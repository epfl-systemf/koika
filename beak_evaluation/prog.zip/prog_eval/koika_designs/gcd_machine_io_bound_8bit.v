(*! Computing GCDs !*)
Require Import Koika.Frontend.
Require Import Koika.Std.

Module GCDMachineIOBound.
  Inductive ext_fn_t := input_data | input_valid |  out_data | out_busy.

  Inductive reg_t :=
  | gcd_busy
  | gcd_a
  | gcd_b
  | output_data
  | last_write_ack.

  Definition pair_t :=
    struct_t {| struct_name := "pair";
                struct_fields := [("a", bits_t 8); ("b", bits_t 8)] |}.

  Definition Sigma (fn: ext_fn_t) : ExternalSignature :=
  match fn with
  | input_data => {$ bits_t 1 ~> pair_t $}
  | input_valid => {$ bits_t 1 ~> bits_t 1 $}
  | out_data => {$ bits_t 8  ~> bits_t 1 $}
  | out_busy => {$ bits_t 1  ~> bits_t 1 $}
  end.


  Definition R r :=
    match r with
    | gcd_busy => bits_t 1
    | gcd_a => bits_t 8
    | gcd_b => bits_t 8
    | output_data => bits_t 8
    | last_write_ack => bits_t 1
    end.

  Definition init_r idx : R idx :=
    match idx with
    | gcd_busy => Bits.zero
    | gcd_a => Bits.zero
    | gcd_b => Bits.zero
    | output_data => Bits.zero
    | last_write_ack => Bits.zero
    end.

   Definition gcd_start : uaction reg_t ext_fn_t :=
    {{  let in_data := extcall input_data(Ob~1) in
        let in_valid := extcall input_valid(Ob~1) in
        if in_valid == Ob~1 && !read0(gcd_busy) then
          write0(gcd_a, get(in_data, a));
          write0(gcd_b, get(in_data, b));
          write0(gcd_busy, Ob~1)
        else
          fail
    }}.

    
  Definition gcd_compute : uaction reg_t ext_fn_t :=
    {{
        let a := read0(gcd_a) in
        let b := read0(gcd_b) in
        if a != |8`d0| then
          if a <= b then
            write0(gcd_b, a);
            write0(gcd_a, b)
          else
            write0(gcd_a, a - b)
        else
          fail
    }}.

  Definition gcd_get_result : uaction reg_t ext_fn_t :=
    {{
        if (read1(gcd_a) == |8`d0|) && read0(gcd_busy) then
          write0(gcd_busy, Ob~0);
          write0(output_data, read1(gcd_b))
        else
          fail
    }}.

     Definition gcd_get_output : uaction reg_t ext_fn_t :=
    {{
       let ack := extcall out_data(read1(output_data)) in
        let busy := extcall out_busy(read1(gcd_busy)) in
         write0(last_write_ack, ack + busy) (* dummy val, otherwise out_data compiled away*)
    }}.

  Definition ext_fn_names (fn: ext_fn_t) :=
    match fn with
    | input_data => "input_data"
    | input_valid => "input_valid"
    | out_data => "out_data"
    | out_busy => "out_busy"
    end.


  Inductive rule_name_t :=
    start | step_compute | get_result | get_output.

  Definition rules :=
    tc_rules R Sigma
             (fun rl => match rl with
                     | start => gcd_start
                     | step_compute => gcd_compute
                     | get_result => gcd_get_result 
                     | get_output => gcd_get_output
                     end).

  Definition bring : scheduler :=
    start |> step_compute |> get_result |> get_output |> done.

  Definition ext_fn_specs (fn : ext_fn_t) :=
    match fn with
    | input_data => {| efr_name := "input_data"; efr_internal := false |}
    | input_valid => {| efr_name := "input_valid"; efr_internal := false |}
    | out_data => {| efr_name := "out_data"; efr_internal := false|}
    | out_busy => {| efr_name := "out_busy"; efr_internal := false |}
    end.


  Definition package :=
    {| ip_koika := {| koika_reg_types := R;
                     koika_reg_init := init_r;
                     koika_ext_fn_types := Sigma;
                     koika_rules := rules;
                     koika_rule_external _ := false;
                     koika_scheduler := bring;
                     koika_module_name := "gcd_machine_io_bound_8bit" |};

       ip_sim := {| sp_ext_fn_specs fn := {| efs_name := show fn; efs_method := false |};
                   sp_prelude := None |};

       ip_verilog := {| vp_ext_fn_specs := ext_fn_specs |} |}.

End GCDMachineIOBound.

Definition prog := Interop.Backends.register GCDMachineIOBound.package.
Extraction "gcd_machine_io_bound_8bit.ml" prog.
