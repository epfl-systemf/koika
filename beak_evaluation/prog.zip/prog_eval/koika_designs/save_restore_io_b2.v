(*! Save and restore simulation state !*)
Require Import Koika.Frontend.

Module SaveRestoreIOB2.
  Inductive reg_t := counter | dummy_val.
  Inductive rule_name_t := increment_counter.

  Inductive ext_fn_t := input_valid | input_counter | output_counter.

  Definition R r :=
    match r with
    | counter => bits_t 32
    | dummy_val => bits_t 1
    end.

  Definition r idx : R idx :=
    match idx with
    | counter => Bits.zero
    | dummy_val => Bits.zero
    end.

  Definition Sigma (fn: ext_fn_t) : ExternalSignature :=
    match fn with
    | input_valid => {$ bits_t 1 ~> bits_t 1 $}
    | input_counter => {$ bits_t 1 ~> bits_t 32 $}
    | output_counter => {$ bits_t 32 ~> bits_t 1 $}
    end.

  Definition _increment_counter : uaction reg_t ext_fn_t :=
    {{ let counter_data := extcall input_counter(Ob~1) in
       let valid := extcall input_valid(Ob~1) in
        let out := extcall output_counter(read0(counter)) in
        write0(dummy_val, out);  (* out assignment otherwise compiled away*)
        if valid == Ob~1 then
            write0(counter, counter_data + |32`d1|)  
        else  write0(counter, read0(counter) + |32`d2|) }}.

  Definition save_restore : scheduler :=
    increment_counter |> done.

  Definition rules :=
    tc_rules R Sigma
             (fun r => match r with
                    | increment_counter => _increment_counter
                    end).

  (* Definition external (_: rule_name_t) := false. *)

  Definition ext_fn_names (fn: ext_fn_t) :=
    match fn with
    | input_valid => "input_valid"
    | input_counter => "input_counter"
    | output_counter => "output_counter"
    end.

  Definition ext_fn_specs (fn : ext_fn_t) :=
    match fn with
    | input_valid => {| efr_name := "input_valid"; efr_internal := false |}
    | input_counter => {| efr_name := "input_counter"; efr_internal := false |}
    | output_counter => {| efr_name := "output_counter"; efr_internal := false |}
    end.

  Definition package :=
    {| ip_koika := {| koika_reg_types := R;
                     koika_reg_init := r;
                     koika_ext_fn_types := Sigma;
                     koika_rules := rules;
                     koika_rule_external _ := false;
                     koika_scheduler := save_restore;
                     koika_module_name := "save_restore_io_b2" |};

       ip_sim := {| sp_ext_fn_specs fn := {| efs_name := show fn; efs_method := false |};
                   sp_prelude := None |};

       ip_verilog := {| vp_ext_fn_specs := ext_fn_specs |} |}.

End SaveRestoreIOB2.

Definition prog := Interop.Backends.register SaveRestoreIOB2.package.
