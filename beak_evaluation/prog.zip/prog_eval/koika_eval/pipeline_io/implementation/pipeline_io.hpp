#ifndef MODULE_PIPELINE_IO_HPP
#define MODULE_PIPELINE_IO_HPP

//////////////
// PREAMBLE //
//////////////

#include "cuttlesim.hpp"
#include <cstdlib>

//////////////
// TYPEDEFS //
//////////////




namespace prims {
#ifndef SIM_MINIMAL
#endif

}

////////////////////
// IMPLEMENTATION //
////////////////////

template <typename extfuns_t> class module_pipeline_io {
public:
struct state_t {
bits<32> r0;
bits<32> outputReg;
bits<32> inputReg;
bits<1> invalid;
bits<1> correct;
bits<1> last_write_ack;

#ifndef SIM_MINIMAL
void dump(std::ostream& os = std::cout) const {
os << "r0 = " << r0 << std::endl;
os << "outputReg = " << outputReg << std::endl;
os << "inputReg = " << inputReg << std::endl;
os << "invalid = " << invalid << std::endl;
os << "correct = " << correct << std::endl;
os << "last_write_ack = " << last_write_ack << std::endl;
}

static _unused void vcd_header(std::ostream& os) {
#ifndef SIM_VCD_SCOPES
#define SIM_VCD_SCOPES { "TOP", "pipeline_io" }
#endif
cuttlesim::vcd::begin_header(os, SIM_VCD_SCOPES);
cuttlesim::vcd::var(os, "r0", 32);
cuttlesim::vcd::var(os, "outputReg", 32);
cuttlesim::vcd::var(os, "inputReg", 32);
cuttlesim::vcd::var(os, "invalid", 1);
cuttlesim::vcd::var(os, "correct", 1);
cuttlesim::vcd::var(os, "last_write_ack", 1);
cuttlesim::vcd::end_header(os, SIM_VCD_SCOPES);
}

void vcd_dumpvars(std::uint_fast64_t cycle_id, _unused std::ostream& os, const state_t& previous, const bool force) const {
os << '#' << cycle_id << std::endl;
cuttlesim::vcd::dumpvar(os, "r0", r0, previous.r0, force);
cuttlesim::vcd::dumpvar(os, "outputReg", outputReg, previous.outputReg, force);
cuttlesim::vcd::dumpvar(os, "inputReg", inputReg, previous.inputReg, force);
cuttlesim::vcd::dumpvar(os, "invalid", invalid, previous.invalid, force);
cuttlesim::vcd::dumpvar(os, "correct", correct, previous.correct, force);
cuttlesim::vcd::dumpvar(os, "last_write_ack", last_write_ack, previous.last_write_ack, force);
}

std::uint_fast64_t vcd_readvars(_unused std::istream& is) {
std::string var{}, val{};
std::uint_fast64_t cycle_id = std::numeric_limits<std::uint_fast64_t>::max();
cuttlesim::vcd::read_header(is);
while (cuttlesim::vcd::readvar(is, cycle_id, var, val)) {
if (var == "r0") {
r0 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "outputReg") {
outputReg = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "inputReg") {
inputReg = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "invalid") {
invalid = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "correct") {
correct = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "last_write_ack") {
last_write_ack = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
}
return cycle_id;
}
#endif
};

using snapshot_t = cuttlesim::snapshot_t<state_t>;

protected:
struct rwset_t {
cuttlesim::ehr_rwset outputReg;
cuttlesim::ehr_rwset invalid;
};

struct log_t {
rwset_t rwset;
state_t state;

const state_t& snapshot() const {
return state;
}
explicit log_t(const state_t& init) : rwset{}, state(init) {
}
};

log_t log;
log_t Log;
extfuns_t extfuns;
cuttlesim::sim_metadata meta;

#ifndef SIM_MINIMAL
std::default_random_engine rng{};
std::uniform_int_distribution<int> uniform{0, 2};
#endif

#define RULE_NAME read_out
DEF_RESET(read_out) {
log.state.last_write_ack = Log.state.last_write_ack;
log.rwset.outputReg = Log.rwset.outputReg;
log.rwset.invalid = Log.rwset.invalid;
}

DEF_COMMIT(read_out) {
Log.state.last_write_ack = log.state.last_write_ack;
Log.rwset.outputReg = log.rwset.outputReg;
Log.rwset.invalid = log.rwset.invalid;
}

DEF_RULE(read_out) {
bits<32> _x0 = READ1(outputReg);
bits<1> ack = extfuns.output_data(_x0);
bits<1> _x1 = READ1(invalid);
bits<1> busy = extfuns.output_phase(_x1);
WRITE0_FAST(last_write_ack, (ack + busy));

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME doF
DEF_RESET(doF) {
log.state.r0 = Log.state.r0;
log.state.outputReg = Log.state.outputReg;
log.state.inputReg = Log.state.inputReg;
log.state.invalid = Log.state.invalid;
log.rwset.outputReg = Log.rwset.outputReg;
log.rwset.invalid = Log.rwset.invalid;
}

DEF_COMMIT(doF) {
Log.state.r0 = log.state.r0;
Log.state.outputReg = log.state.outputReg;
Log.state.inputReg = log.state.inputReg;
Log.state.invalid = log.state.invalid;
Log.rwset.outputReg = log.rwset.outputReg;
Log.rwset.invalid = log.rwset.invalid;
}

DEF_RULE(doF) {
bits<32> v = extfuns.input_data(1'1_b);
bits<1> valid = extfuns.input_valid(1'1_b);
bits<1> invalid = READ1(invalid);
if (valid) {
if (invalid) {
bits<32> _v0 = extfuns.stream(v);
WRITE0_FAST(inputReg, _v0);
WRITE0(outputReg, v);
WRITE1(invalid, 1'0_b);
bits<32> _x3 = extfuns.stream(v);
bits<32> _v3 = extfuns.f(_x3);
WRITE0_FAST(r0, _v3);
}
else {
FAIL_FAST();
}
}
else {
FAIL_FAST();
}

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME doG
DEF_RESET(doG) {
log.state.outputReg = Log.state.outputReg;
log.state.invalid = Log.state.invalid;
log.state.correct = Log.state.correct;
log.rwset.outputReg = Log.rwset.outputReg;
log.rwset.invalid = Log.rwset.invalid;
}

DEF_COMMIT(doG) {
Log.state.outputReg = log.state.outputReg;
Log.state.invalid = log.state.invalid;
Log.state.correct = log.state.correct;
Log.rwset.outputReg = log.rwset.outputReg;
Log.rwset.invalid = log.rwset.invalid;
}

DEF_RULE(doG) {
bits<1> invalid = READ0(invalid);
if (~(invalid)) {
bits<32> data = READ0_FAST(r0);
bits<32> v = READ0(outputReg);
bits<32> _v0 = extfuns.stream(v);
WRITE0(outputReg, _v0);
WRITE0(invalid, 1'1_b);
bits<32> _x2 = extfuns.g(data);
bits<32> _x4 = extfuns.f(v);
bits<32> _y0 = extfuns.g(_x4);
if ((_x2 == _y0)) {
}
else {
WRITE0_FAST(correct, 1'0_b);
}
}
else {
FAIL_FAST();
}

COMMIT();
}
#undef RULE_NAME

#ifdef SIM_FUZZER
using assert_pred_t = bool(*)(const module_pipeline_io&);
assert_pred_t assert_pred = nullptr;
assert_pred_t assert_pred_final = nullptr;
std::vector<snapshot_t> snapshot_history;

#endif

public:
void finish(cuttlesim::exit_info exit_config, int exit_code) {
meta.finished = true;
meta.exit_config = exit_config;
meta.exit_code = exit_code;
}

bool finished() {
return meta.finished;
}

snapshot_t snapshot() const {
return snapshot_t(Log.snapshot(), meta);
}

static constexpr state_t initial_state() {
state_t init {
.r0 = 32'0_b,
.outputReg = 32'0_b,
.inputReg = 32'0_b,
.invalid = 1'1_b,
.correct = 1'1_b,
.last_write_ack = 1'1_b,
};
return init;
}

explicit module_pipeline_io(const state_t init = initial_state()) : log(init), Log(init), extfuns{}, meta{} {
#ifndef SIM_MINIMAL
rng.seed(cuttlesim::random_seed);
#endif
}

_virtual void strobe() const {}

void cycle() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
rule_doG();
rule_doF();
rule_read_out();
strobe();
}

_flatten module_pipeline_io& run(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
}
return *this;
}

#ifndef SIM_MINIMAL
typedef bool (module_pipeline_io::*rule_ptr)();
void cycle_randomized() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
static constexpr rule_ptr rules[3] {
&module_pipeline_io::rule_read_out,
&module_pipeline_io::rule_doF,
&module_pipeline_io::rule_doG};
(this->*rules[uniform(rng)])();
strobe();
}

_flatten module_pipeline_io& run_randomized(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
}
return *this;
}

_flatten module_pipeline_io& trace(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}

_flatten module_pipeline_io& trace_randomized(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}
#endif
#ifdef SIM_FUZZER
void clear_snapshots() {
snapshot_history.clear();
}

const std::vector<snapshot_t>& get_snapshots() const {
return snapshot_history;
}

_flatten module_pipeline_io& run_fuzz(std::uint_fast64_t ncycles, bool abort_on_failure) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();

snapshot_history.push_back(snapshot());
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
if (!cuttlesim::fuzz::check_pred(*this, assert_pred_final, abort_on_failure)) { 
return *this;
}
return *this;
}

_flatten module_pipeline_io& run_trace_until_fail(std::string fname, std::uint_fast64_t ncycles, bool abort_on_failure) {
clear_snapshots();
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
snapshot_history.push_back(snapshot());
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
return *this;
}
void set_assert_pred(assert_pred_t p) {
assert_pred = p;
}

void clear_assert_pred() {
assert_pred = nullptr;
}

void set_assert_pred_final(assert_pred_t p) {
assert_pred_final = p;
}

void clear_assert_pred_final() {
assert_pred_final = nullptr;
}

#endif
};

#endif
