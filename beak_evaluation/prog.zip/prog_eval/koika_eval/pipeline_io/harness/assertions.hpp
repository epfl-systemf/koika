#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {

  auto snap_hist = sim.get_snapshots();

  if (snap_hist.size() < 2) {
    return true; // not enough history to check, so just pass
  }

  auto curr_snap = snap_hist.back();

  return curr_snap.state.correct.v == 1; // check that the correct bit is 1
}

template <typename sim_t>
inline bool assert_final(const sim_t& sim) {

  return true;
}

#endif