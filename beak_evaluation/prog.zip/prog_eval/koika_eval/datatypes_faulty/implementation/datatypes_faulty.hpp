#ifndef MODULE_DATATYPES_FAULTY_HPP
#define MODULE_DATATYPES_FAULTY_HPP

//////////////
// PREAMBLE //
//////////////

#define NEEDS_BOOST_MULTIPRECISION

#include "cuttlesim.hpp"
#include <cstdlib>

//////////////
// TYPEDEFS //
//////////////

enum class enum_flag : bits_t<1> {
set = 1'1_bv
, 
unset = 1'0_bv
};
enum class enum_protocol : bits_t<8> {
ICMP = 8'00000001_bv
, 
IGMP = 8'00000010_bv
, 
TCP = 8'00000110_bv
, 
UDP = 8'00010001_bv
};

struct struct_ipv4_header {
bits<4> version;
bits<4> ihl;
bits<6> dscp;
bits<2> ecn;
bits<16> len;
bits<16> id;
enum_flag reserved;
enum_flag df;
enum_flag mf;
bits<13> fragment_offset;
bits<8> ttl;
enum_protocol protocol;
bits<16> checksum;
array<bits<8>, 4> src;
array<bits<8>, 4> dst;
};

struct struct_result {
bits<1> valid;
struct_ipv4_header value;
};

static _unused bits<1>  operator==(const enum_flag v1, const enum_flag v2) {
return bits<1>::mk(v1) == bits<1>::mk(v2);
}
static _unused bits<1>  operator!=(const enum_flag v1, const enum_flag v2) {
return !(v1 == v2);}

#ifndef SIM_MINIMAL
static _unused std::ostream& operator<<(std::ostream& os, const enum_flag& val) {
return prims::fmt(os, val);
}
#endif

static _unused bits<1>  operator==(const enum_protocol v1, const enum_protocol v2) {
return bits<8>::mk(v1) == bits<8>::mk(v2);
}
static _unused bits<1>  operator!=(const enum_protocol v1, const enum_protocol v2) {
return !(v1 == v2);}

#ifndef SIM_MINIMAL
static _unused std::ostream& operator<<(std::ostream& os, const enum_protocol& val) {
return prims::fmt(os, val);
}
#endif

static _unused bits<1>  operator==(const struct_ipv4_header v1, const struct_ipv4_header v2) {
return bits<1>::mk(bool(v1.version == v2.version) && bool(v1.ihl == v2.ihl) && bool(v1.dscp == v2.dscp) && bool(v1.ecn == v2.ecn) && bool(v1.len == v2.len) && bool(v1.id == v2.id) && bool(v1.reserved == v2.reserved) && bool(v1.df == v2.df) && bool(v1.mf == v2.mf) && bool(v1.fragment_offset == v2.fragment_offset) && bool(v1.ttl == v2.ttl) && bool(v1.protocol == v2.protocol) && bool(v1.checksum == v2.checksum) && bool(v1.src == v2.src) && bool(v1.dst == v2.dst));
}
static _unused bits<1>  operator!=(const struct_ipv4_header v1, const struct_ipv4_header v2) {
return !(v1 == v2);}

#ifndef SIM_MINIMAL
static _unused std::ostream& operator<<(std::ostream& os, const struct_ipv4_header& val) {
return prims::fmt(os, val);
}
#endif

static _unused bits<1>  operator==(const struct_result v1, const struct_result v2) {
return bits<1>::mk(bool(v1.valid == v2.valid) && bool(v1.value == v2.value));
}
static _unused bits<1>  operator!=(const struct_result v1, const struct_result v2) {
return !(v1 == v2);}

#ifndef SIM_MINIMAL
static _unused std::ostream& operator<<(std::ostream& os, const struct_result& val) {
return prims::fmt(os, val);
}
#endif

namespace prims {
#ifndef SIM_MINIMAL
static _unused std::ostream& fmt(std::ostream& os, const enum_flag& val, const fmtopts opts) {
switch (val) {
case enum_flag::set: os << "flag::set"; break;
case enum_flag::unset: os << "flag::unset"; break;
default: os << "flag{"; fmt(os, bits<1>::mk(val), opts) << "}";
}
return os;
}

static _unused std::ostream& fmt(std::ostream& os, const enum_protocol& val, const fmtopts opts) {
switch (val) {
case enum_protocol::ICMP: os << "protocol::ICMP"; break;
case enum_protocol::IGMP: os << "protocol::IGMP"; break;
case enum_protocol::TCP: os << "protocol::TCP"; break;
case enum_protocol::UDP: os << "protocol::UDP"; break;
default: os << "protocol{"; fmt(os, bits<8>::mk(val), opts) << "}";
}
return os;
}

static _unused std::ostream& fmt(std::ostream& os, const struct_ipv4_header& val, const fmtopts opts) {
os << "ipv4_header { ";
os << ".version = "; fmt(os, val.version, opts) << "; ";
os << ".ihl = "; fmt(os, val.ihl, opts) << "; ";
os << ".dscp = "; fmt(os, val.dscp, opts) << "; ";
os << ".ecn = "; fmt(os, val.ecn, opts) << "; ";
os << ".len = "; fmt(os, val.len, opts) << "; ";
os << ".id = "; fmt(os, val.id, opts) << "; ";
os << ".reserved = "; fmt(os, val.reserved, opts) << "; ";
os << ".df = "; fmt(os, val.df, opts) << "; ";
os << ".mf = "; fmt(os, val.mf, opts) << "; ";
os << ".fragment_offset = "; fmt(os, val.fragment_offset, opts) << "; ";
os << ".ttl = "; fmt(os, val.ttl, opts) << "; ";
os << ".protocol = "; fmt(os, val.protocol, opts) << "; ";
os << ".checksum = "; fmt(os, val.checksum, opts) << "; ";
os << ".src = "; fmt(os, val.src, opts) << "; ";
os << ".dst = "; fmt(os, val.dst, opts) << "; ";
os << "}";
return os;
}

static _unused std::ostream& fmt(std::ostream& os, const struct_result& val, const fmtopts opts) {
os << "result { ";
os << ".valid = "; fmt(os, val.valid, opts) << "; ";
os << ".value = "; fmt(os, val.value, opts) << "; ";
os << "}";
return os;
}
#endif

template <> struct type_info<enum_flag> {
static constexpr prims::bitwidth size = 1;
};

template <> _unused bits<1> pack<>(const enum_flag val) {
return bits<1>::mk(val);
}

template <> struct _unpack<enum_flag, 1> {
static enum_flag unpack(const bits<1> bs) {
return static_cast<enum_flag>(bs.v);
}
};

template <> struct type_info<enum_protocol> {
static constexpr prims::bitwidth size = 8;
};

template <> _unused bits<8> pack<>(const enum_protocol val) {
return bits<8>::mk(val);
}

template <> struct _unpack<enum_protocol, 8> {
static enum_protocol unpack(const bits<8> bs) {
return static_cast<enum_protocol>(bs.v);
}
};

template <> struct type_info<struct_ipv4_header> {
static constexpr prims::bitwidth size = 160;
};

template <> _unused bits<160> pack<>(const struct_ipv4_header val) {
bits<160> packed = 0x160'0_x;
packed |= prims::widen<160>(val.version);
packed <<= 4;
packed |= prims::widen<160>(val.ihl);
packed <<= 6;
packed |= prims::widen<160>(val.dscp);
packed <<= 2;
packed |= prims::widen<160>(val.ecn);
packed <<= 16;
packed |= prims::widen<160>(val.len);
packed <<= 16;
packed |= prims::widen<160>(val.id);
packed <<= 1;
packed |= prims::widen<160>(prims::pack(val.reserved));
packed <<= 1;
packed |= prims::widen<160>(prims::pack(val.df));
packed <<= 1;
packed |= prims::widen<160>(prims::pack(val.mf));
packed <<= 13;
packed |= prims::widen<160>(val.fragment_offset);
packed <<= 8;
packed |= prims::widen<160>(val.ttl);
packed <<= 8;
packed |= prims::widen<160>(prims::pack(val.protocol));
packed <<= 16;
packed |= prims::widen<160>(val.checksum);
packed <<= 32;
packed |= prims::widen<160>(prims::pack(val.src));
packed <<= 32;
packed |= prims::widen<160>(prims::pack(val.dst));
return packed;
}

template <> struct _unpack<struct_ipv4_header, 160> {
static struct_ipv4_header unpack(const bits<160> bs) {
struct_ipv4_header unpacked = {};
unpacked.dst = prims::unpack<array<bits<8>, 4>>(prims::truncate<32>(bs >> 0u));
unpacked.src = prims::unpack<array<bits<8>, 4>>(prims::truncate<32>(bs >> 32u));
unpacked.checksum = prims::truncate<16>(bs >> 64u);
unpacked.protocol = prims::unpack<enum_protocol>(prims::truncate<8>(bs >> 80u));
unpacked.ttl = prims::truncate<8>(bs >> 88u);
unpacked.fragment_offset = prims::truncate<13>(bs >> 96u);
unpacked.mf = prims::unpack<enum_flag>(prims::truncate<1>(bs >> 109u));
unpacked.df = prims::unpack<enum_flag>(prims::truncate<1>(bs >> 110u));
unpacked.reserved = prims::unpack<enum_flag>(prims::truncate<1>(bs >> 111u));
unpacked.id = prims::truncate<16>(bs >> 112u);
unpacked.len = prims::truncate<16>(bs >> 128u);
unpacked.ecn = prims::truncate<2>(bs >> 144u);
unpacked.dscp = prims::truncate<6>(bs >> 146u);
unpacked.ihl = prims::truncate<4>(bs >> 152u);
unpacked.version = prims::truncate<4>(bs >> 156u);
return unpacked;
}
};

template <> struct type_info<struct_result> {
static constexpr prims::bitwidth size = 161;
};

template <> _unused bits<161> pack<>(const struct_result val) {
bits<161> packed = 0x161'0_x;
packed |= prims::widen<161>(val.valid);
packed <<= 160;
packed |= prims::widen<161>(prims::pack(val.value));
return packed;
}

template <> struct _unpack<struct_result, 161> {
static struct_result unpack(const bits<161> bs) {
struct_result unpacked = {};
unpacked.value = prims::unpack<struct_ipv4_header>(prims::truncate<160>(bs >> 0u));
unpacked.valid = prims::truncate<1>(bs >> 160u);
return unpacked;
}
};
}

////////////////////
// IMPLEMENTATION //
////////////////////

template <typename extfuns_t> class module_datatypes_faulty {
public:
struct state_t {
bits<160> input;
bits<161> output;
bits<8> dbg_in_ttl;
bits<8> dbg_out_ttl;
bits<8> dbg_in_protocol;

#ifndef SIM_MINIMAL
void dump(std::ostream& os = std::cout) const {
os << "input = " << input << std::endl;
os << "output = " << output << std::endl;
os << "dbg_in_ttl = " << dbg_in_ttl << std::endl;
os << "dbg_out_ttl = " << dbg_out_ttl << std::endl;
os << "dbg_in_protocol = " << dbg_in_protocol << std::endl;
}

static _unused void vcd_header(std::ostream& os) {
#ifndef SIM_VCD_SCOPES
#define SIM_VCD_SCOPES { "TOP", "datatypes_faulty" }
#endif
cuttlesim::vcd::begin_header(os, SIM_VCD_SCOPES);
cuttlesim::vcd::var(os, "input", 160);
cuttlesim::vcd::var(os, "output", 161);
cuttlesim::vcd::var(os, "dbg_in_ttl", 8);
cuttlesim::vcd::var(os, "dbg_out_ttl", 8);
cuttlesim::vcd::var(os, "dbg_in_protocol", 8);
cuttlesim::vcd::end_header(os, SIM_VCD_SCOPES);
}

void vcd_dumpvars(std::uint_fast64_t cycle_id, _unused std::ostream& os, const state_t& previous, const bool force) const {
os << '#' << cycle_id << std::endl;
cuttlesim::vcd::dumpvar(os, "input", input, previous.input, force);
cuttlesim::vcd::dumpvar(os, "output", output, previous.output, force);
cuttlesim::vcd::dumpvar(os, "dbg_in_ttl", dbg_in_ttl, previous.dbg_in_ttl, force);
cuttlesim::vcd::dumpvar(os, "dbg_out_ttl", dbg_out_ttl, previous.dbg_out_ttl, force);
cuttlesim::vcd::dumpvar(os, "dbg_in_protocol", dbg_in_protocol, previous.dbg_in_protocol, force);
}

std::uint_fast64_t vcd_readvars(_unused std::istream& is) {
std::string var{}, val{};
std::uint_fast64_t cycle_id = std::numeric_limits<std::uint_fast64_t>::max();
cuttlesim::vcd::read_header(is);
while (cuttlesim::vcd::readvar(is, cycle_id, var, val)) {
if (var == "input") {
input = prims::unpack<bits<160>>(bits<160>::of_str(val));
}
else if (var == "output") {
output = prims::unpack<bits<161>>(bits<161>::of_str(val));
}
else if (var == "dbg_in_ttl") {
dbg_in_ttl = prims::unpack<bits<8>>(bits<8>::of_str(val));
}
else if (var == "dbg_out_ttl") {
dbg_out_ttl = prims::unpack<bits<8>>(bits<8>::of_str(val));
}
else if (var == "dbg_in_protocol") {
dbg_in_protocol = prims::unpack<bits<8>>(bits<8>::of_str(val));
}
}
return cycle_id;
}
#endif
};

using snapshot_t = cuttlesim::snapshot_t<state_t>;

protected:
struct rwset_t {
};

struct log_t {
rwset_t rwset;
state_t state;

const state_t& snapshot() const {
return state;
}
explicit log_t(const state_t& init) : rwset{}, state(init) {
}
};

log_t log;
log_t Log;
extfuns_t extfuns;
cuttlesim::sim_metadata meta;

#ifndef SIM_MINIMAL
std::default_random_engine rng{};
std::uniform_int_distribution<int> uniform{0, 1};
#endif

#define RULE_NAME decr_icmp_ttl
DEF_RESET(decr_icmp_ttl) {
log.state.output = Log.state.output;
log.state.dbg_in_ttl = Log.state.dbg_in_ttl;
log.state.dbg_out_ttl = Log.state.dbg_out_ttl;
log.state.dbg_in_protocol = Log.state.dbg_in_protocol;
}

DEF_COMMIT(decr_icmp_ttl) {
Log.state.output = log.state.output;
Log.state.dbg_in_ttl = log.state.dbg_in_ttl;
Log.state.dbg_out_ttl = log.state.dbg_out_ttl;
Log.state.dbg_in_protocol = log.state.dbg_in_protocol;
}

DEF_RULE(decr_icmp_ttl) {
bits<160> _x0 = READ0_FAST(input);
struct_ipv4_header hdr = prims::unpack<struct_ipv4_header>(_x0);
bits<1> valid = 1'1_b;
WRITE0_FAST(dbg_in_ttl, hdr.ttl);
WRITE0_FAST(dbg_in_protocol, prims::pack(hdr.protocol));
/* bind */ {
enum_protocol renamed_cpp_dx2_reserved_dx2_matchPattern = hdr.protocol;
if ((renamed_cpp_dx2_reserved_dx2_matchPattern == enum_protocol::ICMP)) {
bits<8> t = hdr.ttl;
switch (t.v) {
case 8'00000000_bv: {
valid = 1'0_b;
}
break;
case 8'00101010_bv: {
hdr.ttl = 8'00000011_b;
}
break;
default: {
hdr.ttl = (t - 8'00000001_b);
}
break;
}
}
}
hdr.reserved = enum_flag::unset;
WRITE0_FAST(dbg_out_ttl, hdr.ttl);
struct_result _x8 = struct_result{};
_x8.valid = valid;
_x8.value = hdr;
WRITE0_FAST(output, prims::pack(_x8));

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME clear_checksum
DEF_RESET(clear_checksum) {
log.state.output = Log.state.output;
}

DEF_COMMIT(clear_checksum) {
Log.state.output = log.state.output;
}

DEF_RULE(clear_checksum) {
bits<161> presp = READ1_FAST(output);
bits<160> phdr = prims::slice<0, 160>(presp);
phdr = prims::slice_subst<64>(phdr, 16'0_b);
WRITE1_FAST(output, prims::slice_subst<0>(presp, phdr));

COMMIT();
}
#undef RULE_NAME

#ifdef SIM_FUZZER
using assert_pred_t = bool(*)(const module_datatypes_faulty&);
assert_pred_t assert_pred = nullptr;
assert_pred_t assert_pred_final = nullptr;
std::vector<snapshot_t> snapshot_history;

#endif

public:
void finish(cuttlesim::exit_info exit_config, int exit_code) {
meta.finished = true;
meta.exit_config = exit_config;
meta.exit_code = exit_code;
}

bool finished() {
return meta.finished;
}

snapshot_t snapshot() const {
return snapshot_t(Log.snapshot(), meta);
}

static constexpr state_t initial_state() {
state_t init {
.input = 0x160'45000054768500004001f0210a0000010a000002_x,
.output = 0x161'0_x,
.dbg_in_ttl = 8'00000000_b,
.dbg_out_ttl = 8'00000000_b,
.dbg_in_protocol = 8'00000000_b,
};
return init;
}

explicit module_datatypes_faulty(const state_t init = initial_state()) : log(init), Log(init), extfuns{}, meta{} {
#ifndef SIM_MINIMAL
rng.seed(cuttlesim::random_seed);
#endif
}

_virtual void strobe() const {}

void cycle() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
rule_decr_icmp_ttl();
rule_clear_checksum();
strobe();
}

_flatten module_datatypes_faulty& run(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
}
return *this;
}

#ifndef SIM_MINIMAL
typedef bool (module_datatypes_faulty::*rule_ptr)();
void cycle_randomized() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
static constexpr rule_ptr rules[2] {
&module_datatypes_faulty::rule_decr_icmp_ttl,
&module_datatypes_faulty::rule_clear_checksum};
(this->*rules[uniform(rng)])();
strobe();
}

_flatten module_datatypes_faulty& run_randomized(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
}
return *this;
}

_flatten module_datatypes_faulty& trace(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}

_flatten module_datatypes_faulty& trace_randomized(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}
#endif
#ifdef SIM_FUZZER
void clear_snapshots() {
snapshot_history.clear();
}

const std::vector<snapshot_t>& get_snapshots() const {
return snapshot_history;
}

_flatten module_datatypes_faulty& run_fuzz(std::uint_fast64_t ncycles, bool abort_on_failure) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();

snapshot_history.push_back(snapshot());
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
if (!cuttlesim::fuzz::check_pred(*this, assert_pred_final, abort_on_failure)) { 
return *this;
}
return *this;
}

_flatten module_datatypes_faulty& run_trace_until_fail(std::string fname, std::uint_fast64_t ncycles, bool abort_on_failure) {
clear_snapshots();
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
snapshot_history.push_back(snapshot());
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
return *this;
}
void set_assert_pred(assert_pred_t p) {
assert_pred = p;
}

void clear_assert_pred() {
assert_pred = nullptr;
}

void set_assert_pred_final(assert_pred_t p) {
assert_pred_final = p;
}

void clear_assert_pred_final() {
assert_pred_final = nullptr;
}

#endif
};

#endif
