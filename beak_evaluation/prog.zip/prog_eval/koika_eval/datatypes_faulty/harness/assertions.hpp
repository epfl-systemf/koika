#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {
  const auto s = sim.snapshot().state;

  const auto in_protocol = s.dbg_in_protocol.v;
  const auto in_ttl = s.dbg_in_ttl.v;
  const auto out_ttl = s.dbg_out_ttl.v;

  // ICMP has bitpattern 0x01 in enum definition.
  if (in_protocol == 0x01 && in_ttl == 42) {
    return out_ttl == 41;
  }

  return true;
}


template <typename sim_t>
inline bool assert_final(const sim_t& sim) {

  return true;
}

#endif