#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {
  auto& out_data_q  = harness::extfuns_impl::out_data_chan.q_assert;

  if (out_data_q.size() < 2) {
    return true; // not enough history to check, so just pass
  }

  auto last_snap = out_data_q.back();
  auto second_last_snap = out_data_q[out_data_q.size() - 2];

  auto last_r0 = last_snap.v;
  auto second_last_r0 = second_last_snap.v;
  
  return !(second_last_r0 == 41 && last_r0 == 3);
}

template <typename sim_t>
inline bool assert_final(const sim_t& sim) {

  return true;
}

#endif