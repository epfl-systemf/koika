#!/usr/bin/env python3

import argparse
import csv
import os
import re
import subprocess
from pathlib import Path
from datetime import datetime


DEFAULT_N_RUNS = 10
DEFAULT_TIMEOUT_SECONDS = 60 * 60
DEFAULT_TEST_DIR = "collatz"
DEFAULT_OPT = "O3"
DEFAULT_LAF = 0
DEFAULT_BIN = "./harness_1"


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Collect time-to-first-crash data from existing AFL++ output "
            "folders and write the same CSV format as the repeated-run script."
        )
    )

    parser.add_argument(
        "test_dir",
        nargs="?",
        default=DEFAULT_TEST_DIR,
        help="Test directory, e.g. collatz.",
    )

    parser.add_argument(
        "--opt",
        default=DEFAULT_OPT,
        choices=["O0", "O1", "O2", "O3"],
        help="Optimization level used in the folder/CSV naming.",
    )

    parser.add_argument(
        "--laf",
        type=int,
        choices=[0, 1],
        default=DEFAULT_LAF,
        help="Whether the collected runs used LAF instrumentation.",
    )

    parser.add_argument(
        "--runs",
        type=int,
        default=DEFAULT_N_RUNS,
        help="Number of folders to collect when using --folder-template.",
    )

    parser.add_argument(
        "--timeout",
        type=int,
        default=DEFAULT_TIMEOUT_SECONDS,
        help="Timeout per trial in seconds, used only to mark timed_out.",
    )

    parser.add_argument(
        "--folder-template",
        default=None,
        help=(
            "Folder-name template relative to test_dir. Available fields: "
            "{opt}, {run_id}, {run_id02}, {laf_suffix}. "
            "Default: result_{opt}_trial_{run_id02}{laf_suffix}. "
            "If the template contains glob characters (*, ?, [), it will be used as a glob pattern to find matching directories under test_dir."
        ),
    )

    parser.add_argument(
        "--out-dirs",
        nargs="+",
        default=None,
        help=(
            "Explicit AFL++ output folders to collect. If given, this overrides "
            "--folder-template and --runs."
        ),
    )

    parser.add_argument(
        "--results-csv",
        default=None,
        help="CSV output path. Defaults to test_dir/time_to_first_bug_<opt><laf_suffix>.csv.",
    )

    parser.add_argument(
        "--bin",
        default=DEFAULT_BIN,
        help="Harness path relative to test_dir, only used with --decode.",
    )

    parser.add_argument(
        "--decode",
        action="store_true",
        help="Run the harness once with --replay on the first crash to create decoded output.",
    )

    return parser.parse_args()


def laf_suffix(laf_enabled: int) -> str:
    return "_laf" if laf_enabled == 1 else ""


def default_folder_name(opt: str, run_id: int, laf_enabled: int) -> str:
    return f"result_{opt}_trial_{run_id:02d}{laf_suffix(laf_enabled)}"


def format_folder_template(template: str, *, opt: str, run_id: int, laf_enabled: int) -> str:
    return template.format(
        opt=opt,
        run_id=run_id,
        run_id02=f"{run_id:02d}",
        laf_suffix=laf_suffix(laf_enabled),
    )


def crash_files(crash_dir: Path):
    if not crash_dir.exists():
        return []

    return sorted(
        p for p in crash_dir.glob("id:*")
        if p.is_file() and p.name != "README.txt"
    )


def find_afl_instance_dir(out_dir: Path) -> Path:
    candidates = [out_dir / "default", out_dir / "out", out_dir]

    for candidate in candidates:
        if (candidate / "fuzzer_stats").exists():
            return candidate

    out_root = out_dir / "out"
    if out_root.exists() and out_root.is_dir():
        subdirs = sorted(p for p in out_root.iterdir() if p.is_dir())
        for subdir in subdirs:
            if (subdir / "fuzzer_stats").exists():
                return subdir

    return out_dir / "default"


def parse_fuzzer_stats(stats_path: Path) -> dict:
    stats = {}

    if not stats_path.exists():
        return stats

    for line in stats_path.read_text(errors="replace").splitlines():
        if ":" not in line:
            continue

        key, value = line.split(":", 1)
        stats[key.strip()] = value.strip()

    return stats


def as_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def as_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def infer_start_timestamp(stats: dict, stats_path: Path):
    start_time = as_int(stats.get("start_time"))
    if start_time is not None and start_time > 0:
        return float(start_time)

    last_update = as_int(stats.get("last_update"))
    run_time = as_float(stats.get("run_time"))

    if last_update is not None and run_time is not None:
        return float(last_update) - run_time

    if stats_path.exists() and run_time is not None:
        return stats_path.stat().st_mtime - run_time

    return None


def infer_total_runtime(stats: dict, stats_path: Path, start_ts):
    run_time = as_float(stats.get("run_time"))
    if run_time is not None:
        return run_time

    last_update = as_int(stats.get("last_update"))
    if start_ts is not None and last_update is not None:
        return max(0.0, float(last_update) - start_ts)

    if start_ts is not None and stats_path.exists():
        return max(0.0, stats_path.stat().st_mtime - start_ts)

    return None


def crash_time_from_filename(crash_file: Path):
    match = re.search(r"(?:^|,)time:(\d+)(?:,|$)", crash_file.name)
    if not match:
        return None

    # AFL++ encodes this time in milliseconds since fuzzing start.
    return int(match.group(1)) / 1000.0


def infer_time_to_first_bug(first_crash: Path, start_ts):
    from_name = crash_time_from_filename(first_crash)
    if from_name is not None:
        return from_name

    if start_ts is not None:
        return max(0.0, first_crash.stat().st_mtime - start_ts)

    return None


def find_existing_decoded_file(first_crash: Path) -> str:
    decoded_path = Path(f"{first_crash}_decoded")
    return str(decoded_path) if decoded_path.exists() else ""


def decode_crash_once(*, test_dir: str, crash_file: str, bin_path: str) -> str:
    harness_path = Path(test_dir) / bin_path
    decoded_path = Path(f"{crash_file}_decoded")

    if not harness_path.exists():
        return find_existing_decoded_file(Path(crash_file))

    try:
        subprocess.run(
            [str(harness_path), "--replay", crash_file],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
    except OSError:
        return find_existing_decoded_file(Path(crash_file))

    return str(decoded_path) if decoded_path.exists() else ""


def find_log_path(test_dir: Path, opt_level: str, laf_enabled: int, run_id: int, kind: str) -> str:
    log_dir = test_dir / f"trial_logs_{opt_level}{laf_suffix(laf_enabled)}"
    path = log_dir / f"trial_{run_id:02d}.{kind}.log"
    return str(path) if path.exists() else ""


def collect_trial(
    *,
    run_id: int,
    n_runs: int,
    test_dir: str,
    opt_level: str,
    laf_enabled: int,
    out_dir: Path,
    timeout_seconds: int,
    decode: bool,
    bin_path: str,
) -> dict:
    afl_instance_dir = find_afl_instance_dir(out_dir)
    crash_dir = afl_instance_dir / "crashes"
    stats_path = afl_instance_dir / "fuzzer_stats"

    stats = parse_fuzzer_stats(stats_path)

    start_ts = infer_start_timestamp(stats, stats_path)
    total_runtime = infer_total_runtime(stats, stats_path, start_ts)

    start_wall = ""
    if start_ts is not None:
        start_wall = datetime.fromtimestamp(start_ts).isoformat(timespec="seconds")

    crashes = crash_files(crash_dir)

    bug_found = bool(crashes)
    first_crash = str(crashes[0]) if bug_found else ""

    time_to_first_bug = ""
    decoded_file = ""

    if bug_found:
        inferred = infer_time_to_first_bug(crashes[0], start_ts)
        if inferred is not None:
            time_to_first_bug = round(inferred, 3)

        decoded_file = (
            decode_crash_once(
                test_dir=test_dir,
                crash_file=first_crash,
                bin_path=bin_path,
            )
            if decode
            else find_existing_decoded_file(crashes[0])
        )

    timed_out = False
    if not bug_found and total_runtime is not None:
        timed_out = total_runtime >= timeout_seconds

    test_dir_path = Path(test_dir)

    return {
        "run_id": run_id,
        "n_runs": n_runs,
        "test_dir": test_dir,
        "opt_level": opt_level,
        "out_dir": str(out_dir),
        "start_time": start_wall,
        "bug_found": bug_found,
        "time_to_first_bug_seconds": time_to_first_bug,
        "timed_out": timed_out,
        "total_runtime_seconds": round(total_runtime, 3) if total_runtime is not None else "",
        "first_crash": first_crash,
        "decoded_file": decoded_file,
        "stdout_log": find_log_path(test_dir_path, opt_level, laf_enabled, run_id, "stdout"),
        "stderr_log": find_log_path(test_dir_path, opt_level, laf_enabled, run_id, "stderr"),
    }


def build_out_dirs(args):
    test_dir = Path(args.test_dir)

    if args.out_dirs:
        return [Path(p) for p in args.out_dirs]

    template = args.folder_template

    # If template contains glob characters, treat it as a glob pattern and
    # return all matching directories under test_dir.
    if template and any(c in template for c in "*?["):
        matches = sorted(p for p in test_dir.glob(template) if p.is_dir())
        return matches

    out_dirs = []
    for run_id in range(1, args.runs + 1):
        if template:
            folder_name = format_folder_template(
                template,
                opt=args.opt,
                run_id=run_id,
                laf_enabled=args.laf,
            )
        else:
            folder_name = default_folder_name(args.opt, run_id, args.laf)

        out_dirs.append(test_dir / folder_name)

    return out_dirs


def main():
    args = parse_args()

    test_dir = args.test_dir
    opt_level = args.opt
    laf_enabled = args.laf

    out_dirs = build_out_dirs(args)
    n_runs = len(out_dirs)

    if args.results_csv:
        results_csv = Path(args.results_csv)
    else:
        results_csv = Path(test_dir) / f"time_to_first_bug_{opt_level}{laf_suffix(laf_enabled)}.csv"

    results_csv.parent.mkdir(parents=True, exist_ok=True)

    fields = [
        "run_id",
        "n_runs",
        "test_dir",
        "opt_level",
        "out_dir",
        "start_time",
        "bug_found",
        "time_to_first_bug_seconds",
        "timed_out",
        "total_runtime_seconds",
        "first_crash",
        "decoded_file",
        "stdout_log",
        "stderr_log",
    ]

    with open(results_csv, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fields)
        writer.writeheader()

        for index, out_dir in enumerate(out_dirs, start=1):
            print(f"[collect {index}/{n_runs}] {out_dir}")

            if not out_dir.exists():
                print(f"[warning] missing folder: {out_dir}")

            row = collect_trial(
                run_id=index,
                n_runs=n_runs,
                test_dir=test_dir,
                opt_level=opt_level,
                laf_enabled=laf_enabled,
                out_dir=out_dir,
                timeout_seconds=args.timeout,
                decode=args.decode,
                bin_path=args.bin,
            )

            writer.writerow(row)
            csvfile.flush()

            print(
                f"[collect {index}/{n_runs}] "
                f"bug_found={row['bug_found']} "
                f"time_to_first_bug={row['time_to_first_bug_seconds']}s "
                f"timed_out={row['timed_out']}"
            )

    print(f"[done] wrote results to {results_csv}")


if __name__ == "__main__":
    main()
