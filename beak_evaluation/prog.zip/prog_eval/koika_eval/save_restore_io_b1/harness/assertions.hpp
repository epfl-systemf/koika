#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {
  auto& input_counter_q  = harness::extfuns_impl::input_counter_chan.q_assert;
  auto& input_valid_q  = harness::extfuns_impl::input_valid_chan.q_assert;
  auto& output_counter_q  = harness::extfuns_impl::output_counter_chan.q_assert;

  auto index = output_counter_q.size(); 
  auto input_counter_prev = input_counter_q.size() > 1 ? input_counter_q[index - 2].v : 0u;
  auto input_valid = input_valid_q.size() > 1 ? input_valid_q[index - 2].v : 0u;
  auto output_counter = output_counter_q.size() > 1 ? output_counter_q.back().v : 0u;
  auto output_counter_prev = output_counter_q.size() > 2 ? output_counter_q[output_counter_q.size() - 2].v : 0u;

  if (index > 1) {
    if (input_valid == 1) {
        return input_counter_prev + 1 == output_counter;  }
    else {
        return output_counter_prev + 1 == output_counter;
    } 
  }
  return true;
}


template <typename sim_t>
inline bool assert_final(const sim_t& sim) {

  return true;
}

#endif