#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {
  const auto& input_data_q  = harness::extfuns_impl::input_data_chan.q_assert;
  const auto& input_valid_q = harness::extfuns_impl::input_valid_chan.q_assert;
  const auto& out_busy_q    = harness::extfuns_impl::out_busy_chan.q_assert;

  const auto snap = sim.snapshot();

  // Only check while computation is active
  if (!snap.state.gcd_busy.v) return true;

  const size_t n = out_busy_q.size();
  if (n == 0) return true;

  // Find most recent accepted input
  for (size_t i = n; i-- > 0; ) {
    if (input_valid_q[i].v == 1 && out_busy_q[i].v == 0) { 
      const uint32_t orig_a = input_data_q[i].a.v; 
      const uint32_t orig_b = input_data_q[i].b.v;

      const uint32_t curr_a = snap.state.gcd_a.v;
      const uint32_t curr_b = snap.state.gcd_b.v;

      return std::gcd(orig_a, orig_b) == std::gcd(curr_a, curr_b);
    }
  }

  return true;
}

template <typename sim_t>
inline bool assert_final(const sim_t& sim) {

  return true;
}

#endif