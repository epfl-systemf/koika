#ifndef MODULE_GCD_MACHINE_IO_BOUND_8BIT_HPP
#define MODULE_GCD_MACHINE_IO_BOUND_8BIT_HPP

//////////////
// PREAMBLE //
//////////////

#include "cuttlesim.hpp"
#include <cstdlib>

//////////////
// TYPEDEFS //
//////////////


struct struct_pair {
bits<8> a;
bits<8> b;
};

static _unused bits<1>  operator==(const struct_pair v1, const struct_pair v2) {
return bits<1>::mk(bool(v1.a == v2.a) && bool(v1.b == v2.b));
}
static _unused bits<1>  operator!=(const struct_pair v1, const struct_pair v2) {
return !(v1 == v2);}

#ifndef SIM_MINIMAL
static _unused std::ostream& operator<<(std::ostream& os, const struct_pair& val) {
return prims::fmt(os, val);
}
#endif

namespace prims {
#ifndef SIM_MINIMAL
static _unused std::ostream& fmt(std::ostream& os, const struct_pair& val, const fmtopts opts) {
os << "pair { ";
os << ".a = "; fmt(os, val.a, opts) << "; ";
os << ".b = "; fmt(os, val.b, opts) << "; ";
os << "}";
return os;
}
#endif

template <> struct type_info<struct_pair> {
static constexpr prims::bitwidth size = 16;
};

template <> _unused bits<16> pack<>(const struct_pair val) {
bits<16> packed = 16'0_b;
packed |= prims::widen<16>(val.a);
packed <<= 8;
packed |= prims::widen<16>(val.b);
return packed;
}

template <> struct _unpack<struct_pair, 16> {
static struct_pair unpack(const bits<16> bs) {
struct_pair unpacked = {};
unpacked.b = prims::truncate<8>(bs >> 0u);
unpacked.a = prims::truncate<8>(bs >> 8u);
return unpacked;
}
};
}

////////////////////
// IMPLEMENTATION //
////////////////////

template <typename extfuns_t> class module_gcd_machine_io_bound_8bit {
public:
struct state_t {
bits<1> gcd_busy;
bits<8> gcd_a;
bits<8> gcd_b;
bits<8> output_data;
bits<1> last_write_ack;

#ifndef SIM_MINIMAL
void dump(std::ostream& os = std::cout) const {
os << "gcd_busy = " << gcd_busy << std::endl;
os << "gcd_a = " << gcd_a << std::endl;
os << "gcd_b = " << gcd_b << std::endl;
os << "output_data = " << output_data << std::endl;
os << "last_write_ack = " << last_write_ack << std::endl;
}

static _unused void vcd_header(std::ostream& os) {
#ifndef SIM_VCD_SCOPES
#define SIM_VCD_SCOPES { "TOP", "gcd_machine_io_bound_8bit" }
#endif
cuttlesim::vcd::begin_header(os, SIM_VCD_SCOPES);
cuttlesim::vcd::var(os, "gcd_busy", 1);
cuttlesim::vcd::var(os, "gcd_a", 8);
cuttlesim::vcd::var(os, "gcd_b", 8);
cuttlesim::vcd::var(os, "output_data", 8);
cuttlesim::vcd::var(os, "last_write_ack", 1);
cuttlesim::vcd::end_header(os, SIM_VCD_SCOPES);
}

void vcd_dumpvars(std::uint_fast64_t cycle_id, _unused std::ostream& os, const state_t& previous, const bool force) const {
os << '#' << cycle_id << std::endl;
cuttlesim::vcd::dumpvar(os, "gcd_busy", gcd_busy, previous.gcd_busy, force);
cuttlesim::vcd::dumpvar(os, "gcd_a", gcd_a, previous.gcd_a, force);
cuttlesim::vcd::dumpvar(os, "gcd_b", gcd_b, previous.gcd_b, force);
cuttlesim::vcd::dumpvar(os, "output_data", output_data, previous.output_data, force);
cuttlesim::vcd::dumpvar(os, "last_write_ack", last_write_ack, previous.last_write_ack, force);
}

std::uint_fast64_t vcd_readvars(_unused std::istream& is) {
std::string var{}, val{};
std::uint_fast64_t cycle_id = std::numeric_limits<std::uint_fast64_t>::max();
cuttlesim::vcd::read_header(is);
while (cuttlesim::vcd::readvar(is, cycle_id, var, val)) {
if (var == "gcd_busy") {
gcd_busy = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "gcd_a") {
gcd_a = prims::unpack<bits<8>>(bits<8>::of_str(val));
}
else if (var == "gcd_b") {
gcd_b = prims::unpack<bits<8>>(bits<8>::of_str(val));
}
else if (var == "output_data") {
output_data = prims::unpack<bits<8>>(bits<8>::of_str(val));
}
else if (var == "last_write_ack") {
last_write_ack = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
}
return cycle_id;
}
#endif
};

using snapshot_t = cuttlesim::snapshot_t<state_t>;

protected:
struct rwset_t {
cuttlesim::ehr_rwset gcd_busy;
cuttlesim::ehr_rwset gcd_a;
cuttlesim::ehr_rwset gcd_b;
};

struct log_t {
rwset_t rwset;
state_t state;

const state_t& snapshot() const {
return state;
}
explicit log_t(const state_t& init) : rwset{}, state(init) {
}
};

log_t log;
log_t Log;
extfuns_t extfuns;
cuttlesim::sim_metadata meta;

#ifndef SIM_MINIMAL
std::default_random_engine rng{};
std::uniform_int_distribution<int> uniform{0, 3};
#endif

#define RULE_NAME get_result
DEF_RESET(get_result) {
log.state.gcd_busy = Log.state.gcd_busy;
log.state.output_data = Log.state.output_data;
log.rwset.gcd_busy = Log.rwset.gcd_busy;
log.rwset.gcd_a = Log.rwset.gcd_a;
log.rwset.gcd_b = Log.rwset.gcd_b;
}

DEF_COMMIT(get_result) {
Log.state.gcd_busy = log.state.gcd_busy;
Log.state.output_data = log.state.output_data;
Log.rwset.gcd_busy = log.rwset.gcd_busy;
Log.rwset.gcd_a = log.rwset.gcd_a;
Log.rwset.gcd_b = log.rwset.gcd_b;
}

DEF_RULE(get_result) {
bits<8> _x0 = READ1(gcd_a);
bits<1> _y1 = READ0(gcd_busy);
if (((_x0 == 8'00000000_b) & _y1)) {
WRITE0(gcd_busy, 1'0_b);
bits<8> _v1 = READ1(gcd_b);
WRITE0_FAST(output_data, _v1);
}
else {
FAIL_FAST();
}

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME get_output
DEF_RESET(get_output) {
log.state.last_write_ack = Log.state.last_write_ack;
log.rwset.gcd_busy = Log.rwset.gcd_busy;
}

DEF_COMMIT(get_output) {
Log.state.last_write_ack = log.state.last_write_ack;
Log.rwset.gcd_busy = log.rwset.gcd_busy;
}

DEF_RULE(get_output) {
bits<8> _x0 = READ1_FAST(output_data);
bits<1> ack = extfuns.out_data(_x0);
bits<1> _x1 = READ1(gcd_busy);
bits<1> busy = extfuns.out_busy(_x1);
WRITE0_FAST(last_write_ack, (ack + busy));

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME start
DEF_RESET(start) {
log.state.gcd_busy = Log.state.gcd_busy;
log.state.gcd_a = Log.state.gcd_a;
log.state.gcd_b = Log.state.gcd_b;
log.rwset.gcd_busy = Log.rwset.gcd_busy;
log.rwset.gcd_a = Log.rwset.gcd_a;
log.rwset.gcd_b = Log.rwset.gcd_b;
}

DEF_COMMIT(start) {
Log.state.gcd_busy = log.state.gcd_busy;
Log.state.gcd_a = log.state.gcd_a;
Log.state.gcd_b = log.state.gcd_b;
Log.rwset.gcd_busy = log.rwset.gcd_busy;
Log.rwset.gcd_a = log.rwset.gcd_a;
Log.rwset.gcd_b = log.rwset.gcd_b;
}

DEF_RULE(start) {
struct_pair in_data = extfuns.input_data(1'1_b);
bits<1> in_valid = extfuns.input_valid(1'1_b);
bits<1> _x2 = READ0(gcd_busy);
if (((in_valid == 1'1_b) & ~(_x2))) {
WRITE0(gcd_a, in_data.a);
WRITE0(gcd_b, in_data.b);
WRITE0(gcd_busy, 1'1_b);
}
else {
FAIL_FAST();
}

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME step_compute
DEF_RESET(step_compute) {
log.state.gcd_a = Log.state.gcd_a;
log.state.gcd_b = Log.state.gcd_b;
log.rwset.gcd_a = Log.rwset.gcd_a;
log.rwset.gcd_b = Log.rwset.gcd_b;
}

DEF_COMMIT(step_compute) {
Log.state.gcd_a = log.state.gcd_a;
Log.state.gcd_b = log.state.gcd_b;
Log.rwset.gcd_a = log.rwset.gcd_a;
Log.rwset.gcd_b = log.rwset.gcd_b;
}

DEF_RULE(step_compute) {
bits<8> a = READ0(gcd_a);
bits<8> b = READ0(gcd_b);
if ((a != 8'00000000_b)) {
if ((a <= b)) {
WRITE0(gcd_b, a);
WRITE0(gcd_a, b);
}
else {
WRITE0(gcd_a, (a - b));
}
}
else {
FAIL_FAST();
}

COMMIT();
}
#undef RULE_NAME

#ifdef SIM_FUZZER
using assert_pred_t = bool(*)(const module_gcd_machine_io_bound_8bit&);
assert_pred_t assert_pred = nullptr;
assert_pred_t assert_pred_final = nullptr;
std::vector<snapshot_t> snapshot_history;

#endif

public:
void finish(cuttlesim::exit_info exit_config, int exit_code) {
meta.finished = true;
meta.exit_config = exit_config;
meta.exit_code = exit_code;
}

bool finished() {
return meta.finished;
}

snapshot_t snapshot() const {
return snapshot_t(Log.snapshot(), meta);
}

static constexpr state_t initial_state() {
state_t init {
.gcd_busy = 1'0_b,
.gcd_a = 8'00000000_b,
.gcd_b = 8'00000000_b,
.output_data = 8'00000000_b,
.last_write_ack = 1'0_b,
};
return init;
}

explicit module_gcd_machine_io_bound_8bit(const state_t init = initial_state()) : log(init), Log(init), extfuns{}, meta{} {
#ifndef SIM_MINIMAL
rng.seed(cuttlesim::random_seed);
#endif
}

_virtual void strobe() const {}

void cycle() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
rule_start();
rule_step_compute();
rule_get_result();
rule_get_output();
strobe();
}

_flatten module_gcd_machine_io_bound_8bit& run(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
}
return *this;
}

#ifndef SIM_MINIMAL
typedef bool (module_gcd_machine_io_bound_8bit::*rule_ptr)();
void cycle_randomized() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
static constexpr rule_ptr rules[4] {
&module_gcd_machine_io_bound_8bit::rule_get_result,
&module_gcd_machine_io_bound_8bit::rule_get_output,
&module_gcd_machine_io_bound_8bit::rule_start,
&module_gcd_machine_io_bound_8bit::rule_step_compute};
(this->*rules[uniform(rng)])();
strobe();
}

_flatten module_gcd_machine_io_bound_8bit& run_randomized(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
}
return *this;
}

_flatten module_gcd_machine_io_bound_8bit& trace(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}

_flatten module_gcd_machine_io_bound_8bit& trace_randomized(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}
#endif
#ifdef SIM_FUZZER
void clear_snapshots() {
snapshot_history.clear();
}

const std::vector<snapshot_t>& get_snapshots() const {
return snapshot_history;
}

_flatten module_gcd_machine_io_bound_8bit& run_fuzz(std::uint_fast64_t ncycles, bool abort_on_failure) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();

snapshot_history.push_back(snapshot());
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
if (!cuttlesim::fuzz::check_pred(*this, assert_pred_final, abort_on_failure)) { 
return *this;
}
return *this;
}

_flatten module_gcd_machine_io_bound_8bit& run_trace_until_fail(std::string fname, std::uint_fast64_t ncycles, bool abort_on_failure) {
clear_snapshots();
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
snapshot_history.push_back(snapshot());
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
return *this;
}
void set_assert_pred(assert_pred_t p) {
assert_pred = p;
}

void clear_assert_pred() {
assert_pred = nullptr;
}

void set_assert_pred_final(assert_pred_t p) {
assert_pred_final = p;
}

void clear_assert_pred_final() {
assert_pred_final = nullptr;
}

#endif
};

#endif
