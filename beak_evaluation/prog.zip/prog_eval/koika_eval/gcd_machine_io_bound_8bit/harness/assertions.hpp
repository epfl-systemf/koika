#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


#include <cstddef>

// template <typename sim_t>
// inline bool assert_fn(const sim_t& sim) {

//   return true;
// }

struct assertion_monitor_t {
  bool in_flight = false;
  std::size_t start_idx = 0;
  std::size_t snap_idx = 0;
  bool have_prev = false;
  bool prev_busy = false;

  static constexpr std::size_t MAX_LATENCY = 65536; 

  void reset() { *this = {}; }
};

inline assertion_monitor_t& assertion_monitor() {
  static assertion_monitor_t mon;
  return mon;
}

inline void reset_assertion_monitor() {
  assertion_monitor().reset();
}

template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {
  auto& mon = assertion_monitor();
  const auto& curr = sim.snapshot().state;

  if (!mon.have_prev) {
    mon.prev_busy = curr.gcd_busy.v;
    mon.have_prev = true;
    mon.snap_idx = 0;
    return true;
  }

  ++mon.snap_idx;

  if (!mon.in_flight && !mon.prev_busy && curr.gcd_busy.v) {
    mon.in_flight = true;
    mon.start_idx = mon.snap_idx;
  }

  if (mon.in_flight && !curr.gcd_busy.v) {
    mon.in_flight = false;
  }

  if (mon.in_flight && (mon.snap_idx - mon.start_idx > assertion_monitor_t::MAX_LATENCY)) {
    return false;
  }

  mon.prev_busy = curr.gcd_busy.v;
  return true;
}

// template <typename sim_t>
// inline bool assert_final(const sim_t& sim) {
//   const auto& h = sim.get_snapshots();
//   if (h.empty()) return true;

//   constexpr std::size_t MAX_LATENCY = 65536; // adjust for your FSM overhead

//   bool in_flight = false;
//   std::size_t start_idx = 0;

//   for (std::size_t i = 1; i < h.size(); ++i) {
//     const auto& prev = h[i - 1].state;
//     const auto& curr = h[i].state;

//     // Start of a new computation
//     if (!in_flight && !prev.gcd_busy.v && curr.gcd_busy.v) {
//       in_flight = true;
//       start_idx = i;
//     }

//     // Completion
//     if (in_flight && !curr.gcd_busy.v) {
//       in_flight = false;
//     }

//     // Timeout
//     if (in_flight && (i - start_idx > MAX_LATENCY)) {
//       return false;
//     }
//   }

//   return true;
// }


template <typename sim_t>
inline bool assert_final(const sim_t& sim) {
  

  return true;
}

#endif