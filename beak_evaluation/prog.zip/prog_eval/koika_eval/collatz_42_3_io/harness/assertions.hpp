#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {
  auto& out_data_q1  = harness::extfuns_impl::out_data1_chan.q_assert;
  auto& out_data_q2  = harness::extfuns_impl::out_data2_chan.q_assert;

  if (out_data_q1.size() < 1 || out_data_q2.size() < 1) {
    return true; // not enough history to check, so just pass
  }

  auto bef_div = out_data_q1.back().v;
  auto after_div = out_data_q2.back().v; 

  
  return !(bef_div == 42 && after_div == 3);
}


template <typename sim_t>
inline bool assert_final(const sim_t& sim) {

  return true;
}

#endif