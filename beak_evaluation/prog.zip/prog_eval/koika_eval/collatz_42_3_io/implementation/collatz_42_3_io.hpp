#ifndef MODULE_COLLATZ_42_3_IO_HPP
#define MODULE_COLLATZ_42_3_IO_HPP

//////////////
// PREAMBLE //
//////////////

#include "cuttlesim.hpp"
#include <cstdlib>

//////////////
// TYPEDEFS //
//////////////




namespace prims {
#ifndef SIM_MINIMAL
#endif

}

////////////////////
// IMPLEMENTATION //
////////////////////

template <typename extfuns_t> class module_collatz_42_3_io {
public:
struct state_t {
bits<16> r0;
bits<16> last_write_ack;

#ifndef SIM_MINIMAL
void dump(std::ostream& os = std::cout) const {
os << "r0 = " << r0 << std::endl;
os << "last_write_ack = " << last_write_ack << std::endl;
}

static _unused void vcd_header(std::ostream& os) {
#ifndef SIM_VCD_SCOPES
#define SIM_VCD_SCOPES { "TOP", "collatz_42_3_io" }
#endif
cuttlesim::vcd::begin_header(os, SIM_VCD_SCOPES);
cuttlesim::vcd::var(os, "r0", 16);
cuttlesim::vcd::var(os, "last_write_ack", 16);
cuttlesim::vcd::end_header(os, SIM_VCD_SCOPES);
}

void vcd_dumpvars(std::uint_fast64_t cycle_id, _unused std::ostream& os, const state_t& previous, const bool force) const {
os << '#' << cycle_id << std::endl;
cuttlesim::vcd::dumpvar(os, "r0", r0, previous.r0, force);
cuttlesim::vcd::dumpvar(os, "last_write_ack", last_write_ack, previous.last_write_ack, force);
}

std::uint_fast64_t vcd_readvars(_unused std::istream& is) {
std::string var{}, val{};
std::uint_fast64_t cycle_id = std::numeric_limits<std::uint_fast64_t>::max();
cuttlesim::vcd::read_header(is);
while (cuttlesim::vcd::readvar(is, cycle_id, var, val)) {
if (var == "r0") {
r0 = prims::unpack<bits<16>>(bits<16>::of_str(val));
}
else if (var == "last_write_ack") {
last_write_ack = prims::unpack<bits<16>>(bits<16>::of_str(val));
}
}
return cycle_id;
}
#endif
};

using snapshot_t = cuttlesim::snapshot_t<state_t>;

protected:
struct rwset_t {
cuttlesim::reg_rwset last_write_ack;
};

struct log_t {
rwset_t rwset;
state_t state;

const state_t& snapshot() const {
return state;
}
explicit log_t(const state_t& init) : rwset{}, state(init) {
}
};

log_t log;
log_t Log;
extfuns_t extfuns;
cuttlesim::sim_metadata meta;

#ifndef SIM_MINIMAL
std::default_random_engine rng{};
std::uniform_int_distribution<int> uniform{0, 3};
#endif

#define RULE_NAME get_output_bef_div
DEF_RESET(get_output_bef_div) {
log.state.last_write_ack = Log.state.last_write_ack;
log.rwset.last_write_ack = Log.rwset.last_write_ack;
}

DEF_COMMIT(get_output_bef_div) {
Log.state.last_write_ack = log.state.last_write_ack;
Log.rwset.last_write_ack = log.rwset.last_write_ack;
}

DEF_RULE(get_output_bef_div) {
bits<16> _x0 = READ0_FAST(r0);
bits<16> ack = extfuns.out_data1(_x0);
WRITE0(last_write_ack, ack);

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME get_output_aft_div
DEF_RESET(get_output_aft_div) {
log.state.last_write_ack = Log.state.last_write_ack;
log.rwset.last_write_ack = Log.rwset.last_write_ack;
}

DEF_COMMIT(get_output_aft_div) {
Log.state.last_write_ack = log.state.last_write_ack;
Log.rwset.last_write_ack = log.rwset.last_write_ack;
}

DEF_RULE(get_output_aft_div) {
bits<16> _x0 = READ1_FAST(r0);
bits<16> ack = extfuns.out_data2(_x0);
WRITE0(last_write_ack, ack);

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME divide
DEF_RESET(divide) {
log.state.r0 = Log.state.r0;
}

DEF_COMMIT(divide) {
Log.state.r0 = log.state.r0;
}

DEF_RULE(divide) {
bits<16> v = READ0_FAST(r0);
bits<16> n42 = 0x16'2a_x;
bits<16> n3 = 0x16'03_x;
bits<1> odd = v[4'0000_b];
if ((v == n42)) {
WRITE0_FAST(r0, n3);
}
else {
if (~(odd)) {
WRITE0_FAST(r0, (v >> 1'1_b));
}
else {
FAIL_FAST();
}
}

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME multiply
DEF_RESET(multiply) {
log.state.r0 = Log.state.r0;
}

DEF_COMMIT(multiply) {
Log.state.r0 = log.state.r0;
}

DECL_FN(times_three_0, bits<16>)
DEF_FN(times_three_0, bits<16> &_ret, bits<16> bs) {
_ret = ((bs << 1'1_b) + bs);
return true;
}
DEF_RULE(multiply) {
bits<16> v = READ1_FAST(r0);
bits<1> odd = v[4'0000_b];
if (odd) {
bits<16> _v0 = CALL_FN(times_three_0, v);
WRITE1_FAST(r0, (_v0 + 16'1_b));
}
else {
FAIL_FAST();
}

COMMIT();
}
#undef RULE_NAME

#ifdef SIM_FUZZER
using assert_pred_t = bool(*)(const module_collatz_42_3_io&);
assert_pred_t assert_pred = nullptr;
assert_pred_t assert_pred_final = nullptr;
std::vector<snapshot_t> snapshot_history;

#endif

public:
void finish(cuttlesim::exit_info exit_config, int exit_code) {
meta.finished = true;
meta.exit_config = exit_config;
meta.exit_code = exit_code;
}

bool finished() {
return meta.finished;
}

snapshot_t snapshot() const {
return snapshot_t(Log.snapshot(), meta);
}

static constexpr state_t initial_state() {
state_t init {
.r0 = 0x16'12_x,
.last_write_ack = 16'0_b,
};
return init;
}

explicit module_collatz_42_3_io(const state_t init = initial_state()) : log(init), Log(init), extfuns{}, meta{} {
#ifndef SIM_MINIMAL
rng.seed(cuttlesim::random_seed);
#endif
}

_virtual void strobe() const {}

void cycle() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
rule_get_output_bef_div();
rule_divide();
rule_get_output_aft_div();
rule_multiply();
strobe();
}

_flatten module_collatz_42_3_io& run(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
}
return *this;
}

#ifndef SIM_MINIMAL
typedef bool (module_collatz_42_3_io::*rule_ptr)();
void cycle_randomized() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
static constexpr rule_ptr rules[4] {
&module_collatz_42_3_io::rule_get_output_bef_div,
&module_collatz_42_3_io::rule_get_output_aft_div,
&module_collatz_42_3_io::rule_divide,
&module_collatz_42_3_io::rule_multiply};
(this->*rules[uniform(rng)])();
strobe();
}

_flatten module_collatz_42_3_io& run_randomized(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
}
return *this;
}

_flatten module_collatz_42_3_io& trace(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}

_flatten module_collatz_42_3_io& trace_randomized(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}
#endif
#ifdef SIM_FUZZER
void clear_snapshots() {
snapshot_history.clear();
}

const std::vector<snapshot_t>& get_snapshots() const {
return snapshot_history;
}

_flatten module_collatz_42_3_io& run_fuzz(std::uint_fast64_t ncycles, bool abort_on_failure) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();

snapshot_history.push_back(snapshot());
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
if (!cuttlesim::fuzz::check_pred(*this, assert_pred_final, abort_on_failure)) { 
return *this;
}
return *this;
}

_flatten module_collatz_42_3_io& run_trace_until_fail(std::string fname, std::uint_fast64_t ncycles, bool abort_on_failure) {
clear_snapshots();
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
snapshot_history.push_back(snapshot());
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
return *this;
}
void set_assert_pred(assert_pred_t p) {
assert_pred = p;
}

void clear_assert_pred() {
assert_pred = nullptr;
}

void set_assert_pred_final(assert_pred_t p) {
assert_pred_final = p;
}

void clear_assert_pred_final() {
assert_pred_final = nullptr;
}

#endif
};

#endif
