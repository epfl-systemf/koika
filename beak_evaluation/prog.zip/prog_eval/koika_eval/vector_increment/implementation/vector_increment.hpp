#ifndef MODULE_VECTOR_INCREMENT_HPP
#define MODULE_VECTOR_INCREMENT_HPP

//////////////
// PREAMBLE //
//////////////

#include "cuttlesim.hpp"
#include <cstdlib>

//////////////
// TYPEDEFS //
//////////////




namespace prims {
#ifndef SIM_MINIMAL
#endif

}

////////////////////
// IMPLEMENTATION //
////////////////////

template <typename extfuns_t> class module_vector_increment {
public:
struct state_t {
bits<4> rIndex;
bits<32> rData_0;
bits<32> rData_1;
bits<32> rData_2;
bits<32> rData_3;
bits<32> rData_4;
bits<32> rData_5;
bits<32> rData_6;
bits<32> rData_7;
bits<32> rData_8;
bits<32> rData_9;
bits<32> rData_10;
bits<32> rData_11;
bits<32> rData_12;
bits<32> rData_13;
bits<32> rData_14;
bits<32> rData_15;
bits<32> rOutput;

#ifndef SIM_MINIMAL
void dump(std::ostream& os = std::cout) const {
os << "rIndex = " << rIndex << std::endl;
os << "rData_0 = " << rData_0 << std::endl;
os << "rData_1 = " << rData_1 << std::endl;
os << "rData_2 = " << rData_2 << std::endl;
os << "rData_3 = " << rData_3 << std::endl;
os << "rData_4 = " << rData_4 << std::endl;
os << "rData_5 = " << rData_5 << std::endl;
os << "rData_6 = " << rData_6 << std::endl;
os << "rData_7 = " << rData_7 << std::endl;
os << "rData_8 = " << rData_8 << std::endl;
os << "rData_9 = " << rData_9 << std::endl;
os << "rData_10 = " << rData_10 << std::endl;
os << "rData_11 = " << rData_11 << std::endl;
os << "rData_12 = " << rData_12 << std::endl;
os << "rData_13 = " << rData_13 << std::endl;
os << "rData_14 = " << rData_14 << std::endl;
os << "rData_15 = " << rData_15 << std::endl;
os << "rOutput = " << rOutput << std::endl;
}

static _unused void vcd_header(std::ostream& os) {
#ifndef SIM_VCD_SCOPES
#define SIM_VCD_SCOPES { "TOP", "vector_increment" }
#endif
cuttlesim::vcd::begin_header(os, SIM_VCD_SCOPES);
cuttlesim::vcd::var(os, "rIndex", 4);
cuttlesim::vcd::var(os, "rData_0", 32);
cuttlesim::vcd::var(os, "rData_1", 32);
cuttlesim::vcd::var(os, "rData_2", 32);
cuttlesim::vcd::var(os, "rData_3", 32);
cuttlesim::vcd::var(os, "rData_4", 32);
cuttlesim::vcd::var(os, "rData_5", 32);
cuttlesim::vcd::var(os, "rData_6", 32);
cuttlesim::vcd::var(os, "rData_7", 32);
cuttlesim::vcd::var(os, "rData_8", 32);
cuttlesim::vcd::var(os, "rData_9", 32);
cuttlesim::vcd::var(os, "rData_10", 32);
cuttlesim::vcd::var(os, "rData_11", 32);
cuttlesim::vcd::var(os, "rData_12", 32);
cuttlesim::vcd::var(os, "rData_13", 32);
cuttlesim::vcd::var(os, "rData_14", 32);
cuttlesim::vcd::var(os, "rData_15", 32);
cuttlesim::vcd::var(os, "rOutput", 32);
cuttlesim::vcd::end_header(os, SIM_VCD_SCOPES);
}

void vcd_dumpvars(std::uint_fast64_t cycle_id, _unused std::ostream& os, const state_t& previous, const bool force) const {
os << '#' << cycle_id << std::endl;
cuttlesim::vcd::dumpvar(os, "rIndex", rIndex, previous.rIndex, force);
cuttlesim::vcd::dumpvar(os, "rData_0", rData_0, previous.rData_0, force);
cuttlesim::vcd::dumpvar(os, "rData_1", rData_1, previous.rData_1, force);
cuttlesim::vcd::dumpvar(os, "rData_2", rData_2, previous.rData_2, force);
cuttlesim::vcd::dumpvar(os, "rData_3", rData_3, previous.rData_3, force);
cuttlesim::vcd::dumpvar(os, "rData_4", rData_4, previous.rData_4, force);
cuttlesim::vcd::dumpvar(os, "rData_5", rData_5, previous.rData_5, force);
cuttlesim::vcd::dumpvar(os, "rData_6", rData_6, previous.rData_6, force);
cuttlesim::vcd::dumpvar(os, "rData_7", rData_7, previous.rData_7, force);
cuttlesim::vcd::dumpvar(os, "rData_8", rData_8, previous.rData_8, force);
cuttlesim::vcd::dumpvar(os, "rData_9", rData_9, previous.rData_9, force);
cuttlesim::vcd::dumpvar(os, "rData_10", rData_10, previous.rData_10, force);
cuttlesim::vcd::dumpvar(os, "rData_11", rData_11, previous.rData_11, force);
cuttlesim::vcd::dumpvar(os, "rData_12", rData_12, previous.rData_12, force);
cuttlesim::vcd::dumpvar(os, "rData_13", rData_13, previous.rData_13, force);
cuttlesim::vcd::dumpvar(os, "rData_14", rData_14, previous.rData_14, force);
cuttlesim::vcd::dumpvar(os, "rData_15", rData_15, previous.rData_15, force);
cuttlesim::vcd::dumpvar(os, "rOutput", rOutput, previous.rOutput, force);
}

std::uint_fast64_t vcd_readvars(_unused std::istream& is) {
std::string var{}, val{};
std::uint_fast64_t cycle_id = std::numeric_limits<std::uint_fast64_t>::max();
cuttlesim::vcd::read_header(is);
while (cuttlesim::vcd::readvar(is, cycle_id, var, val)) {
if (var == "rIndex") {
rIndex = prims::unpack<bits<4>>(bits<4>::of_str(val));
}
else if (var == "rData_0") {
rData_0 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_1") {
rData_1 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_2") {
rData_2 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_3") {
rData_3 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_4") {
rData_4 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_5") {
rData_5 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_6") {
rData_6 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_7") {
rData_7 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_8") {
rData_8 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_9") {
rData_9 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_10") {
rData_10 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_11") {
rData_11 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_12") {
rData_12 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_13") {
rData_13 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_14") {
rData_14 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rData_15") {
rData_15 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rOutput") {
rOutput = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
}
return cycle_id;
}
#endif
};

using snapshot_t = cuttlesim::snapshot_t<state_t>;

protected:
struct rwset_t {
cuttlesim::ehr_rwset rOutput;
};

struct log_t {
rwset_t rwset;
state_t state;

const state_t& snapshot() const {
return state;
}
explicit log_t(const state_t& init) : rwset{}, state(init) {
}
};

log_t log;
log_t Log;
extfuns_t extfuns;
cuttlesim::sim_metadata meta;

#ifndef SIM_MINIMAL
std::default_random_engine rng{};
std::uniform_int_distribution<int> uniform{0, 2};
#endif

#define RULE_NAME incr_index
DEF_RESET(incr_index) {
log.state.rIndex = Log.state.rIndex;
}

DEF_COMMIT(incr_index) {
Log.state.rIndex = log.state.rIndex;
}

DEF_RULE(incr_index) {
bits<4> _v0 = READ0_FAST(rIndex);
WRITE0_FAST(rIndex, (_v0 + 4'0001_b));

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME read_reg_sequential
DEF_RESET(read_reg_sequential) {
log.state.rOutput = Log.state.rOutput;
log.rwset.rOutput = Log.rwset.rOutput;
}

DEF_COMMIT(read_reg_sequential) {
Log.state.rOutput = log.state.rOutput;
Log.rwset.rOutput = log.rwset.rOutput;
}

DEF_RULE(read_reg_sequential) {
bits<4> v = READ0_FAST(rIndex);
v = (v + 4'0001_b);
bits<32> _v0;
/* bind */ {
bits<32> tmp = bits<32>{};
if ((v == 4'0000_b)) {
tmp = READ0_FAST(rData_0);
}
if ((v == 4'0001_b)) {
tmp = READ0_FAST(rData_1);
}
if ((v == 4'0010_b)) {
tmp = READ0_FAST(rData_2);
}
if ((v == 4'0011_b)) {
tmp = READ0_FAST(rData_3);
}
if ((v == 4'0100_b)) {
tmp = READ0_FAST(rData_4);
}
if ((v == 4'0101_b)) {
tmp = READ0_FAST(rData_5);
}
if ((v == 4'0110_b)) {
tmp = READ0_FAST(rData_6);
}
if ((v == 4'0111_b)) {
tmp = READ0_FAST(rData_7);
}
if ((v == 4'1000_b)) {
tmp = READ0_FAST(rData_8);
}
if ((v == 4'1001_b)) {
tmp = READ0_FAST(rData_9);
}
if ((v == 4'1010_b)) {
tmp = READ0_FAST(rData_10);
}
if ((v == 4'1011_b)) {
tmp = READ0_FAST(rData_11);
}
if ((v == 4'1100_b)) {
tmp = READ0_FAST(rData_12);
}
if ((v == 4'1101_b)) {
tmp = READ0_FAST(rData_13);
}
if ((v == 4'1110_b)) {
tmp = READ0_FAST(rData_14);
}
if ((v == 4'1111_b)) {
tmp = READ0_FAST(rData_15);
}
_v0 = tmp;
}
WRITE1(rOutput, _v0);

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME read_reg_tree
DEF_RESET(read_reg_tree) {
log.state.rOutput = Log.state.rOutput;
log.rwset.rOutput = Log.rwset.rOutput;
}

DEF_COMMIT(read_reg_tree) {
Log.state.rOutput = log.state.rOutput;
Log.rwset.rOutput = log.rwset.rOutput;
}

DEF_RULE(read_reg_tree) {
bits<4> v = READ0_FAST(rIndex);
v = (v + 4'0001_b);
bits<32> _v0;
if (v[2'00_b]) {
if (v[2'01_b]) {
if (v[2'10_b]) {
if (v[2'11_b]) {
_v0 = READ0_FAST(rData_15);
}
else {
_v0 = READ0_FAST(rData_7);
}
}
else {
if (v[2'11_b]) {
_v0 = READ0_FAST(rData_11);
}
else {
_v0 = READ0_FAST(rData_3);
}
}
}
else {
if (v[2'10_b]) {
if (v[2'11_b]) {
_v0 = READ0_FAST(rData_13);
}
else {
_v0 = READ0_FAST(rData_5);
}
}
else {
if (v[2'11_b]) {
_v0 = READ0_FAST(rData_9);
}
else {
_v0 = READ0_FAST(rData_1);
}
}
}
}
else {
if (v[2'01_b]) {
if (v[2'10_b]) {
if (v[2'11_b]) {
_v0 = READ0_FAST(rData_14);
}
else {
_v0 = READ0_FAST(rData_6);
}
}
else {
if (v[2'11_b]) {
_v0 = READ0_FAST(rData_10);
}
else {
_v0 = READ0_FAST(rData_2);
}
}
}
else {
if (v[2'10_b]) {
if (v[2'11_b]) {
_v0 = READ0_FAST(rData_12);
}
else {
_v0 = READ0_FAST(rData_4);
}
}
else {
if (v[2'11_b]) {
_v0 = READ0_FAST(rData_8);
}
else {
_v0 = READ0_FAST(rData_0);
}
}
}
}
WRITE0(rOutput, _v0);

COMMIT();
}
#undef RULE_NAME

#ifdef SIM_FUZZER
using assert_pred_t = bool(*)(const module_vector_increment&);
assert_pred_t assert_pred = nullptr;
assert_pred_t assert_pred_final = nullptr;
std::vector<snapshot_t> snapshot_history;

#endif

public:
void finish(cuttlesim::exit_info exit_config, int exit_code) {
meta.finished = true;
meta.exit_config = exit_config;
meta.exit_code = exit_code;
}

bool finished() {
return meta.finished;
}

snapshot_t snapshot() const {
return snapshot_t(Log.snapshot(), meta);
}

static constexpr state_t initial_state() {
state_t init {
.rIndex = 4'0000_b,
.rData_0 = 32'0_b,
.rData_1 = 32'1_b,
.rData_2 = 0x32'0002_x,
.rData_3 = 0x32'0003_x,
.rData_4 = 0x32'0004_x,
.rData_5 = 0x32'0005_x,
.rData_6 = 0x32'0006_x,
.rData_7 = 0x32'0007_x,
.rData_8 = 0x32'0008_x,
.rData_9 = 0x32'0009_x,
.rData_10 = 0x32'000a_x,
.rData_11 = 0x32'000b_x,
.rData_12 = 0x32'000c_x,
.rData_13 = 0x32'000d_x,
.rData_14 = 0x32'000e_x,
.rData_15 = 0x32'000f_x,
.rOutput = 32'0_b,
};
return init;
}

explicit module_vector_increment(const state_t init = initial_state()) : log(init), Log(init), extfuns{}, meta{} {
#ifndef SIM_MINIMAL
rng.seed(cuttlesim::random_seed);
#endif
}

_virtual void strobe() const {}

void cycle() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
rule_read_reg_sequential();
rule_read_reg_tree();
rule_incr_index();
strobe();
}

_flatten module_vector_increment& run(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
}
return *this;
}

#ifndef SIM_MINIMAL
typedef bool (module_vector_increment::*rule_ptr)();
void cycle_randomized() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
static constexpr rule_ptr rules[3] {
&module_vector_increment::rule_incr_index,
&module_vector_increment::rule_read_reg_sequential,
&module_vector_increment::rule_read_reg_tree};
(this->*rules[uniform(rng)])();
strobe();
}

_flatten module_vector_increment& run_randomized(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
}
return *this;
}

_flatten module_vector_increment& trace(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}

_flatten module_vector_increment& trace_randomized(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}
#endif
#ifdef SIM_FUZZER
void clear_snapshots() {
snapshot_history.clear();
}

const std::vector<snapshot_t>& get_snapshots() const {
return snapshot_history;
}

_flatten module_vector_increment& run_fuzz(std::uint_fast64_t ncycles, bool abort_on_failure) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();

snapshot_history.push_back(snapshot());
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
if (!cuttlesim::fuzz::check_pred(*this, assert_pred_final, abort_on_failure)) { 
return *this;
}
return *this;
}

_flatten module_vector_increment& run_trace_until_fail(std::string fname, std::uint_fast64_t ncycles, bool abort_on_failure) {
clear_snapshots();
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
snapshot_history.push_back(snapshot());
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
return *this;
}
void set_assert_pred(assert_pred_t p) {
assert_pred = p;
}

void clear_assert_pred() {
assert_pred = nullptr;
}

void set_assert_pred_final(assert_pred_t p) {
assert_pred_final = p;
}

void clear_assert_pred_final() {
assert_pred_final = nullptr;
}

#endif
};

#endif
