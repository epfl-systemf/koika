#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {
return true; 
}

template <typename sim_t>
inline bool assert_final(const sim_t& sim) {
  auto& snap = sim.get_snapshots().back(); // get the latest snapshot
 uint16_t rIndex = snap.state.rIndex.v;
     uint32_t rData[16] = {
     static_cast<uint32_t>(snap.state.rData_0.v),
     static_cast<uint32_t>(snap.state.rData_1.v),
     static_cast<uint32_t>(snap.state.rData_2.v),
     static_cast<uint32_t>(snap.state.rData_3.v),
     static_cast<uint32_t>(snap.state.rData_4.v),
     static_cast<uint32_t>(snap.state.rData_5.v),
     static_cast<uint32_t>(snap.state.rData_6.v),
     static_cast<uint32_t>(snap.state.rData_7.v),
     static_cast<uint32_t>(snap.state.rData_8.v),
     static_cast<uint32_t>(snap.state.rData_9.v),
     static_cast<uint32_t>(snap.state.rData_10.v),
     static_cast<uint32_t>(snap.state.rData_11.v),
     static_cast<uint32_t>(snap.state.rData_12.v),
     static_cast<uint32_t>(snap.state.rData_13.v),
     static_cast<uint32_t>(snap.state.rData_14.v),
     static_cast<uint32_t>(snap.state.rData_15.v)
   };
    uint32_t rOutput = snap.state.rOutput.v;
     uint16_t idx = (rIndex == 0) ? 15 : (rIndex - 1) % 16;
    return rOutput == rData[idx]; // if output is not correct, check if it matches the expected value based on the index and data array
}

#endif