#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {
  auto state = sim.snapshot(); 
  return state.state.rf_x00_zero.v == 0; 
}


template <typename sim_t>
inline bool assert_final(const sim_t& sim) {

  return true;
}

#endif