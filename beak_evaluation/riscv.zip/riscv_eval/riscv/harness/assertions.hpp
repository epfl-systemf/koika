#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {
  const auto& st = sim.snapshot().state;
  if (!st.d2e_valid0) return true;

  const uint32_t inst = st.d2e_data0.dInst.inst.v;

  // This is what RVCore.v:getImmediateType matches on: inst[6:2]
  const uint8_t opcode5 = static_cast<uint8_t>((inst >> 2) & 0x1fu);

  const bool imm_valid = static_cast<bool>(st.d2e_data0.dInst.immediateType.valid);
  if (!imm_valid) return true;

  const enum_immType imm_kind = st.d2e_data0.dInst.immediateType.data;

  switch (opcode5) {
    case 0x00: // LOAD   (0x03 >> 2)
    case 0x04: // OP-IMM (0x13 >> 2)
    case 0x19: // JALR   (0x67 >> 2)
      return bool(imm_kind == enum_immType::ImmI);

    case 0x08: // STORE  (0x23 >> 2)
      return bool(imm_kind == enum_immType::ImmS);

    case 0x18: // BRANCH (0x63 >> 2)
      return bool(imm_kind == enum_immType::ImmB);

    case 0x05: // AUIPC  (0x17 >> 2)
    case 0x0D: // LUI    (0x37 >> 2)
      return bool(imm_kind == enum_immType::ImmU);

    case 0x1B: // JAL    (0x6F >> 2)
      return bool(imm_kind == enum_immType::ImmJ);

    default:
      // In RVCore.v, imm_valid would be false for these.
      return false;
  }
}


template <typename sim_t>
inline bool assert_final(const sim_t& sim) {

  return true;
}

#endif