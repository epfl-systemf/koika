#include <algorithm>
#include <array>
#include <cassert>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <string>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include "rv32_a.hpp"     // must define namespace rv32_a
#include "rv32_fifo_wedmf.hpp"   // must define namespace rv32_b

#include "harness_support.hpp"
#include "mem_support.hpp"
#include "filter_support_w_branch.hpp"

#define ALL_REGISTERS(X) \
   X(toIMem_data0, 68) \
   X(toIMem_valid0, 1) \
   X(fromIMem_data0, 68) \
   X(fromIMem_valid0, 1) \
   X(toDMem_data0, 68) \
   X(toDMem_valid0, 1) \
   X(fromDMem_data0, 68) \
   X(fromDMem_valid0, 1) \
   X(f2d_data0, 65) \
   X(f2d_valid0, 1) \
   X(f2dprim_data0, 65) \
   X(f2dprim_valid0, 1) \
   X(d2e_data0, 169) \
   X(d2e_valid0, 1) \
   X(e2w_data0, 77) \
   X(e2w_valid0, 1) \
   X(rf_x00_zero, 32) \
   X(rf_x01_ra, 32) \
   X(rf_x02_sp, 32) \
   X(rf_x03_gp, 32) \
   X(rf_x04_tp, 32) \
   X(rf_x05_t0, 32) \
   X(rf_x06_t1, 32) \
   X(rf_x07_t2, 32) \
   X(rf_x08_s0_fp, 32) \
   X(rf_x09_s1, 32) \
   X(rf_x10_a0, 32) \
   X(rf_x11_a1, 32) \
   X(rf_x12_a2, 32) \
   X(rf_x13_a3, 32) \
   X(rf_x14_a4, 32) \
   X(rf_x15_a5, 32) \
   X(rf_x16_a6, 32) \
   X(rf_x17_a7, 32) \
   X(rf_x18_s2, 32) \
   X(rf_x19_s3, 32) \
   X(rf_x20_s4, 32) \
   X(rf_x21_s5, 32) \
   X(rf_x22_s6, 32) \
   X(rf_x23_s7, 32) \
   X(rf_x24_s8, 32) \
   X(rf_x25_s9, 32) \
   X(rf_x26_s10, 32) \
   X(rf_x27_s11, 32) \
   X(rf_x28_t3, 32) \
   X(rf_x29_t4, 32) \
   X(rf_x30_t5, 32) \
   X(rf_x31_t6, 32) \
   X(mulState_valid, 1) \
   X(mulState_operand1, 32) \
   X(mulState_operand2, 32) \
   X(mulState_result, 64) \
   X(mulState_n_step, 5) \
   X(mulState_finished, 1) \
   X(scoreboard_x00_zero, 2) \
   X(scoreboard_x01_ra, 2) \
   X(scoreboard_x02_sp, 2) \
   X(scoreboard_x03_gp, 2) \
   X(scoreboard_x04_tp, 2) \
   X(scoreboard_x05_t0, 2) \
   X(scoreboard_x06_t1, 2) \
   X(scoreboard_x07_t2, 2) \
   X(scoreboard_x08_s0_fp, 2) \
   X(scoreboard_x09_s1, 2) \
   X(scoreboard_x10_a0, 2) \
   X(scoreboard_x11_a1, 2) \
   X(scoreboard_x12_a2, 2) \
   X(scoreboard_x13_a3, 2) \
   X(scoreboard_x14_a4, 2) \
   X(scoreboard_x15_a5, 2) \
   X(scoreboard_x16_a6, 2) \
   X(scoreboard_x17_a7, 2) \
   X(scoreboard_x18_s2, 2) \
   X(scoreboard_x19_s3, 2) \
   X(scoreboard_x20_s4, 2) \
   X(scoreboard_x21_s5, 2) \
   X(scoreboard_x22_s6, 2) \
   X(scoreboard_x23_s7, 2) \
   X(scoreboard_x24_s8, 2) \
   X(scoreboard_x25_s9, 2) \
   X(scoreboard_x26_s10, 2) \
   X(scoreboard_x27_s11, 2) \
   X(scoreboard_x28_t3, 2) \
   X(scoreboard_x29_t4, 2) \
   X(scoreboard_x30_t5, 2) \
   X(scoreboard_x31_t6, 2) \
   X(cycle_count, 32) \
   X(instr_count, 32) \
   X(pc, 32) \
   X(epoch, 1)

#include "diff_fuzz_support.hpp"

// ------------------------------------------------------------
// Common helpers
// ------------------------------------------------------------

namespace harness_common {

static std::string CrashLogPath = "";

static std::string decode_path_for(const char* input_path) {
  std::string in_path(input_path ? input_path : "");
  return in_path + "_decoded";
}

template <int BitWidth>
static prims::bits<BitWidth> pack_bits_from_bytes(const std::vector<uint8_t>& buf,
                                                  std::size_t offset,
                                                  std::size_t nbytes) {
  prims::bits<BitWidth> acc = prims::bits<BitWidth>::mk(0);

  for (std::size_t i = 0; i < nbytes; ++i) {
    const uint8_t byte = (offset + i < buf.size()) ? buf[offset + i] : 0;
    const auto b = prims::widen<BitWidth>(prims::bits<8>::mk(byte));
    acc = acc | (b << (8 * i));
  }

  return acc;
}

static void install_imem_program(const std::vector<uint8_t>& buf,
                                 std::size_t kEffectiveSeedPairs) {
  for (std::size_t i = 0; i < fuzz_mem::kImemWords; ++i) {
    fuzz_mem::imem_set_word(i, fuzz_filter::kNopInsn);
  }

  constexpr std::size_t total_bytes = 3; // -9 -8, so 5 bytes left ?  + -led -uart_write_bytes = 3 bytes left

  for (std::size_t i = 0; i < kEffectiveSeedPairs; ++i) {
    const std::size_t base_off = i * total_bytes;
    const std::size_t off = base_off + 2; // + 4

    if (i < fuzz_mem::kImemWords) {
      const uint32_t raw = fuzz_mem::load_u32_le_padded(buf, off);
      //const uint32_t instr = fuzz_filter::filter_to_straightline_u_imm(raw);
      const uint32_t instr = fuzz_filter::filter_to_straightline_u_imm_bounded(raw, i, kEffectiveSeedPairs);
      fuzz_mem::imem_set_word(i, instr);
    }
  }

  for (std::size_t i = 0; i < fuzz_filter::kTrailerWords; ++i) {
    fuzz_mem::imem_set_word(
        kEffectiveSeedPairs + i,
        fuzz_filter::finish_trailer_word(i)
    );
  }
}

} // namespace harness_common

// ------------------------------------------------------------
// Harness A: rv32_a
// ------------------------------------------------------------

#define EXT_INPUTS_A(X) \
   X(ext_mem_dmem, struct_mem_input, struct_mem_output) \
   X(ext_uart_write, struct_maybe_bits_8, bits<1>) \
   X(ext_uart_read, bits<1>, struct_maybe_bits_8) \
   X(ext_mem_imem, struct_mem_input, struct_mem_output) \
   X(ext_led, struct_maybe_bits_1, bits<1>)

#define EXT_OUTPUTS_A(X)

namespace harness_a {

struct extfuns_impl {
  EXT_INPUTS_A(HARNESS_DECL_INPUT_CHANNEL)
  EXT_OUTPUTS_A(HARNESS_DECL_OUTPUT_CHANNEL)

  diff_fuzz::dmem_t* active_dmem = nullptr;

  static void clear() {
    EXT_INPUTS_A(HARNESS_CLEAR_INPUT_CHANNEL)
    EXT_OUTPUTS_A(HARNESS_CLEAR_OUTPUT_CHANNEL)
  }

  auto ext_mem_dmem(struct_mem_input ready);
  auto ext_uart_write(struct_maybe_bits_8 ready);
  auto ext_uart_read(bits<1> ready);
  auto ext_mem_imem(struct_mem_input ready);
  auto ext_led(struct_maybe_bits_1 ready);

  template<typename simulator>
  bits<1> ext_finish(simulator& sim, struct_maybe_bits_8 req) {
    if (req.valid) {
      bits<8> exitcode = req.data;

      if (exitcode == 8'0_b) {
        std::printf("  \033[0;32mPASS A\033[0m\n");
      } else {
        std::printf("  \033[0;31mFAIL A\033[0m (%d)\n", exitcode.v);
      }

      sim.finish(cuttlesim::exit_info_none, exitcode.v);
    }

    return 1'0_b;
  }

  enum_hostID ext_host_id(bits<1>) {
    return enum_hostID::Cuttlesim;
  }
};

using extfuns_t = extfuns_impl;
using simulator = rv32_a::module_rv32<extfuns_t>;
using snapshot_t = simulator::snapshot_t;
using state_t = simulator::state_t;

#define DEF_INPUT_CHANNEL_A(name, width, storage) \
 input_channel_fifo<extfuns_impl::name##_stored_t> extfuns_impl::name##_chan;
EXT_INPUTS_A(DEF_INPUT_CHANNEL_A)
#undef DEF_INPUT_CHANNEL_A

#define DEF_OUTPUT_CHANNEL_A(name, width, storage) \
 output_channel_fifo<extfuns_impl::name##_stored_t> extfuns_impl::name##_chan;
EXT_OUTPUTS_A(DEF_OUTPUT_CHANNEL_A)
#undef DEF_OUTPUT_CHANNEL_A

inline auto extfuns_impl::ext_mem_dmem(struct_mem_input ready) {
  const bits<1> get_ready = ready.get_ready;
  const bits<1> put_valid = ready.put_valid;
  const struct_mem_req put_request = ready.put_request;

  const bits<4> put_request_byte_en = put_request.byte_en;
  const bits<32> put_request_addr = put_request.addr;
  const bits<32> put_request_data = put_request.data;

  const bool may_run =
      static_cast<bool>(get_ready) &&
      static_cast<bool>(put_valid);

  struct_mem_output resp{};

  if (may_run) {
    if (active_dmem == nullptr) {
      std::fprintf(stderr, "Internal harness A error: active_dmem is null\n");
      std::abort();
    }

    const uint32_t be = put_request_byte_en.v & 0xfu;
    const uint32_t addr = put_request_addr.v;

    if (be != 0) {
      const uint32_t data = put_request_data.v;
      diff_fuzz::dmem_store_masked(*active_dmem, addr, data, be);
    }

    const uint32_t data = diff_fuzz::dmem_load_word(*active_dmem, addr);

    resp.get_valid = bits<1>::mk(1);
    resp.put_ready = bits<1>::mk(1);

    resp.get_response.byte_en = put_request_byte_en;
    resp.get_response.addr = put_request_addr;
    resp.get_response.data = bits<32>::mk(data);
  }

  return resp;
}

inline auto extfuns_impl::ext_uart_write(struct_maybe_bits_8 ready) {
  return bits<1>::mk(1);
}

inline auto extfuns_impl::ext_uart_read(bits<1> ready) {
  if (!static_cast<bool>(ready)) {
    ext_uart_read_stored_t p{};
    p.valid = bits<1>::mk(0);
    p.data  = bits<8>::mk(0);
    return p;
  }

  return ext_uart_read_chan.pop_or_zero();
}

inline auto extfuns_impl::ext_mem_imem(struct_mem_input ready) {
  const bits<1> get_ready = ready.get_ready;
  const bits<1> put_valid = ready.put_valid;
  const struct_mem_req put_request = ready.put_request;

  const bool may_run =
      static_cast<bool>(get_ready) &&
      static_cast<bool>(put_valid);

  struct_mem_output resp{};

  if (may_run) {
    const uint32_t addr = put_request.addr.v;
    const uint32_t instr = fuzz_mem::imem_fetch(addr);

    resp.get_valid = bits<1>::mk(1);
    resp.put_ready = bits<1>::mk(1);

    resp.get_response.byte_en = bits<4>::mk(0xf);
    resp.get_response.addr = put_request.addr;
    resp.get_response.data = bits<32>::mk(instr);
  }

  return resp;
}

static bits<1> led_state = bits<1>::mk(0);

inline auto extfuns_impl::ext_led(struct_maybe_bits_1 ready) {
  if (static_cast<bool>(ready.valid)) {
    led_state = ready.data;
  }

  return led_state;
}

static void set_run_inputs(const std::vector<uint8_t>& buf,
                           std::size_t kEffectiveSeedPairs) {
  extfuns_impl::clear();

  //constexpr std::size_t ext_mem_dmem_bytes = 9;
  //constexpr std::size_t ext_uart_write_bytes = 1;
  constexpr std::size_t ext_uart_read_bytes = 2;
  //constexpr std::size_t ext_led_bytes = 1;
  constexpr std::size_t total_bytes = 3;

  for (std::size_t i = 0; i < kEffectiveSeedPairs; ++i) {
    const std::size_t base_off = i * total_bytes;

    // {
    //   const std::size_t off = base_off + 0; // can remove ? - 9 bytes
    //   prims::bits<72> safe_ext_mem_dmem =
    //       harness_common::pack_bits_from_bytes<72>(buf, off, ext_mem_dmem_bytes);

    //   extfuns_impl::ext_mem_dmem_chan.push(
    //       prims::unpack<struct_mem_output>(
    //           prims::truncate<70>(safe_ext_mem_dmem)));
    // }

    // {
    //   // const std::size_t off = base_off + 9;
    //   const std::size_t off = base_off + 0;
    //   prims::bits<8> safe_ext_uart_write =
    //       harness_common::pack_bits_from_bytes<8>(buf, off, ext_uart_write_bytes);

    //   extfuns_impl::ext_uart_write_chan.push(
    //       prims::truncate<1>(safe_ext_uart_write));
    // }

    {
      // const std::size_t off = base_off + 10;
      const std::size_t off = base_off + 0;
      prims::bits<16> safe_ext_uart_read =
          harness_common::pack_bits_from_bytes<16>(buf, off, ext_uart_read_bytes);

      extfuns_impl::ext_uart_read_chan.push(
          prims::unpack<struct_maybe_bits_8>(
              prims::truncate<9>(safe_ext_uart_read)));
    }

    // {
    //   // const std::size_t off = base_off + 21;
    //   const std::size_t off = base_off + 2;
    //   prims::bits<8> safe_ext_led =
    //       harness_common::pack_bits_from_bytes<8>(buf, off, ext_led_bytes);

    //   extfuns_impl::ext_led_chan.push(
    //       prims::truncate<1>(safe_ext_led));
    // }
  }
}

} // namespace harness_a

// ------------------------------------------------------------
// Harness B: rv32_b
// ------------------------------------------------------------

#define EXT_INPUTS_B(X) \
   X(ext_mem_dmem, struct_mem_input, struct_mem_output) \
   X(ext_uart_write, struct_maybe_bits_8, bits<1>) \
   X(ext_uart_read, bits<1>, struct_maybe_bits_8) \
   X(ext_mem_imem, struct_mem_input, struct_mem_output) \
   X(ext_led, struct_maybe_bits_1, bits<1>)

#define EXT_OUTPUTS_B(X)

namespace harness_b {

struct extfuns_impl {
  EXT_INPUTS_B(HARNESS_DECL_INPUT_CHANNEL)
  EXT_OUTPUTS_B(HARNESS_DECL_OUTPUT_CHANNEL)

  diff_fuzz::dmem_t* active_dmem = nullptr;

  static void clear() {
    EXT_INPUTS_B(HARNESS_CLEAR_INPUT_CHANNEL)
    EXT_OUTPUTS_B(HARNESS_CLEAR_OUTPUT_CHANNEL)
  }

  auto ext_mem_dmem(struct_mem_input ready);
  auto ext_uart_write(struct_maybe_bits_8 ready);
  auto ext_uart_read(bits<1> ready);
  auto ext_mem_imem(struct_mem_input ready);
  auto ext_led(struct_maybe_bits_1 ready);

  template<typename simulator>
  bits<1> ext_finish(simulator& sim, struct_maybe_bits_8 req) {
    if (req.valid) {
      bits<8> exitcode = req.data;

      if (exitcode == 8'0_b) {
        std::printf("  \033[0;32mPASS B\033[0m\n");
      } else {
        std::printf("  \033[0;31mFAIL B\033[0m (%d)\n", exitcode.v);
      }

      sim.finish(cuttlesim::exit_info_none, exitcode.v);
    }

    return 1'0_b;
  }

  enum_hostID ext_host_id(bits<1>) {
    return enum_hostID::Cuttlesim;
  }
};

using extfuns_t = extfuns_impl;
using simulator = rv32_b::module_rv32<extfuns_t>;
using snapshot_t = simulator::snapshot_t;
using state_t = simulator::state_t;

#define DEF_INPUT_CHANNEL_B(name, width, storage) \
 input_channel_fifo<extfuns_impl::name##_stored_t> extfuns_impl::name##_chan;
EXT_INPUTS_B(DEF_INPUT_CHANNEL_B)
#undef DEF_INPUT_CHANNEL_B

#define DEF_OUTPUT_CHANNEL_B(name, width, storage) \
 output_channel_fifo<extfuns_impl::name##_stored_t> extfuns_impl::name##_chan;
EXT_OUTPUTS_B(DEF_OUTPUT_CHANNEL_B)
#undef DEF_OUTPUT_CHANNEL_B

inline auto extfuns_impl::ext_mem_dmem(struct_mem_input ready) {
  const bits<1> get_ready = ready.get_ready;
  const bits<1> put_valid = ready.put_valid;
  const struct_mem_req put_request = ready.put_request;

  const bits<4> put_request_byte_en = put_request.byte_en;
  const bits<32> put_request_addr = put_request.addr;
  const bits<32> put_request_data = put_request.data;

  const bool may_run =
      static_cast<bool>(get_ready) &&
      static_cast<bool>(put_valid);

  struct_mem_output resp{};

  if (may_run) {
    if (active_dmem == nullptr) {
      std::fprintf(stderr, "Internal harness B error: active_dmem is null\n");
      std::abort();
    }

    const uint32_t be = put_request_byte_en.v & 0xfu;
    const uint32_t addr = put_request_addr.v;

    if (be != 0) {
      const uint32_t data = put_request_data.v;
      diff_fuzz::dmem_store_masked(*active_dmem, addr, data, be);
    }

    const uint32_t data = diff_fuzz::dmem_load_word(*active_dmem, addr);

    resp.get_valid = bits<1>::mk(1);
    resp.put_ready = bits<1>::mk(1);

    resp.get_response.byte_en = put_request_byte_en;
    resp.get_response.addr = put_request_addr;
    resp.get_response.data = bits<32>::mk(data);
  }

  return resp;
}

inline auto extfuns_impl::ext_uart_write(struct_maybe_bits_8 ready) {
  return bits<1>::mk(1);
}

inline auto extfuns_impl::ext_uart_read(bits<1> ready) {
  if (!static_cast<bool>(ready)) {
    ext_uart_read_stored_t p{};
    p.valid = bits<1>::mk(0);
    p.data  = bits<8>::mk(0);
    return p;
  }

  return ext_uart_read_chan.pop_or_zero();
}

inline auto extfuns_impl::ext_mem_imem(struct_mem_input ready) {
  const bits<1> get_ready = ready.get_ready;
  const bits<1> put_valid = ready.put_valid;
  const struct_mem_req put_request = ready.put_request;

  const bool may_run =
      static_cast<bool>(get_ready) &&
      static_cast<bool>(put_valid);

  struct_mem_output resp{};

  if (may_run) {
    const uint32_t addr = put_request.addr.v;
    const uint32_t instr = fuzz_mem::imem_fetch(addr);

    resp.get_valid = bits<1>::mk(1);
    resp.put_ready = bits<1>::mk(1);

    resp.get_response.byte_en = bits<4>::mk(0xf);
    resp.get_response.addr = put_request.addr;
    resp.get_response.data = bits<32>::mk(instr);
  }

  return resp;
}

static bits<1> led_state = bits<1>::mk(0);

inline auto extfuns_impl::ext_led(struct_maybe_bits_1 ready) {
  if (static_cast<bool>(ready.valid)) {
    led_state = ready.data;
  }

  return led_state;
}

static void set_run_inputs(const std::vector<uint8_t>& buf,
                           std::size_t kEffectiveSeedPairs) {
  extfuns_impl::clear();

  //constexpr std::size_t ext_mem_dmem_bytes = 0;
  //constexpr std::size_t ext_uart_write_bytes = 1;
  constexpr std::size_t ext_uart_read_bytes = 2;
  //constexpr std::size_t ext_led_bytes = 1;
  constexpr std::size_t total_bytes = 3; // here also decrease bytes ? 

  for (std::size_t i = 0; i < kEffectiveSeedPairs; ++i) {
    const std::size_t base_off = i * total_bytes;

    // {
    //   const std::size_t off = base_off + 0; // remove dmem ? 
    //   prims::bits<72> safe_ext_mem_dmem =
    //       harness_common::pack_bits_from_bytes<72>(buf, off, ext_mem_dmem_bytes);

    //   extfuns_impl::ext_mem_dmem_chan.push(
    //       prims::unpack<struct_mem_output>(
    //           prims::truncate<70>(safe_ext_mem_dmem)));
    // }

    // {
    //   // const std::size_t off = base_off + 9;
    //   const std::size_t off = base_off + 0;
    //   prims::bits<8> safe_ext_uart_write =
    //       harness_common::pack_bits_from_bytes<8>(buf, off, ext_uart_write_bytes);

    //   extfuns_impl::ext_uart_write_chan.push(
    //       prims::truncate<1>(safe_ext_uart_write));
    // }

    {
      // const std::size_t off = base_off + 10;
      const std::size_t off = base_off + 0;
      prims::bits<16> safe_ext_uart_read =
          harness_common::pack_bits_from_bytes<16>(buf, off, ext_uart_read_bytes);

      extfuns_impl::ext_uart_read_chan.push(
          prims::unpack<struct_maybe_bits_8>(
              prims::truncate<9>(safe_ext_uart_read)));
    }

    // {
    //   // const std::size_t off = base_off + 21;
    //   const std::size_t off = base_off + 3;
    //   prims::bits<8> safe_ext_led =
    //       harness_common::pack_bits_from_bytes<8>(buf, off, ext_led_bytes);

    //   extfuns_impl::ext_led_chan.push(
    //       prims::truncate<1>(safe_ext_led));
    // }
  }
}

} // namespace harness_b

// ------------------------------------------------------------
// Architectural comparison
// ------------------------------------------------------------

namespace arch_diff {

struct arch_result {
  std::array<uint32_t, 32> rf{};
  bool finished = false;
  int exit_code = 0;
  diff_fuzz::dmem_t dmem;
};

template <typename RunResultT>
static arch_result extract_arch_result(const RunResultT& run) {
  const auto& st = run.state;

  arch_result out{};

#define COPY_RF(idx, field) \
  out.rf[idx] = static_cast<uint32_t>(prims::pack(st.field).v)

  COPY_RF(0,  rf_x00_zero);
  COPY_RF(1,  rf_x01_ra);
  COPY_RF(2,  rf_x02_sp);
  COPY_RF(3,  rf_x03_gp);
  COPY_RF(4,  rf_x04_tp);
  COPY_RF(5,  rf_x05_t0);
  COPY_RF(6,  rf_x06_t1);
  COPY_RF(7,  rf_x07_t2);
  COPY_RF(8,  rf_x08_s0_fp);
  COPY_RF(9,  rf_x09_s1);
  COPY_RF(10, rf_x10_a0);
  COPY_RF(11, rf_x11_a1);
  COPY_RF(12, rf_x12_a2);
  COPY_RF(13, rf_x13_a3);
  COPY_RF(14, rf_x14_a4);
  COPY_RF(15, rf_x15_a5);
  COPY_RF(16, rf_x16_a6);
  COPY_RF(17, rf_x17_a7);
  COPY_RF(18, rf_x18_s2);
  COPY_RF(19, rf_x19_s3);
  COPY_RF(20, rf_x20_s4);
  COPY_RF(21, rf_x21_s5);
  COPY_RF(22, rf_x22_s6);
  COPY_RF(23, rf_x23_s7);
  COPY_RF(24, rf_x24_s8);
  COPY_RF(25, rf_x25_s9);
  COPY_RF(26, rf_x26_s10);
  COPY_RF(27, rf_x27_s11);
  COPY_RF(28, rf_x28_t3);
  COPY_RF(29, rf_x29_t4);
  COPY_RF(30, rf_x30_t5);
  COPY_RF(31, rf_x31_t6);

#undef COPY_RF

  out.finished = run.finished;
  out.exit_code = run.exit_code;
  out.dmem = run.dmem;

  return out;
}

static bool arch_results_equal(const arch_result& a,
                               const arch_result& b) {
  bool ok = true;

  if (a.finished != b.finished) {
    std::fprintf(stderr,
                 "Finish mismatch: a=%d b=%d\n",
                 static_cast<int>(a.finished),
                 static_cast<int>(b.finished));
    ok = false;
  }

  if (a.exit_code != b.exit_code) {
    std::fprintf(stderr,
                 "Exit-code mismatch: a=%d b=%d\n",
                 a.exit_code,
                 b.exit_code);
    ok = false;
  }

  for (std::size_t i = 0; i < 32; ++i) {
    if (a.rf[i] != b.rf[i]) {
      std::fprintf(stderr,
                   "RF mismatch: x%zu a=0x%08x b=0x%08x\n",
                   i,
                   a.rf[i],
                   b.rf[i]);
      ok = false;
    }
  }

  if (!diff_fuzz::dmem_equal(a.dmem, b.dmem)) {
    ok = false;
  }

  return ok;
}

static void dump_arch_result(FILE* out,
                             const char* label,
                             const arch_result& r) {
  std::fprintf(out, "=== %s architectural result ===\n", label);
  std::fprintf(out,
               "finished=%d exit_code=%d\n",
               static_cast<int>(r.finished),
               r.exit_code);

  for (std::size_t i = 0; i < 32; ++i) {
    std::fprintf(out, "x%02zu = 0x%08x\n", i, r.rf[i]);
  }
}

static void dump_arch_results_to_log(const std::string& path,
                                     const arch_result& a,
                                     const arch_result& b) {
  FILE* out = nullptr;

  if (!path.empty()) {
    out = std::fopen(path.c_str(), "a");
  }

  if (!out) {
    return;
  }

  dump_arch_result(out, "Core A", a);
  dump_arch_result(out, "Core B", b);

  std::fclose(out);
}

} // namespace arch_diff

#include "assertions.hpp"

// ------------------------------------------------------------
// Main
// ------------------------------------------------------------

int main(int argc, char** argv) {
  bool replay = false;
  const char* input_path = nullptr;

  if (argc == 3 && std::strcmp(argv[1], "--replay") == 0) {
    replay = true;
    input_path = argv[2];
  } else if (argc == 2) {
    input_path = argv[1];
  } else {
    std::fprintf(stderr, "Usage: %s [--replay] <input_file>\n", argv[0]);
    return 1;
  }

  FILE* f = std::fopen(input_path, "rb");
  if (!f) {
    std::fprintf(stderr, "Error: unable to open %s\n", input_path);
    return 1;
  }

  std::vector<uint8_t> buf;

  std::fseek(f, 0, SEEK_END);
  const long file_size = std::ftell(f);
  std::fseek(f, 0, SEEK_SET);

  if (file_size > 0) {
    buf.resize(static_cast<std::size_t>(file_size));

    const std::size_t nread =
        std::fread(buf.data(), 1, static_cast<std::size_t>(file_size), f);

    if (nread != static_cast<std::size_t>(file_size)) {
      std::fprintf(stderr, "Error: short read from %s\n", input_path);
      std::fclose(f);
      return 1;
    }
  } else {
    std::fprintf(stderr, "Error: unable to read from %s\n", input_path);
    std::fclose(f);
    return 1;
  }

  std::fclose(f);

  const std::size_t one_input_io = 5; // adapted to 5
  const std::size_t one_input = one_input_io;

  const std::size_t buf_size = buf.size();
  if (buf_size < one_input) {
    return 0;
  }

  const std::size_t kSeedPairs = buf_size / one_input;

  const std::size_t kEffectiveSeedPairs =
      std::min(
          kSeedPairs,
          fuzz_filter::max_fuzz_instrs(fuzz_mem::kImemWords)
      );

  buf.resize(one_input * kEffectiveSeedPairs);

  harness_common::install_imem_program(buf, kEffectiveSeedPairs);

  const std::uint_fast64_t instr_budget =
      static_cast<std::uint_fast64_t>(
          kEffectiveSeedPairs + fuzz_filter::kTrailerWords
      );

  const std::uint_fast64_t cycles_to_run =
      8 * instr_budget + 64;

  if (replay) {
    harness_common::CrashLogPath = harness_common::decode_path_for(input_path);
    const std::string ruletrace_path = harness_common::CrashLogPath + "_A_ruletrace";
    setenv("SIM_RULETRACE_FPATH", ruletrace_path.c_str(), 1);

    std::fprintf(stderr, "Replaying input from %s\n", input_path);
    std::fprintf(stderr,
                 "kSeedPairs=%zu kEffectiveSeedPairs=%zu trailer_start_word=%zu "
                 "trailer_words=%zu cycles_to_run=%llu\n",
                 kSeedPairs,
                 kEffectiveSeedPairs,
                 kEffectiveSeedPairs,
                 fuzz_filter::kTrailerWords,
                 static_cast<unsigned long long>(cycles_to_run));
  }

  using sim_a_t = harness_a::simulator;
  using sim_b_t = harness_b::simulator;

  using sim_assert_a_t = bool (*)(const sim_a_t&);
  using sim_assert_b_t = bool (*)(const sim_b_t&);

  const sim_assert_a_t no_assert_a = nullptr;
  const sim_assert_b_t no_assert_b = nullptr;

  const auto run_a =
      diff_fuzz::run_one_instance<sim_a_t>(
          buf,
          kEffectiveSeedPairs,
          cycles_to_run,
          replay,
          "Core A",
          harness_a::set_run_inputs,
          no_assert_a,
          no_assert_a,
          harness_common::CrashLogPath);

  if (replay) {
    const std::string ruletrace_path = harness_common::CrashLogPath + "_B_ruletrace";
    setenv("SIM_RULETRACE_FPATH", ruletrace_path.c_str(), 1);
    cuttlesim::ruletrace::reset();
  }
  const auto run_b =
      diff_fuzz::run_one_instance<sim_b_t>(
          buf,
          kEffectiveSeedPairs,
          cycles_to_run,
          replay,
          "Core B",
          harness_b::set_run_inputs,
          no_assert_b,
          no_assert_b,
          harness_common::CrashLogPath);

  const arch_diff::arch_result arch_a =
      arch_diff::extract_arch_result(run_a);

  const arch_diff::arch_result arch_b =
      arch_diff::extract_arch_result(run_b);

  const bool equal = arch_diff::arch_results_equal(arch_a, arch_b);

  if (!equal) {
    std::fprintf(stderr, "Differential mismatch\n");

    if (replay) {
      
      const std::string imem_path = harness_common::CrashLogPath + "_imem";
      fuzz_mem::dump_imem(imem_path); 

      diff_fuzz::dump_state_and_dmem(
          harness_common::CrashLogPath,
          "Core A Compared Final State",
          run_a.state,
          run_a.dmem);

      diff_fuzz::dump_state_and_dmem(
          harness_common::CrashLogPath,
          "Core B Compared Final State",
          run_b.state,
          run_b.dmem);

      arch_diff::dump_arch_results_to_log(
          harness_common::CrashLogPath,
          arch_a,
          arch_b);

      return 1;
    }

    std::abort();
  }

  if (replay) {
    std::fprintf(stderr, "No differential mismatch reproduced\n");
  }

  return 0;
}