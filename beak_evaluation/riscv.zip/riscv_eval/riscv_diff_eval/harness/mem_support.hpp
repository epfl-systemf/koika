#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <unordered_map>
#include <vector>

#include "filter_support_w_branch.hpp"

namespace fuzz_mem {

inline constexpr std::size_t kImemWords = 1024;

inline std::array<uint32_t, kImemWords>& imem_image() {
  static std::array<uint32_t, kImemWords> imem{};
  return imem;
}

inline std::unordered_map<uint32_t, uint32_t>& dmem_image() {
  static std::unordered_map<uint32_t, uint32_t> dmem;
  return dmem;
}

inline void reset_all() {
  imem_image().fill(fuzz_filter::kNopInsn);
  dmem_image().clear();
}

inline void imem_set_word(std::size_t word_index, uint32_t instr) {
  if (word_index < kImemWords) {
    imem_image()[word_index] = instr;
  }
}

inline uint32_t imem_get_word(std::size_t word_index) {
  if (word_index >= kImemWords) {
    return fuzz_filter::kIllegalInsn;
  }

  return imem_image()[word_index];
}

inline uint32_t imem_fetch(uint32_t addr) {
  if ((addr & 0x3u) != 0) {
    return fuzz_filter::kIllegalInsn;
  }

  const uint32_t word_index = addr >> 2;

  if (word_index >= kImemWords) {
    return fuzz_filter::kIllegalInsn;
  }

  return imem_image()[word_index];
}

inline void dump_imem(const std::string& path) {
  FILE* out = nullptr;

  if (!path.empty()) {
    out = std::fopen(path.c_str(), "a");
  }

  if (!out) {
    return;
  }

  std::fprintf(out, "=== IMEM LAYOUT ===\n");

  for (int i = 0; i < kImemWords; ++i) {
    std::fprintf(out, "imem[%zu] = 0x%08x (%s) \n", i, imem_get_word(i), fuzz_filter::instr_to_string(imem_get_word(i)));
  }
}

inline uint32_t dmem_load_word(uint32_t addr) {
  const uint32_t word_addr = addr & ~0x3u;

  auto it = dmem_image().find(word_addr);
  if (it == dmem_image().end()) {
    return 0;
  }

  return it->second;
}

inline void dmem_store_masked(uint32_t addr, uint32_t data, uint32_t byte_en) {
  const uint32_t word_addr = addr & ~0x3u;

  uint32_t cur = dmem_load_word(word_addr);

  uint32_t mask = 0;
  for (int i = 0; i < 4; ++i) {
    if ((byte_en >> i) & 0x1u) {
      mask |= 0xFFu << (8 * i);
    }
  }

  const uint32_t next = (cur & ~mask) | (data & mask);
  dmem_image()[word_addr] = next;
}

inline uint32_t load_u32_le_padded(const std::vector<uint8_t>& buf,
                                   std::size_t off) {
  uint32_t x = 0;

  for (std::size_t i = 0; i < 4; ++i) {
    if (off + i < buf.size()) {
      x |= static_cast<uint32_t>(buf[off + i]) << (8 * i);
    }
  }

  return x;
}

} // namespace fuzz_mem