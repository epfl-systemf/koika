#pragma once

#include <cstddef>
#include <cstdint>

namespace fuzz_filter {

inline constexpr uint32_t kNopInsn     = 0x00000013u; // addi x0, x0, 0
inline constexpr uint32_t kIllegalInsn = 0x00000000u;

// Fixed trailer layout:
//   [15 NOPs] [lui x5, 0x40001] [sw x0, 0(x5)]
//
inline constexpr std::size_t kDrainNops = 15;
inline constexpr std::size_t kFinishWords = 2;
inline constexpr std::size_t kPostFinishNops = 16;
inline constexpr std::size_t kTrailerWords =
    kDrainNops + kFinishWords + kPostFinishNops;


// to trigger finish
inline constexpr uint32_t kFinishLuiT0  = 0x400012b7u; // lui x5, 0x40001 
inline constexpr uint32_t kFinishSwX0T0 = 0x0002a023u; // sw x0, 0(x5)

inline std::size_t max_fuzz_instrs(std::size_t imem_words) {
  return (imem_words > kTrailerWords) ? (imem_words - kTrailerWords) : 0;
}

inline uint32_t finish_trailer_word(std::size_t trailer_offset) {
  if (trailer_offset < kDrainNops) {
    return kNopInsn;
  }

  const std::size_t finish_offset = trailer_offset - kDrainNops;

  if (finish_offset == 0) {
    return kFinishLuiT0;
  }

  if (finish_offset == 1) {
    return kFinishSwX0T0;
  }

  return kNopInsn;
}

enum class InstKind : uint8_t {
  LUI,
  AUIPC,

  JAL,
  BEQ,

  ADDI,
  SLTI,
  SLTIU,
  XORI,
  ORI,
  ANDI,

  LB, 
  LH, 
  LW, 
  LBU, 
  LHU, 
  SB, 
  SH, 
  SW
};

struct InstSpec {
  InstKind kind;
};

inline constexpr InstSpec kStraightlineUImmSpecs[] = { // only straightline instr. for now
    {InstKind::LUI},
    {InstKind::AUIPC},

  // Forward-only control flow (bounded by caller for termination).
  {InstKind::JAL},
  {InstKind::BEQ},

    {InstKind::ADDI},
    {InstKind::SLTI},
    {InstKind::SLTIU},
    {InstKind::XORI},
    {InstKind::ORI},
    {InstKind::ANDI},

    {InstKind::LB},
    {InstKind::LH},
    {InstKind::LW},
    {InstKind::LBU},
    {InstKind::LHU},
    {InstKind::SB},
    {InstKind::SH},
    {InstKind::SW},

};

inline constexpr std::size_t kStraightlineUImmSpecCount =
    sizeof(kStraightlineUImmSpecs) / sizeof(kStraightlineUImmSpecs[0]); // number of Instrs.

inline uint32_t mask_width(unsigned width) {
  return (width >= 32) ? 0xffffffffu : ((1u << width) - 1u);
}

inline uint32_t pick_bits(uint32_t raw, unsigned lo, unsigned width) {
  return (raw >> lo) & mask_width(width);
}

inline uint32_t encode_u_type(uint32_t opcode, uint32_t rd, uint32_t imm20) {
  return ((imm20 & 0xfffffu) << 12) |
         ((rd & 0x1fu) << 7) |
         (opcode & 0x7fu);
}

inline uint32_t encode_i_type(uint32_t opcode,
                              uint32_t rd,
                              uint32_t funct3,
                              uint32_t rs1,
                              uint32_t imm12) {
  return ((imm12 & 0xfffu) << 20) |
         ((rs1 & 0x1fu) << 15) |
         ((funct3 & 0x7u) << 12) |
         ((rd & 0x1fu) << 7) |
         (opcode & 0x7fu);
}

inline uint32_t encode_b_type(uint32_t opcode,
          uint32_t funct3,
          uint32_t rs1,
          uint32_t rs2,
          uint32_t imm13) {
  const uint32_t imm = imm13 & 0x1fffu;
  return (((imm >> 12) & 0x1u) << 31) |
    (((imm >> 5) & 0x3fu) << 25) |
    ((rs2 & 0x1fu) << 20) |
    ((rs1 & 0x1fu) << 15) |
    ((funct3 & 0x7u) << 12) |
    (((imm >> 1) & 0xfu) << 8) |
    (((imm >> 11) & 0x1u) << 7) |
    (opcode & 0x7fu);
}

inline uint32_t encode_j_type(uint32_t opcode, uint32_t rd, uint32_t imm21) {
  const uint32_t imm = imm21 & 0x1fffffu;
  return (((imm >> 20) & 0x1u) << 31) |
    (((imm >> 1) & 0x3ffu) << 21) |
    (((imm >> 11) & 0x1u) << 20) |
    (((imm >> 12) & 0xffu) << 12) |
    ((rd & 0x1fu) << 7) |
    (opcode & 0x7fu);
}

inline uint32_t encode_spec(const InstSpec& spec, uint32_t payload) {
  const uint32_t rd = pick_bits(payload, 0, 5);
  const uint32_t rs1 = pick_bits(payload, 5, 5);
  const uint32_t imm12 = pick_bits(payload, 10, 12);
  const uint32_t imm20 = pick_bits(payload, 10, 20);

  switch (spec.kind) {
    case InstKind::LUI:
      return encode_u_type(0x37u, rd, imm20);

    case InstKind::AUIPC:
      return encode_u_type(0x17u, rd, imm20);

    case InstKind::JAL:
      return kNopInsn;

    case InstKind::BEQ:
      return kNopInsn;

    case InstKind::ADDI:
      return encode_i_type(0x13u, rd, 0x0u, rs1, imm12);

    case InstKind::SLTI:
      return encode_i_type(0x13u, rd, 0x2u, rs1, imm12);

    case InstKind::SLTIU:
      return encode_i_type(0x13u, rd, 0x3u, rs1, imm12);

    case InstKind::XORI:
      return encode_i_type(0x13u, rd, 0x4u, rs1, imm12);

    case InstKind::ORI:
      return encode_i_type(0x13u, rd, 0x6u, rs1, imm12);

    case InstKind::ANDI:
      return encode_i_type(0x13u, rd, 0x7u, rs1, imm12);

    case InstKind::LB:
      return encode_i_type(0x3u, rd, 0x0u, rs1, imm12);

    case InstKind::LH:
      return encode_i_type(0x3u, rd, 0x1u, rs1, imm12);

    case InstKind::LW:
      return encode_i_type(0x3u, rd, 0x2u, rs1, imm12);

    case InstKind::LBU:
      return encode_i_type(0x3u, rd, 0x4u, rs1, imm12);

    case InstKind::LHU:
      return encode_i_type(0x3u, rd, 0x5u, rs1, imm12);

    case InstKind::SB:
      return encode_i_type(0x23u, rd, 0x0u, rs1, imm12);

    case InstKind::SH:
      return encode_i_type(0x23u, rd, 0x1u, rs1, imm12);

    case InstKind::SW:
      return encode_i_type(0x23u, rd, 0x2u, rs1, imm12);

    default:
      return kNopInsn;
  }
}

inline uint32_t encode_spec_bounded(const InstSpec& spec,
                                    uint32_t payload,
                                    std::size_t instr_index,
                                    std::size_t fuzz_instr_count) {
  const uint32_t rd = pick_bits(payload, 0, 5);
  const uint32_t rs1 = pick_bits(payload, 5, 5);
  const uint32_t rs2 = pick_bits(payload, 10, 5);
  const uint32_t imm12 = pick_bits(payload, 10, 12);
  const uint32_t imm20 = pick_bits(payload, 10, 20);

  // Bound forward targets to the first finish instruction to guarantee termination.
  const std::size_t finish_start_index = fuzz_instr_count + kDrainNops;
  const std::size_t max_forward_words =
      (finish_start_index > instr_index)
          ? (finish_start_index - instr_index)
          : 0u;

  switch (spec.kind) {
    case InstKind::LUI:
      return encode_u_type(0x37u, rd, imm20);

    case InstKind::AUIPC:
      return encode_u_type(0x17u, rd, imm20);

    case InstKind::ADDI:
      return encode_i_type(0x13u, rd, 0x0u, rs1, imm12);

    case InstKind::SLTI:
      return encode_i_type(0x13u, rd, 0x2u, rs1, imm12);

    case InstKind::SLTIU:
      return encode_i_type(0x13u, rd, 0x3u, rs1, imm12);

    case InstKind::XORI:
      return encode_i_type(0x13u, rd, 0x4u, rs1, imm12);

    case InstKind::ORI:
      return encode_i_type(0x13u, rd, 0x6u, rs1, imm12);

    case InstKind::ANDI:
      return encode_i_type(0x13u, rd, 0x7u, rs1, imm12);

    case InstKind::LB:
      return encode_i_type(0x3u, rd, 0x0u, rs1, imm12);

    case InstKind::LH:
      return encode_i_type(0x3u, rd, 0x1u, rs1, imm12);

    case InstKind::LW:
      return encode_i_type(0x3u, rd, 0x2u, rs1, imm12);

    case InstKind::LBU:
      return encode_i_type(0x3u, rd, 0x4u, rs1, imm12);

    case InstKind::LHU:
      return encode_i_type(0x3u, rd, 0x5u, rs1, imm12);

    case InstKind::SB:
      return encode_i_type(0x23u, rd, 0x0u, rs1, imm12);

    case InstKind::SH:
      return encode_i_type(0x23u, rd, 0x1u, rs1, imm12);

    case InstKind::SW:
      return encode_i_type(0x23u, rd, 0x2u, rs1, imm12);

    case InstKind::JAL: {
      if (max_forward_words == 0u) {
        return kNopInsn;
      }

      // Max positive JAL immediate is 2^20-2 bytes => 262143 words.
      constexpr std::size_t kMaxJalWords = 262143u;
      const std::size_t bound_words =
          (max_forward_words < kMaxJalWords) ? max_forward_words : kMaxJalWords;
      const std::size_t offset_words = 1u + (payload % bound_words);
      const uint32_t imm21 = static_cast<uint32_t>(offset_words * 4u);
      return encode_j_type(0x6fu, 0u, imm21); // rd=0 so return address is discarded.
    }

    case InstKind::BEQ: {
      if (max_forward_words == 0u) {
        return kNopInsn;
      }

      // Max positive BEQ immediate is 2^12-2 bytes => 1023 words.
      constexpr std::size_t kMaxBeqWords = 1023u;
      const std::size_t bound_words =
          (max_forward_words < kMaxBeqWords) ? max_forward_words : kMaxBeqWords;
      const std::size_t offset_words = 1u + (payload % bound_words);
      const uint32_t imm13 = static_cast<uint32_t>(offset_words * 4u);
      return encode_b_type(0x63u, 0x0u, rs1, rs2, imm13); // beq rs1, rs2, +imm
    }

    default:
      return kNopInsn;
  }
}

inline uint32_t filter_to_nop(uint32_t raw) { // nop mapping
  (void)raw;
  return kNopInsn;
}

inline uint32_t filter_to_straightline_u_imm(uint32_t raw) { // quotient/remainder, other methods ???
  const uint32_t spec_idx =
      raw % static_cast<uint32_t>(kStraightlineUImmSpecCount); 

  const uint32_t payload =
      raw / static_cast<uint32_t>(kStraightlineUImmSpecCount); 

  uint32_t insn = encode_spec(kStraightlineUImmSpecs[spec_idx], payload);

  if (insn == kIllegalInsn || insn == kFinishLuiT0 || insn == kFinishSwX0T0)
    return kNopInsn;
    
  return encode_spec(kStraightlineUImmSpecs[spec_idx], payload);
}

  inline uint32_t filter_to_straightline_u_imm_bounded(uint32_t raw,
                             std::size_t instr_index,
                             std::size_t fuzz_instr_count) {
    const uint32_t spec_idx =
      raw % static_cast<uint32_t>(kStraightlineUImmSpecCount);

    const uint32_t payload =
      raw / static_cast<uint32_t>(kStraightlineUImmSpecCount);

    uint32_t insn = encode_spec(kStraightlineUImmSpecs[spec_idx], payload);

    if (insn == kIllegalInsn || insn == kFinishLuiT0 || insn == kFinishSwX0T0)
      return kNopInsn;

    return encode_spec_bounded(
      kStraightlineUImmSpecs[spec_idx], payload, instr_index, fuzz_instr_count);
  }

inline const char* instr_to_string(uint32_t insn) {
  if (insn == kNopInsn) {
    return "nop";
  }

  if (insn == kIllegalInsn) {
    return "illegal";
  }

  const uint32_t opcode = insn & 0x7fu;
  const uint32_t funct3 = (insn >> 12) & 0x7u;

  switch (opcode) {
    case 0x37u:
      return "lui";
    case 0x17u:
      return "auipc";
    case 0x13u:
      switch (funct3) {
        case 0x0u:
          return "addi";
        case 0x2u:
          return "slti";
        case 0x3u:
          return "sltiu";
        case 0x4u:
          return "xori";
        case 0x6u:
          return "ori";
        case 0x7u:
          return "andi";
        default:
          return "op-imm";
      }
    case 0x03u:
      switch (funct3) {
        case 0x0u:
          return "lb";
        case 0x1u:
          return "lh";
        case 0x2u:
          return "lw";
        case 0x4u:
          return "lbu";
        case 0x5u:
          return "lhu";
        default:
          return "load";
      }
    case 0x23u:
      switch (funct3) {
        case 0x0u:
          return "sb";
        case 0x1u:
          return "sh";
        case 0x2u:
          return "sw";
        default:
          return "store";
      }
    case 0x6fu:
      return "jal";
    case 0x63u:
      switch (funct3) {
        case 0x0u:
          return "beq";
        default:
          return "branch";
      }
    default:
      return "unknown";
  }
}

} // namespace fuzz_filter