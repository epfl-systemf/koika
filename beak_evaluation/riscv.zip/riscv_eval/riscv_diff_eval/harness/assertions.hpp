#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP

#include <cstdint>
#include <cstdio>
#include <cstdlib>

namespace rv_assert_metrics {

// Count only valid decoded instructions.
inline std::uint64_t decode_valid_insts = 0;
inline std::uint64_t decode_legal_insts = 0;
inline std::uint64_t decode_illegal_insts = 0;

// Optional: count cycles separately for debugging.
inline std::uint64_t observed_cycles = 0;

inline void reset_metrics() {
  decode_valid_insts = 0;
  decode_legal_insts = 0;
  decode_illegal_insts = 0;
  observed_cycles = 0;
}

} // namespace rv_assert_metrics

template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {
  using namespace rv_assert_metrics;

  const auto& h = sim.get_snapshots();
  const auto& curr = h[h.size() - 1];

  ++observed_cycles;

  const bool valid = static_cast<bool>(curr.state.d2e_valid0);
  const bool legal = static_cast<bool>(curr.state.d2e_data0.dInst.legal);

  if (valid) {
    ++decode_valid_insts;

    if (legal) {
      ++decode_legal_insts;
    } else {
      ++decode_illegal_insts;
    }
  }

  return true;
}

template <typename sim_t>
inline bool assert_final(const sim_t& sim) {
  using namespace rv_assert_metrics;

  const double pct_decode =
      (decode_valid_insts == 0)
          ? 0.0
          : (100.0 * static_cast<double>(decode_legal_insts) /
             static_cast<double>(decode_valid_insts));

  const bool finished = sim.finished();
  const int exit_code = finished ? sim.finish_exit_code() : -1;

  const char* out_path = std::getenv("LEGAL_METRICS_PATH");
  if (!out_path || out_path[0] == '\0') {
    out_path = "legal_instr_metrics_filter_ext1.txt";
  }

  if (FILE* out = std::fopen(out_path, "a")) {
    std::fprintf(out,
                 "[during-legality] legal=%llu illegal=%llu valid=%llu cycles=%llu (%.2f%%)\n",
                 static_cast<unsigned long long>(decode_legal_insts),
                 static_cast<unsigned long long>(decode_illegal_insts),
                 static_cast<unsigned long long>(decode_valid_insts),
                 static_cast<unsigned long long>(observed_cycles),
                 pct_decode);

    std::fprintf(out,
                 "[finish-status] finished=%d exit_code=%d\n",
                 static_cast<int>(finished),
                 exit_code);

    std::fclose(out);
  }

  return true;
}

#endif