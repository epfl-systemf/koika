#pragma once

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cerrno>
#include <string>
#include <unordered_map>
#include <vector>

#ifndef ALL_REGISTERS
#error "diff_fuzz_support.hpp must be included after ALL_REGISTERS is defined"
#endif

namespace diff_fuzz {

using dmem_t = std::unordered_map<uint32_t, uint32_t>;

inline uint32_t dmem_load_word(const dmem_t& dmem, uint32_t addr) {
  const uint32_t word_addr = addr & ~0x3u;

  const auto it = dmem.find(word_addr);
  if (it == dmem.end()) {
    return 0;
  }

  return it->second;
}

inline void dmem_store_masked(dmem_t& dmem,
                              uint32_t addr,
                              uint32_t data,
                              uint32_t byte_en) {
  const uint32_t word_addr = addr & ~0x3u;
  const uint32_t cur = dmem_load_word(dmem, word_addr);

  uint32_t mask = 0;
  for (int i = 0; i < 4; ++i) {
    if ((byte_en >> i) & 0x1u) {
      mask |= 0xffu << (8 * i);
    }
  }

  const uint32_t next = (cur & ~mask) | (data & mask);
  dmem[word_addr] = next;
}

template <typename StateT>
struct run_result {
  StateT state;
  dmem_t dmem;
  bool finished;
  int exit_code;
};

template <typename BitsT>
inline void dump_bits_field(FILE* out,
                            const char* name,
                            int width,
                            BitsT value) {
  const auto packed = prims::pack(value);
  std::fprintf(out, "%s[%d] = 0x%08x\n", name, width, (unsigned)packed.v);
}

inline void dump_dmem(FILE* out, const char* title, const dmem_t& dmem) {
  std::fprintf(out, "--- %s ---\n", title);

  if (dmem.empty()) {
    std::fprintf(out, "(empty)\n");
    return;
  }

  for (const auto& kv : dmem) {
    std::fprintf(out, "dmem[0x%08x] = 0x%08x\n", kv.first, kv.second);
  }
}

template <typename StateT>
inline void dump_state_and_dmem(const std::string& path,
                                const char* label,
                                const StateT& st,
                                const dmem_t& dmem) {
  FILE* out = nullptr;

  if (!path.empty()) {
    out = std::fopen(path.c_str(), "a");
  }

  if (!out) {
    return;
  }

  std::fprintf(out, "=== %s ===\n", label);

#define DIFF_DUMP_FIELD(name, width) \
  diff_fuzz::dump_bits_field(out, #name, width, st.name);
  ALL_REGISTERS(DIFF_DUMP_FIELD)
#undef DIFF_DUMP_FIELD

  dump_dmem(out, "per-core dmem", dmem);

  std::fclose(out);
}

template <typename StateT>
inline bool states_equal(const StateT& a, const StateT& b) {
  bool ok = true;

#define DIFF_CMP_FIELD(name, width)                                 \
  do {                                                              \
    const auto av = prims::pack(a.name);                            \
    const auto bv = prims::pack(b.name);                            \
    if (!(av == bv)) {                                              \
      std::fprintf(stderr, "State mismatch: %s\n", #name);          \
      ok = false;                                                   \
    }                                                               \
  } while (0);

  ALL_REGISTERS(DIFF_CMP_FIELD)

#undef DIFF_CMP_FIELD

  return ok;
}

inline bool dmem_equal(const dmem_t& a, const dmem_t& b) {
  if (a == b) {
    return true;
  }

  std::fprintf(stderr,
               "DMEM mismatch: size_a=%zu size_b=%zu\n",
               a.size(),
               b.size());

  std::size_t shown = 0;

  for (const auto& kv : a) {
    const uint32_t addr = kv.first;
    const uint32_t aval = kv.second;

    const auto it = b.find(addr);
    const bool missing = (it == b.end());
    const uint32_t bval = missing ? 0 : it->second;

    if (missing || aval != bval) {
      std::fprintf(stderr,
                   "  dmem[0x%08x]: a=0x%08x b=%s0x%08x\n",
                   addr,
                   aval,
                   missing ? "<missing> " : "",
                   bval);

      if (++shown >= 16) {
        break;
      }
    }
  }

  if (shown < 16) {
    for (const auto& kv : b) {
      const uint32_t addr = kv.first;

      if (a.find(addr) == a.end()) {
        std::fprintf(stderr,
                     "  dmem[0x%08x]: a=<missing> b=0x%08x\n",
                     addr,
                     kv.second);

        if (++shown >= 16) {
          break;
        }
      }
    }
  }

  return false;
}

template <typename StateT>
inline bool run_results_equal(const run_result<StateT>& a,
                              const run_result<StateT>& b) {
  bool ok = true;

  if (a.finished != b.finished) {
    std::fprintf(stderr,
                 "Finish-status mismatch: a=%d b=%d\n",
                 static_cast<int>(a.finished),
                 static_cast<int>(b.finished));
    ok = false;
  }

  if (!states_equal(a.state, b.state)) {
    ok = false;
  }

  if (!dmem_equal(a.dmem, b.dmem)) {
    ok = false;
  }

  return ok;
}

template <typename SimulatorT, typename SetRunInputsFn>
inline run_result<typename SimulatorT::state_t>
run_one_instance(const std::vector<uint8_t>& buf,
                 std::size_t kEffectiveSeedPairs,
                 std::uint_fast64_t cycles_to_run,
                 bool replay,
                 const char* label,
                 SetRunInputsFn set_run_inputs,
                 bool (*assert_pred)(const SimulatorT&),
                 bool (*assert_pred_final)(const SimulatorT&),
                 const std::string& crash_log_path) {
  using state_t = typename SimulatorT::state_t;

  dmem_t dmem;

  state_t st = SimulatorT::initial_state();

  set_run_inputs(buf, kEffectiveSeedPairs);

  if (replay) {
    dump_state_and_dmem(
        crash_log_path,
        (std::string(label) + " Initial State").c_str(),
        st,
        dmem);
  }

  SimulatorT sim(st);

  sim.get_extfuns().active_dmem = &dmem;

  if (assert_pred) {
    sim.set_assert_pred(assert_pred);
  }

  if (assert_pred_final) {
    sim.set_assert_pred_final(assert_pred_final);
  }

  sim.run_fuzz(cycles_to_run, !replay);

  run_result<state_t> result;
  result.state = sim.snapshot().state;
  result.dmem = dmem;
  result.finished = sim.finished();
  result.exit_code = sim.finish_exit_code();

  if (replay) {
    dump_state_and_dmem(
        crash_log_path,
        (std::string(label) + " Final State").c_str(),
        result.state,
        result.dmem);
  }

  sim.get_extfuns().active_dmem = nullptr;

  return result;
}

} // namespace diff_fuzz