#ifndef MODULE_RV32_B_HPP
#define MODULE_RV32_B_HPP


////////////////////
// IMPLEMENTATION //
////////////////////
namespace rv32_b {
template <typename extfuns_t> class module_rv32 {
public:
struct state_t {
struct_mem_req toIMem_data0;
bits<1> toIMem_valid0;
struct_mem_resp fromIMem_data0;
bits<1> fromIMem_valid0;
struct_mem_req toDMem_data0;
bits<1> toDMem_valid0;
struct_mem_resp fromDMem_data0;
bits<1> fromDMem_valid0;
struct_fetch_bookkeeping f2d_data0;
bits<1> f2d_valid0;
struct_fetch_bookkeeping f2dprim_data0;
bits<1> f2dprim_valid0;
struct_decode_bookkeeping d2e_data0;
bits<1> d2e_valid0;
struct_execute_bookkeeping e2w_data0;
bits<1> e2w_valid0;
bits<32> rf_x00_zero;
bits<32> rf_x01_ra;
bits<32> rf_x02_sp;
bits<32> rf_x03_gp;
bits<32> rf_x04_tp;
bits<32> rf_x05_t0;
bits<32> rf_x06_t1;
bits<32> rf_x07_t2;
bits<32> rf_x08_s0_fp;
bits<32> rf_x09_s1;
bits<32> rf_x10_a0;
bits<32> rf_x11_a1;
bits<32> rf_x12_a2;
bits<32> rf_x13_a3;
bits<32> rf_x14_a4;
bits<32> rf_x15_a5;
bits<32> rf_x16_a6;
bits<32> rf_x17_a7;
bits<32> rf_x18_s2;
bits<32> rf_x19_s3;
bits<32> rf_x20_s4;
bits<32> rf_x21_s5;
bits<32> rf_x22_s6;
bits<32> rf_x23_s7;
bits<32> rf_x24_s8;
bits<32> rf_x25_s9;
bits<32> rf_x26_s10;
bits<32> rf_x27_s11;
bits<32> rf_x28_t3;
bits<32> rf_x29_t4;
bits<32> rf_x30_t5;
bits<32> rf_x31_t6;
bits<1> mulState_valid;
bits<32> mulState_operand1;
bits<32> mulState_operand2;
bits<64> mulState_result;
bits<5> mulState_n_step;
bits<1> mulState_finished;
bits<2> scoreboard_x00_zero;
bits<2> scoreboard_x01_ra;
bits<2> scoreboard_x02_sp;
bits<2> scoreboard_x03_gp;
bits<2> scoreboard_x04_tp;
bits<2> scoreboard_x05_t0;
bits<2> scoreboard_x06_t1;
bits<2> scoreboard_x07_t2;
bits<2> scoreboard_x08_s0_fp;
bits<2> scoreboard_x09_s1;
bits<2> scoreboard_x10_a0;
bits<2> scoreboard_x11_a1;
bits<2> scoreboard_x12_a2;
bits<2> scoreboard_x13_a3;
bits<2> scoreboard_x14_a4;
bits<2> scoreboard_x15_a5;
bits<2> scoreboard_x16_a6;
bits<2> scoreboard_x17_a7;
bits<2> scoreboard_x18_s2;
bits<2> scoreboard_x19_s3;
bits<2> scoreboard_x20_s4;
bits<2> scoreboard_x21_s5;
bits<2> scoreboard_x22_s6;
bits<2> scoreboard_x23_s7;
bits<2> scoreboard_x24_s8;
bits<2> scoreboard_x25_s9;
bits<2> scoreboard_x26_s10;
bits<2> scoreboard_x27_s11;
bits<2> scoreboard_x28_t3;
bits<2> scoreboard_x29_t4;
bits<2> scoreboard_x30_t5;
bits<2> scoreboard_x31_t6;
bits<32> cycle_count;
bits<32> instr_count;
bits<32> pc;
bits<1> epoch;

#ifndef SIM_MINIMAL
void dump(std::ostream& os = std::cout) const {
os << "toIMem_data0 = " << toIMem_data0 << std::endl;
os << "toIMem_valid0 = " << toIMem_valid0 << std::endl;
os << "fromIMem_data0 = " << fromIMem_data0 << std::endl;
os << "fromIMem_valid0 = " << fromIMem_valid0 << std::endl;
os << "toDMem_data0 = " << toDMem_data0 << std::endl;
os << "toDMem_valid0 = " << toDMem_valid0 << std::endl;
os << "fromDMem_data0 = " << fromDMem_data0 << std::endl;
os << "fromDMem_valid0 = " << fromDMem_valid0 << std::endl;
os << "f2d_data0 = " << f2d_data0 << std::endl;
os << "f2d_valid0 = " << f2d_valid0 << std::endl;
os << "f2dprim_data0 = " << f2dprim_data0 << std::endl;
os << "f2dprim_valid0 = " << f2dprim_valid0 << std::endl;
os << "d2e_data0 = " << d2e_data0 << std::endl;
os << "d2e_valid0 = " << d2e_valid0 << std::endl;
os << "e2w_data0 = " << e2w_data0 << std::endl;
os << "e2w_valid0 = " << e2w_valid0 << std::endl;
os << "rf_x00_zero = " << rf_x00_zero << std::endl;
os << "rf_x01_ra = " << rf_x01_ra << std::endl;
os << "rf_x02_sp = " << rf_x02_sp << std::endl;
os << "rf_x03_gp = " << rf_x03_gp << std::endl;
os << "rf_x04_tp = " << rf_x04_tp << std::endl;
os << "rf_x05_t0 = " << rf_x05_t0 << std::endl;
os << "rf_x06_t1 = " << rf_x06_t1 << std::endl;
os << "rf_x07_t2 = " << rf_x07_t2 << std::endl;
os << "rf_x08_s0_fp = " << rf_x08_s0_fp << std::endl;
os << "rf_x09_s1 = " << rf_x09_s1 << std::endl;
os << "rf_x10_a0 = " << rf_x10_a0 << std::endl;
os << "rf_x11_a1 = " << rf_x11_a1 << std::endl;
os << "rf_x12_a2 = " << rf_x12_a2 << std::endl;
os << "rf_x13_a3 = " << rf_x13_a3 << std::endl;
os << "rf_x14_a4 = " << rf_x14_a4 << std::endl;
os << "rf_x15_a5 = " << rf_x15_a5 << std::endl;
os << "rf_x16_a6 = " << rf_x16_a6 << std::endl;
os << "rf_x17_a7 = " << rf_x17_a7 << std::endl;
os << "rf_x18_s2 = " << rf_x18_s2 << std::endl;
os << "rf_x19_s3 = " << rf_x19_s3 << std::endl;
os << "rf_x20_s4 = " << rf_x20_s4 << std::endl;
os << "rf_x21_s5 = " << rf_x21_s5 << std::endl;
os << "rf_x22_s6 = " << rf_x22_s6 << std::endl;
os << "rf_x23_s7 = " << rf_x23_s7 << std::endl;
os << "rf_x24_s8 = " << rf_x24_s8 << std::endl;
os << "rf_x25_s9 = " << rf_x25_s9 << std::endl;
os << "rf_x26_s10 = " << rf_x26_s10 << std::endl;
os << "rf_x27_s11 = " << rf_x27_s11 << std::endl;
os << "rf_x28_t3 = " << rf_x28_t3 << std::endl;
os << "rf_x29_t4 = " << rf_x29_t4 << std::endl;
os << "rf_x30_t5 = " << rf_x30_t5 << std::endl;
os << "rf_x31_t6 = " << rf_x31_t6 << std::endl;
os << "mulState_valid = " << mulState_valid << std::endl;
os << "mulState_operand1 = " << mulState_operand1 << std::endl;
os << "mulState_operand2 = " << mulState_operand2 << std::endl;
os << "mulState_result = " << mulState_result << std::endl;
os << "mulState_n_step = " << mulState_n_step << std::endl;
os << "mulState_finished = " << mulState_finished << std::endl;
os << "scoreboard_x00_zero = " << scoreboard_x00_zero << std::endl;
os << "scoreboard_x01_ra = " << scoreboard_x01_ra << std::endl;
os << "scoreboard_x02_sp = " << scoreboard_x02_sp << std::endl;
os << "scoreboard_x03_gp = " << scoreboard_x03_gp << std::endl;
os << "scoreboard_x04_tp = " << scoreboard_x04_tp << std::endl;
os << "scoreboard_x05_t0 = " << scoreboard_x05_t0 << std::endl;
os << "scoreboard_x06_t1 = " << scoreboard_x06_t1 << std::endl;
os << "scoreboard_x07_t2 = " << scoreboard_x07_t2 << std::endl;
os << "scoreboard_x08_s0_fp = " << scoreboard_x08_s0_fp << std::endl;
os << "scoreboard_x09_s1 = " << scoreboard_x09_s1 << std::endl;
os << "scoreboard_x10_a0 = " << scoreboard_x10_a0 << std::endl;
os << "scoreboard_x11_a1 = " << scoreboard_x11_a1 << std::endl;
os << "scoreboard_x12_a2 = " << scoreboard_x12_a2 << std::endl;
os << "scoreboard_x13_a3 = " << scoreboard_x13_a3 << std::endl;
os << "scoreboard_x14_a4 = " << scoreboard_x14_a4 << std::endl;
os << "scoreboard_x15_a5 = " << scoreboard_x15_a5 << std::endl;
os << "scoreboard_x16_a6 = " << scoreboard_x16_a6 << std::endl;
os << "scoreboard_x17_a7 = " << scoreboard_x17_a7 << std::endl;
os << "scoreboard_x18_s2 = " << scoreboard_x18_s2 << std::endl;
os << "scoreboard_x19_s3 = " << scoreboard_x19_s3 << std::endl;
os << "scoreboard_x20_s4 = " << scoreboard_x20_s4 << std::endl;
os << "scoreboard_x21_s5 = " << scoreboard_x21_s5 << std::endl;
os << "scoreboard_x22_s6 = " << scoreboard_x22_s6 << std::endl;
os << "scoreboard_x23_s7 = " << scoreboard_x23_s7 << std::endl;
os << "scoreboard_x24_s8 = " << scoreboard_x24_s8 << std::endl;
os << "scoreboard_x25_s9 = " << scoreboard_x25_s9 << std::endl;
os << "scoreboard_x26_s10 = " << scoreboard_x26_s10 << std::endl;
os << "scoreboard_x27_s11 = " << scoreboard_x27_s11 << std::endl;
os << "scoreboard_x28_t3 = " << scoreboard_x28_t3 << std::endl;
os << "scoreboard_x29_t4 = " << scoreboard_x29_t4 << std::endl;
os << "scoreboard_x30_t5 = " << scoreboard_x30_t5 << std::endl;
os << "scoreboard_x31_t6 = " << scoreboard_x31_t6 << std::endl;
os << "cycle_count = " << cycle_count << std::endl;
os << "instr_count = " << instr_count << std::endl;
os << "pc = " << pc << std::endl;
os << "epoch = " << epoch << std::endl;
}

static _unused void vcd_header(std::ostream& os) {
#ifndef SIM_VCD_SCOPES
#define SIM_VCD_SCOPES { "TOP", "rv32" }
#endif
cuttlesim::vcd::begin_header(os, SIM_VCD_SCOPES);
cuttlesim::vcd::var(os, "toIMem_data0", 68);
cuttlesim::vcd::var(os, "toIMem_valid0", 1);
cuttlesim::vcd::var(os, "fromIMem_data0", 68);
cuttlesim::vcd::var(os, "fromIMem_valid0", 1);
cuttlesim::vcd::var(os, "toDMem_data0", 68);
cuttlesim::vcd::var(os, "toDMem_valid0", 1);
cuttlesim::vcd::var(os, "fromDMem_data0", 68);
cuttlesim::vcd::var(os, "fromDMem_valid0", 1);
cuttlesim::vcd::var(os, "f2d_data0", 65);
cuttlesim::vcd::var(os, "f2d_valid0", 1);
cuttlesim::vcd::var(os, "f2dprim_data0", 65);
cuttlesim::vcd::var(os, "f2dprim_valid0", 1);
cuttlesim::vcd::var(os, "d2e_data0", 169);
cuttlesim::vcd::var(os, "d2e_valid0", 1);
cuttlesim::vcd::var(os, "e2w_data0", 77);
cuttlesim::vcd::var(os, "e2w_valid0", 1);
cuttlesim::vcd::var(os, "rf_x00_zero", 32);
cuttlesim::vcd::var(os, "rf_x01_ra", 32);
cuttlesim::vcd::var(os, "rf_x02_sp", 32);
cuttlesim::vcd::var(os, "rf_x03_gp", 32);
cuttlesim::vcd::var(os, "rf_x04_tp", 32);
cuttlesim::vcd::var(os, "rf_x05_t0", 32);
cuttlesim::vcd::var(os, "rf_x06_t1", 32);
cuttlesim::vcd::var(os, "rf_x07_t2", 32);
cuttlesim::vcd::var(os, "rf_x08_s0_fp", 32);
cuttlesim::vcd::var(os, "rf_x09_s1", 32);
cuttlesim::vcd::var(os, "rf_x10_a0", 32);
cuttlesim::vcd::var(os, "rf_x11_a1", 32);
cuttlesim::vcd::var(os, "rf_x12_a2", 32);
cuttlesim::vcd::var(os, "rf_x13_a3", 32);
cuttlesim::vcd::var(os, "rf_x14_a4", 32);
cuttlesim::vcd::var(os, "rf_x15_a5", 32);
cuttlesim::vcd::var(os, "rf_x16_a6", 32);
cuttlesim::vcd::var(os, "rf_x17_a7", 32);
cuttlesim::vcd::var(os, "rf_x18_s2", 32);
cuttlesim::vcd::var(os, "rf_x19_s3", 32);
cuttlesim::vcd::var(os, "rf_x20_s4", 32);
cuttlesim::vcd::var(os, "rf_x21_s5", 32);
cuttlesim::vcd::var(os, "rf_x22_s6", 32);
cuttlesim::vcd::var(os, "rf_x23_s7", 32);
cuttlesim::vcd::var(os, "rf_x24_s8", 32);
cuttlesim::vcd::var(os, "rf_x25_s9", 32);
cuttlesim::vcd::var(os, "rf_x26_s10", 32);
cuttlesim::vcd::var(os, "rf_x27_s11", 32);
cuttlesim::vcd::var(os, "rf_x28_t3", 32);
cuttlesim::vcd::var(os, "rf_x29_t4", 32);
cuttlesim::vcd::var(os, "rf_x30_t5", 32);
cuttlesim::vcd::var(os, "rf_x31_t6", 32);
cuttlesim::vcd::var(os, "mulState_valid", 1);
cuttlesim::vcd::var(os, "mulState_operand1", 32);
cuttlesim::vcd::var(os, "mulState_operand2", 32);
cuttlesim::vcd::var(os, "mulState_result", 64);
cuttlesim::vcd::var(os, "mulState_n_step", 5);
cuttlesim::vcd::var(os, "mulState_finished", 1);
cuttlesim::vcd::var(os, "scoreboard_x00_zero", 2);
cuttlesim::vcd::var(os, "scoreboard_x01_ra", 2);
cuttlesim::vcd::var(os, "scoreboard_x02_sp", 2);
cuttlesim::vcd::var(os, "scoreboard_x03_gp", 2);
cuttlesim::vcd::var(os, "scoreboard_x04_tp", 2);
cuttlesim::vcd::var(os, "scoreboard_x05_t0", 2);
cuttlesim::vcd::var(os, "scoreboard_x06_t1", 2);
cuttlesim::vcd::var(os, "scoreboard_x07_t2", 2);
cuttlesim::vcd::var(os, "scoreboard_x08_s0_fp", 2);
cuttlesim::vcd::var(os, "scoreboard_x09_s1", 2);
cuttlesim::vcd::var(os, "scoreboard_x10_a0", 2);
cuttlesim::vcd::var(os, "scoreboard_x11_a1", 2);
cuttlesim::vcd::var(os, "scoreboard_x12_a2", 2);
cuttlesim::vcd::var(os, "scoreboard_x13_a3", 2);
cuttlesim::vcd::var(os, "scoreboard_x14_a4", 2);
cuttlesim::vcd::var(os, "scoreboard_x15_a5", 2);
cuttlesim::vcd::var(os, "scoreboard_x16_a6", 2);
cuttlesim::vcd::var(os, "scoreboard_x17_a7", 2);
cuttlesim::vcd::var(os, "scoreboard_x18_s2", 2);
cuttlesim::vcd::var(os, "scoreboard_x19_s3", 2);
cuttlesim::vcd::var(os, "scoreboard_x20_s4", 2);
cuttlesim::vcd::var(os, "scoreboard_x21_s5", 2);
cuttlesim::vcd::var(os, "scoreboard_x22_s6", 2);
cuttlesim::vcd::var(os, "scoreboard_x23_s7", 2);
cuttlesim::vcd::var(os, "scoreboard_x24_s8", 2);
cuttlesim::vcd::var(os, "scoreboard_x25_s9", 2);
cuttlesim::vcd::var(os, "scoreboard_x26_s10", 2);
cuttlesim::vcd::var(os, "scoreboard_x27_s11", 2);
cuttlesim::vcd::var(os, "scoreboard_x28_t3", 2);
cuttlesim::vcd::var(os, "scoreboard_x29_t4", 2);
cuttlesim::vcd::var(os, "scoreboard_x30_t5", 2);
cuttlesim::vcd::var(os, "scoreboard_x31_t6", 2);
cuttlesim::vcd::var(os, "cycle_count", 32);
cuttlesim::vcd::var(os, "instr_count", 32);
cuttlesim::vcd::var(os, "pc", 32);
cuttlesim::vcd::var(os, "epoch", 1);
cuttlesim::vcd::end_header(os, SIM_VCD_SCOPES);
}

void vcd_dumpvars(std::uint_fast64_t cycle_id, _unused std::ostream& os, const state_t& previous, const bool force) const {
os << '#' << cycle_id << std::endl;
cuttlesim::vcd::dumpvar(os, "toIMem_data0", toIMem_data0, previous.toIMem_data0, force);
cuttlesim::vcd::dumpvar(os, "toIMem_valid0", toIMem_valid0, previous.toIMem_valid0, force);
cuttlesim::vcd::dumpvar(os, "fromIMem_data0", fromIMem_data0, previous.fromIMem_data0, force);
cuttlesim::vcd::dumpvar(os, "fromIMem_valid0", fromIMem_valid0, previous.fromIMem_valid0, force);
cuttlesim::vcd::dumpvar(os, "toDMem_data0", toDMem_data0, previous.toDMem_data0, force);
cuttlesim::vcd::dumpvar(os, "toDMem_valid0", toDMem_valid0, previous.toDMem_valid0, force);
cuttlesim::vcd::dumpvar(os, "fromDMem_data0", fromDMem_data0, previous.fromDMem_data0, force);
cuttlesim::vcd::dumpvar(os, "fromDMem_valid0", fromDMem_valid0, previous.fromDMem_valid0, force);
cuttlesim::vcd::dumpvar(os, "f2d_data0", f2d_data0, previous.f2d_data0, force);
cuttlesim::vcd::dumpvar(os, "f2d_valid0", f2d_valid0, previous.f2d_valid0, force);
cuttlesim::vcd::dumpvar(os, "f2dprim_data0", f2dprim_data0, previous.f2dprim_data0, force);
cuttlesim::vcd::dumpvar(os, "f2dprim_valid0", f2dprim_valid0, previous.f2dprim_valid0, force);
cuttlesim::vcd::dumpvar(os, "d2e_data0", d2e_data0, previous.d2e_data0, force);
cuttlesim::vcd::dumpvar(os, "d2e_valid0", d2e_valid0, previous.d2e_valid0, force);
cuttlesim::vcd::dumpvar(os, "e2w_data0", e2w_data0, previous.e2w_data0, force);
cuttlesim::vcd::dumpvar(os, "e2w_valid0", e2w_valid0, previous.e2w_valid0, force);
cuttlesim::vcd::dumpvar(os, "rf_x00_zero", rf_x00_zero, previous.rf_x00_zero, force);
cuttlesim::vcd::dumpvar(os, "rf_x01_ra", rf_x01_ra, previous.rf_x01_ra, force);
cuttlesim::vcd::dumpvar(os, "rf_x02_sp", rf_x02_sp, previous.rf_x02_sp, force);
cuttlesim::vcd::dumpvar(os, "rf_x03_gp", rf_x03_gp, previous.rf_x03_gp, force);
cuttlesim::vcd::dumpvar(os, "rf_x04_tp", rf_x04_tp, previous.rf_x04_tp, force);
cuttlesim::vcd::dumpvar(os, "rf_x05_t0", rf_x05_t0, previous.rf_x05_t0, force);
cuttlesim::vcd::dumpvar(os, "rf_x06_t1", rf_x06_t1, previous.rf_x06_t1, force);
cuttlesim::vcd::dumpvar(os, "rf_x07_t2", rf_x07_t2, previous.rf_x07_t2, force);
cuttlesim::vcd::dumpvar(os, "rf_x08_s0_fp", rf_x08_s0_fp, previous.rf_x08_s0_fp, force);
cuttlesim::vcd::dumpvar(os, "rf_x09_s1", rf_x09_s1, previous.rf_x09_s1, force);
cuttlesim::vcd::dumpvar(os, "rf_x10_a0", rf_x10_a0, previous.rf_x10_a0, force);
cuttlesim::vcd::dumpvar(os, "rf_x11_a1", rf_x11_a1, previous.rf_x11_a1, force);
cuttlesim::vcd::dumpvar(os, "rf_x12_a2", rf_x12_a2, previous.rf_x12_a2, force);
cuttlesim::vcd::dumpvar(os, "rf_x13_a3", rf_x13_a3, previous.rf_x13_a3, force);
cuttlesim::vcd::dumpvar(os, "rf_x14_a4", rf_x14_a4, previous.rf_x14_a4, force);
cuttlesim::vcd::dumpvar(os, "rf_x15_a5", rf_x15_a5, previous.rf_x15_a5, force);
cuttlesim::vcd::dumpvar(os, "rf_x16_a6", rf_x16_a6, previous.rf_x16_a6, force);
cuttlesim::vcd::dumpvar(os, "rf_x17_a7", rf_x17_a7, previous.rf_x17_a7, force);
cuttlesim::vcd::dumpvar(os, "rf_x18_s2", rf_x18_s2, previous.rf_x18_s2, force);
cuttlesim::vcd::dumpvar(os, "rf_x19_s3", rf_x19_s3, previous.rf_x19_s3, force);
cuttlesim::vcd::dumpvar(os, "rf_x20_s4", rf_x20_s4, previous.rf_x20_s4, force);
cuttlesim::vcd::dumpvar(os, "rf_x21_s5", rf_x21_s5, previous.rf_x21_s5, force);
cuttlesim::vcd::dumpvar(os, "rf_x22_s6", rf_x22_s6, previous.rf_x22_s6, force);
cuttlesim::vcd::dumpvar(os, "rf_x23_s7", rf_x23_s7, previous.rf_x23_s7, force);
cuttlesim::vcd::dumpvar(os, "rf_x24_s8", rf_x24_s8, previous.rf_x24_s8, force);
cuttlesim::vcd::dumpvar(os, "rf_x25_s9", rf_x25_s9, previous.rf_x25_s9, force);
cuttlesim::vcd::dumpvar(os, "rf_x26_s10", rf_x26_s10, previous.rf_x26_s10, force);
cuttlesim::vcd::dumpvar(os, "rf_x27_s11", rf_x27_s11, previous.rf_x27_s11, force);
cuttlesim::vcd::dumpvar(os, "rf_x28_t3", rf_x28_t3, previous.rf_x28_t3, force);
cuttlesim::vcd::dumpvar(os, "rf_x29_t4", rf_x29_t4, previous.rf_x29_t4, force);
cuttlesim::vcd::dumpvar(os, "rf_x30_t5", rf_x30_t5, previous.rf_x30_t5, force);
cuttlesim::vcd::dumpvar(os, "rf_x31_t6", rf_x31_t6, previous.rf_x31_t6, force);
cuttlesim::vcd::dumpvar(os, "mulState_valid", mulState_valid, previous.mulState_valid, force);
cuttlesim::vcd::dumpvar(os, "mulState_operand1", mulState_operand1, previous.mulState_operand1, force);
cuttlesim::vcd::dumpvar(os, "mulState_operand2", mulState_operand2, previous.mulState_operand2, force);
cuttlesim::vcd::dumpvar(os, "mulState_result", mulState_result, previous.mulState_result, force);
cuttlesim::vcd::dumpvar(os, "mulState_n_step", mulState_n_step, previous.mulState_n_step, force);
cuttlesim::vcd::dumpvar(os, "mulState_finished", mulState_finished, previous.mulState_finished, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x00_zero", scoreboard_x00_zero, previous.scoreboard_x00_zero, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x01_ra", scoreboard_x01_ra, previous.scoreboard_x01_ra, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x02_sp", scoreboard_x02_sp, previous.scoreboard_x02_sp, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x03_gp", scoreboard_x03_gp, previous.scoreboard_x03_gp, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x04_tp", scoreboard_x04_tp, previous.scoreboard_x04_tp, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x05_t0", scoreboard_x05_t0, previous.scoreboard_x05_t0, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x06_t1", scoreboard_x06_t1, previous.scoreboard_x06_t1, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x07_t2", scoreboard_x07_t2, previous.scoreboard_x07_t2, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x08_s0_fp", scoreboard_x08_s0_fp, previous.scoreboard_x08_s0_fp, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x09_s1", scoreboard_x09_s1, previous.scoreboard_x09_s1, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x10_a0", scoreboard_x10_a0, previous.scoreboard_x10_a0, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x11_a1", scoreboard_x11_a1, previous.scoreboard_x11_a1, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x12_a2", scoreboard_x12_a2, previous.scoreboard_x12_a2, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x13_a3", scoreboard_x13_a3, previous.scoreboard_x13_a3, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x14_a4", scoreboard_x14_a4, previous.scoreboard_x14_a4, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x15_a5", scoreboard_x15_a5, previous.scoreboard_x15_a5, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x16_a6", scoreboard_x16_a6, previous.scoreboard_x16_a6, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x17_a7", scoreboard_x17_a7, previous.scoreboard_x17_a7, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x18_s2", scoreboard_x18_s2, previous.scoreboard_x18_s2, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x19_s3", scoreboard_x19_s3, previous.scoreboard_x19_s3, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x20_s4", scoreboard_x20_s4, previous.scoreboard_x20_s4, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x21_s5", scoreboard_x21_s5, previous.scoreboard_x21_s5, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x22_s6", scoreboard_x22_s6, previous.scoreboard_x22_s6, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x23_s7", scoreboard_x23_s7, previous.scoreboard_x23_s7, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x24_s8", scoreboard_x24_s8, previous.scoreboard_x24_s8, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x25_s9", scoreboard_x25_s9, previous.scoreboard_x25_s9, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x26_s10", scoreboard_x26_s10, previous.scoreboard_x26_s10, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x27_s11", scoreboard_x27_s11, previous.scoreboard_x27_s11, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x28_t3", scoreboard_x28_t3, previous.scoreboard_x28_t3, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x29_t4", scoreboard_x29_t4, previous.scoreboard_x29_t4, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x30_t5", scoreboard_x30_t5, previous.scoreboard_x30_t5, force);
cuttlesim::vcd::dumpvar(os, "scoreboard_x31_t6", scoreboard_x31_t6, previous.scoreboard_x31_t6, force);
cuttlesim::vcd::dumpvar(os, "cycle_count", cycle_count, previous.cycle_count, force);
cuttlesim::vcd::dumpvar(os, "instr_count", instr_count, previous.instr_count, force);
cuttlesim::vcd::dumpvar(os, "pc", pc, previous.pc, force);
cuttlesim::vcd::dumpvar(os, "epoch", epoch, previous.epoch, force);
}

std::uint_fast64_t vcd_readvars(_unused std::istream& is) {
std::string var{}, val{};
std::uint_fast64_t cycle_id = std::numeric_limits<std::uint_fast64_t>::max();
cuttlesim::vcd::read_header(is);
while (cuttlesim::vcd::readvar(is, cycle_id, var, val)) {
if (var == "toIMem_data0") {
toIMem_data0 = prims::unpack<struct_mem_req>(bits<68>::of_str(val));
}
else if (var == "toIMem_valid0") {
toIMem_valid0 = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "fromIMem_data0") {
fromIMem_data0 = prims::unpack<struct_mem_resp>(bits<68>::of_str(val));
}
else if (var == "fromIMem_valid0") {
fromIMem_valid0 = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "toDMem_data0") {
toDMem_data0 = prims::unpack<struct_mem_req>(bits<68>::of_str(val));
}
else if (var == "toDMem_valid0") {
toDMem_valid0 = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "fromDMem_data0") {
fromDMem_data0 = prims::unpack<struct_mem_resp>(bits<68>::of_str(val));
}
else if (var == "fromDMem_valid0") {
fromDMem_valid0 = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "f2d_data0") {
f2d_data0 = prims::unpack<struct_fetch_bookkeeping>(bits<65>::of_str(val));
}
else if (var == "f2d_valid0") {
f2d_valid0 = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "f2dprim_data0") {
f2dprim_data0 = prims::unpack<struct_fetch_bookkeeping>(bits<65>::of_str(val));
}
else if (var == "f2dprim_valid0") {
f2dprim_valid0 = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "d2e_data0") {
d2e_data0 = prims::unpack<struct_decode_bookkeeping>(bits<169>::of_str(val));
}
else if (var == "d2e_valid0") {
d2e_valid0 = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "e2w_data0") {
e2w_data0 = prims::unpack<struct_execute_bookkeeping>(bits<77>::of_str(val));
}
else if (var == "e2w_valid0") {
e2w_valid0 = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "rf_x00_zero") {
rf_x00_zero = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x01_ra") {
rf_x01_ra = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x02_sp") {
rf_x02_sp = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x03_gp") {
rf_x03_gp = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x04_tp") {
rf_x04_tp = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x05_t0") {
rf_x05_t0 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x06_t1") {
rf_x06_t1 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x07_t2") {
rf_x07_t2 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x08_s0_fp") {
rf_x08_s0_fp = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x09_s1") {
rf_x09_s1 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x10_a0") {
rf_x10_a0 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x11_a1") {
rf_x11_a1 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x12_a2") {
rf_x12_a2 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x13_a3") {
rf_x13_a3 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x14_a4") {
rf_x14_a4 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x15_a5") {
rf_x15_a5 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x16_a6") {
rf_x16_a6 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x17_a7") {
rf_x17_a7 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x18_s2") {
rf_x18_s2 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x19_s3") {
rf_x19_s3 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x20_s4") {
rf_x20_s4 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x21_s5") {
rf_x21_s5 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x22_s6") {
rf_x22_s6 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x23_s7") {
rf_x23_s7 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x24_s8") {
rf_x24_s8 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x25_s9") {
rf_x25_s9 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x26_s10") {
rf_x26_s10 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x27_s11") {
rf_x27_s11 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x28_t3") {
rf_x28_t3 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x29_t4") {
rf_x29_t4 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x30_t5") {
rf_x30_t5 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "rf_x31_t6") {
rf_x31_t6 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "mulState_valid") {
mulState_valid = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "mulState_operand1") {
mulState_operand1 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "mulState_operand2") {
mulState_operand2 = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "mulState_result") {
mulState_result = prims::unpack<bits<64>>(bits<64>::of_str(val));
}
else if (var == "mulState_n_step") {
mulState_n_step = prims::unpack<bits<5>>(bits<5>::of_str(val));
}
else if (var == "mulState_finished") {
mulState_finished = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
else if (var == "scoreboard_x00_zero") {
scoreboard_x00_zero = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x01_ra") {
scoreboard_x01_ra = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x02_sp") {
scoreboard_x02_sp = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x03_gp") {
scoreboard_x03_gp = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x04_tp") {
scoreboard_x04_tp = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x05_t0") {
scoreboard_x05_t0 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x06_t1") {
scoreboard_x06_t1 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x07_t2") {
scoreboard_x07_t2 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x08_s0_fp") {
scoreboard_x08_s0_fp = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x09_s1") {
scoreboard_x09_s1 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x10_a0") {
scoreboard_x10_a0 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x11_a1") {
scoreboard_x11_a1 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x12_a2") {
scoreboard_x12_a2 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x13_a3") {
scoreboard_x13_a3 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x14_a4") {
scoreboard_x14_a4 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x15_a5") {
scoreboard_x15_a5 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x16_a6") {
scoreboard_x16_a6 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x17_a7") {
scoreboard_x17_a7 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x18_s2") {
scoreboard_x18_s2 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x19_s3") {
scoreboard_x19_s3 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x20_s4") {
scoreboard_x20_s4 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x21_s5") {
scoreboard_x21_s5 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x22_s6") {
scoreboard_x22_s6 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x23_s7") {
scoreboard_x23_s7 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x24_s8") {
scoreboard_x24_s8 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x25_s9") {
scoreboard_x25_s9 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x26_s10") {
scoreboard_x26_s10 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x27_s11") {
scoreboard_x27_s11 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x28_t3") {
scoreboard_x28_t3 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x29_t4") {
scoreboard_x29_t4 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x30_t5") {
scoreboard_x30_t5 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "scoreboard_x31_t6") {
scoreboard_x31_t6 = prims::unpack<bits<2>>(bits<2>::of_str(val));
}
else if (var == "cycle_count") {
cycle_count = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "instr_count") {
instr_count = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "pc") {
pc = prims::unpack<bits<32>>(bits<32>::of_str(val));
}
else if (var == "epoch") {
epoch = prims::unpack<bits<1>>(bits<1>::of_str(val));
}
}
return cycle_id;
}
#endif
};

using snapshot_t = cuttlesim::snapshot_t<state_t>;

protected:
struct rwset_t {
cuttlesim::ehr_rwset mulState_valid;
cuttlesim::reg_rwset mulState_operand1;
cuttlesim::reg_rwset mulState_operand2;
cuttlesim::ehr_rwset mulState_result;
cuttlesim::reg_rwset mulState_n_step;
cuttlesim::ehr_rwset mulState_finished;
};

struct log_t {
rwset_t rwset;
state_t state;

const state_t& snapshot() const {
return state;
}
explicit log_t(const state_t& init) : rwset{}, state(init) {
}
};

log_t log;
log_t Log;
extfuns_t extfuns;
cuttlesim::sim_metadata meta;

#ifndef SIM_MINIMAL
std::default_random_engine rng{};
std::uniform_int_distribution<int> uniform{0, 8};
#endif

#define RULE_NAME Dmem
DEF_RESET(Dmem) {
log.state.toDMem_valid0 = Log.state.toDMem_valid0;
log.state.fromDMem_data0 = Log.state.fromDMem_data0;
log.state.fromDMem_valid0 = Log.state.fromDMem_valid0;
}

DEF_COMMIT(Dmem) {
Log.state.toDMem_valid0 = log.state.toDMem_valid0;
Log.state.fromDMem_data0 = log.state.fromDMem_data0;
Log.state.fromDMem_valid0 = log.state.fromDMem_valid0;
}

DECL_FN(can_enq_0, bits<1>)
DEF_FN(can_enq_0, bits<1> &_ret) {
bits<1> _x0 = READ1_FAST(fromDMem_valid0);
_ret = ~(_x0);
return true;
}

DECL_FN(peek_0, struct_maybe_mem_req)
DEF_FN(peek_0, struct_maybe_mem_req &_ret) {
bits<1> _test0 = CALL_FN(can_deq_0);
if (_test0) {
struct_mem_req _x1 = READ1_FAST(toDMem_data0);
_ret = CALL_FN(valid_0, _x1);
}
else {
_ret = CALL_FN(invalid_0);
}
return true;
}

DECL_FN(can_deq_0, bits<1>)
DEF_FN(can_deq_0, bits<1> &_ret) {
_ret = READ1_FAST(toDMem_valid0);
return true;
}

DECL_FN(valid_0, struct_maybe_mem_req)
DEF_FN(valid_0, struct_maybe_mem_req &_ret, struct_mem_req x) {
_ret = struct_maybe_mem_req{};
_ret.valid = 1'1_b;
_ret.data = x;
return true;
}

DECL_FN(invalid_0, struct_maybe_mem_req)
DEF_FN(invalid_0, struct_maybe_mem_req &_ret) {
_ret = struct_maybe_mem_req{};
_ret.valid = 1'0_b;
return true;
}

DECL_FN(memoryBus_0, struct_mem_output)
DEF_FN(memoryBus_0, struct_mem_output &_ret, bits<1> get_ready, bits<1> put_valid, struct_mem_req put_request) {
bits<32> addr = put_request.addr;
bits<4> byte_en = put_request.byte_en;
bits<1> is_write = (byte_en == 4'1111_b);
bits<1> is_uart = (addr == 0x32'40000000_x);
bits<1> is_uart_read = (is_uart & ~(is_write));
bits<1> is_uart_write = (is_uart & is_write);
bits<1> is_led = (addr == 0x32'40000004_x);
bits<1> is_led_write = (is_led & is_write);
bits<1> is_finish = (addr == 0x32'40001000_x);
bits<1> is_finish_write = (is_finish & is_write);
bits<1> is_host_id = (addr == 0x32'40001004_x);
bits<1> is_host_id_read = (is_host_id & ~(is_write));
bits<1> is_mem = (~(is_uart) & (~(is_led) & (~(is_finish) & ~(is_host_id))));
if (is_uart_write) {
bits<8> renamed_cppchar = prims::islice<8>(put_request.data, 5'00000_b);
bits<1> may_run = (get_ready & (put_valid & is_uart_write));
struct_maybe_bits_8 _x17 = struct_maybe_bits_8{};
_x17.valid = may_run;
_x17.data = renamed_cppchar;
bits<1> ready = extfuns.ext_uart_write(_x17);
_ret = struct_mem_output{};
_ret.get_valid = (may_run & ready);
_ret.put_ready = (may_run & ready);
struct_mem_resp _y25 = struct_mem_resp{};
_y25.byte_en = byte_en;
_y25.addr = addr;
_y25.data = 32'0_b;
_ret.get_response = _y25;
}
else {
if (is_uart_read) {
bits<1> may_run = (get_ready & (put_valid & is_uart_read));
struct_maybe_bits_8 opt_char = extfuns.ext_uart_read(may_run);
bits<1> ready = opt_char.valid;
_ret = struct_mem_output{};
_ret.get_valid = (may_run & ready);
_ret.put_ready = (may_run & ready);
struct_mem_resp _y35 = struct_mem_resp{};
_y35.byte_en = byte_en;
_y35.addr = addr;
_y35.data = prims::zextl<32>(opt_char.data);
_ret.get_response = _y35;
}
else {
if (is_led) {
bits<1> on = put_request.data[5'00000_b];
bits<1> may_run = (get_ready & (put_valid & is_led_write));
struct_maybe_bits_1 _x24 = struct_maybe_bits_1{};
_x24.valid = may_run;
_x24.data = on;
bits<1> current = extfuns.ext_led(_x24);
bits<1> ready = 1'1_b;
_ret = struct_mem_output{};
_ret.get_valid = (may_run & ready);
_ret.put_ready = (may_run & ready);
struct_mem_resp _y48 = struct_mem_resp{};
_y48.byte_en = byte_en;
_y48.addr = addr;
_y48.data = prims::zextl<32>(current);
_ret.get_response = _y48;
}
else {
if (is_finish) {
bits<8> renamed_cppchar = prims::islice<8>(put_request.data, 5'00000_b);
bits<1> may_run = (get_ready & (put_valid & is_finish_write));
struct_maybe_bits_8 _x28 = struct_maybe_bits_8{};
_x28.valid = may_run;
_x28.data = renamed_cppchar;
bits<1> response = extfuns.ext_finish(*this, _x28);
bits<1> ready = 1'1_b;
_ret = struct_mem_output{};
_ret.get_valid = (may_run & ready);
_ret.put_ready = (may_run & ready);
struct_mem_resp _y61 = struct_mem_resp{};
_y61.byte_en = byte_en;
_y61.addr = addr;
_y61.data = prims::zextl<32>(response);
_ret.get_response = _y61;
}
else {
if (is_host_id) {
bits<1> may_run = (get_ready & (put_valid & is_host_id_read));
enum_hostID _x30 = extfuns.ext_host_id(1'1_b);
bits<8> response = prims::pack(_x30);
bits<1> ready = 1'1_b;
_ret = struct_mem_output{};
_ret.get_valid = (may_run & ready);
_ret.put_ready = (may_run & ready);
struct_mem_resp _y71 = struct_mem_resp{};
_y71.byte_en = byte_en;
_y71.addr = addr;
_y71.data = prims::zextl<32>(response);
_ret.get_response = _y71;
}
else {
struct_mem_input _x33 = struct_mem_input{};
_x33.get_ready = (get_ready & is_mem);
_x33.put_valid = (put_valid & is_mem);
_x33.put_request = put_request;
_ret = extfuns.ext_mem_dmem(_x33);
}
}
}
}
}
return true;
}

DECL_FN(enq_0, unit)
DEF_FN(enq_0, unit &_ret, struct_mem_resp data) {
bits<1> _x34 = CALL_FN(can_enq_1);
if (~(_x34)) {
FAIL_FAST();
}
WRITE1_FAST(fromDMem_data0, data);
WRITE1_FAST(fromDMem_valid0, 1'1_b);
_ret = prims::tt;
return true;
}

DECL_FN(can_enq_1, bits<1>)
DEF_FN(can_enq_1, bits<1> &_ret) {
bits<1> _x35 = READ1_FAST(fromDMem_valid0);
_ret = ~(_x35);
return true;
}

DECL_FN(deq_0, struct_mem_req)
DEF_FN(deq_0, struct_mem_req &_ret) {
bits<1> _x36 = CALL_FN(can_deq_1);
if (~(_x36)) {
FAIL();
}
WRITE1_FAST(toDMem_valid0, 1'0_b);
_ret = READ1_FAST(toDMem_data0);
return true;
}

DECL_FN(can_deq_1, bits<1>)
DEF_FN(can_deq_1, bits<1> &_ret) {
_ret = READ1_FAST(toDMem_valid0);
return true;
}
DEF_RULE(Dmem) {
bits<1> get_ready = CALL_FN(can_enq_0);
struct_maybe_mem_req put_request_opt = CALL_FN(peek_0);
struct_mem_req put_request = put_request_opt.data;
bits<1> put_valid = put_request_opt.valid;
struct_mem_output mem_out = CALL_FN(memoryBus_0, get_ready, put_valid, put_request);
if ((get_ready & mem_out.get_valid)) {
CALL_FN(enq_0, mem_out.get_response);
}
if ((put_valid & mem_out.put_ready)) {
CALL_FN(deq_0);
}

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME Execute
DEF_RESET(Execute) {
log.state.toDMem_data0 = Log.state.toDMem_data0;
log.state.toDMem_valid0 = Log.state.toDMem_valid0;
log.state.d2e_valid0 = Log.state.d2e_valid0;
log.state.e2w_data0 = Log.state.e2w_data0;
log.state.e2w_valid0 = Log.state.e2w_valid0;
log.state.mulState_valid = Log.state.mulState_valid;
log.state.mulState_operand1 = Log.state.mulState_operand1;
log.state.mulState_operand2 = Log.state.mulState_operand2;
log.state.mulState_result = Log.state.mulState_result;
log.state.mulState_n_step = Log.state.mulState_n_step;
log.state.pc = Log.state.pc;
log.state.epoch = Log.state.epoch;
log.rwset.mulState_valid = Log.rwset.mulState_valid;
log.rwset.mulState_operand1 = Log.rwset.mulState_operand1;
log.rwset.mulState_operand2 = Log.rwset.mulState_operand2;
log.rwset.mulState_result = Log.rwset.mulState_result;
log.rwset.mulState_n_step = Log.rwset.mulState_n_step;
}

DEF_COMMIT(Execute) {
Log.state.toDMem_data0 = log.state.toDMem_data0;
Log.state.toDMem_valid0 = log.state.toDMem_valid0;
Log.state.d2e_valid0 = log.state.d2e_valid0;
Log.state.e2w_data0 = log.state.e2w_data0;
Log.state.e2w_valid0 = log.state.e2w_valid0;
Log.state.mulState_valid = log.state.mulState_valid;
Log.state.mulState_operand1 = log.state.mulState_operand1;
Log.state.mulState_operand2 = log.state.mulState_operand2;
Log.state.mulState_result = log.state.mulState_result;
Log.state.mulState_n_step = log.state.mulState_n_step;
Log.state.pc = log.state.pc;
Log.state.epoch = log.state.epoch;
Log.rwset.mulState_valid = log.rwset.mulState_valid;
Log.rwset.mulState_operand1 = log.rwset.mulState_operand1;
Log.rwset.mulState_operand2 = log.rwset.mulState_operand2;
Log.rwset.mulState_result = log.rwset.mulState_result;
Log.rwset.mulState_n_step = log.rwset.mulState_n_step;
}

DECL_FN(deq_1, struct_decode_bookkeeping)
DEF_FN(deq_1, struct_decode_bookkeeping &_ret) {
bits<1> _x0 = CALL_FN(can_deq_2);
if (~(_x0)) {
FAIL_FAST();
}
WRITE0_FAST(d2e_valid0, 1'0_b);
_ret = READ0_FAST(d2e_data0);
return true;
}

DECL_FN(can_deq_2, bits<1>)
DEF_FN(can_deq_2, bits<1> &_ret) {
_ret = READ0_FAST(d2e_valid0);
return true;
}

DECL_FN(getFields_0, struct_instFields)
DEF_FN(getFields_0, struct_instFields &_ret, bits<32> inst) {
struct_instFields res = struct_instFields{};
res.opcode = prims::islice<7>(inst, 5'00000_b);
res.funct3 = prims::islice<3>(inst, 5'01100_b);
res.funct7 = prims::islice<7>(inst, 5'11001_b);
res.funct5 = prims::islice<5>(inst, 5'11011_b);
res.funct2 = prims::islice<2>(inst, 5'11001_b);
res.rd = prims::islice<5>(inst, 5'00111_b);
res.rs1 = prims::islice<5>(inst, 5'01111_b);
res.rs2 = prims::islice<5>(inst, 5'10100_b);
res.rs3 = prims::islice<5>(inst, 5'11011_b);
bits<32> _y18 = CALL_FN(signExtend_0, prims::islice<12>(inst, 5'10100_b));
res.immI = _y18;
bits<32> _y20 = CALL_FN(signExtend_0, prims::concat(prims::islice<7>(inst, 5'11001_b), prims::islice<5>(inst, 5'00111_b)));
res.immS = _y20;
bits<32> _y24 = CALL_FN(signExtend_1, prims::concat(inst[5'11111_b], prims::concat(inst[5'00111_b], prims::concat(prims::islice<6>(inst, 5'11001_b), prims::concat(prims::islice<4>(inst, 5'01000_b), 1'0_b)))));
res.immB = _y24;
res.immU = prims::concat(prims::islice<20>(inst, 5'01100_b), 12'0_b);
bits<32> _y36 = CALL_FN(signExtend_2, prims::concat(inst[5'11111_b], prims::concat(prims::islice<8>(inst, 5'01100_b), prims::concat(inst[5'10100_b], prims::concat(prims::islice<10>(inst, 5'10101_b), 1'0_b)))));
res.immJ = _y36;
res.csr = prims::islice<12>(inst, 5'10100_b);
_ret = res;
return true;
}

DECL_FN(signExtend_0, bits<32>)
DEF_FN(signExtend_0, bits<32> &_ret, bits<12> arg) {
_ret = prims::sext<32>(arg);
return true;
}

DECL_FN(signExtend_1, bits<32>)
DEF_FN(signExtend_1, bits<32> &_ret, bits<13> arg) {
_ret = prims::sext<32>(arg);
return true;
}

DECL_FN(signExtend_2, bits<32>)
DEF_FN(signExtend_2, bits<32> &_ret, bits<21> arg) {
_ret = prims::sext<32>(arg);
return true;
}

DECL_FN(getImmediate_0, bits<32>)
DEF_FN(getImmediate_0, bits<32> &_ret, struct_decodedInst dInst) {
struct_maybe_immType imm_type_v = dInst.immediateType;
if ((imm_type_v.valid == 1'1_b)) {
struct_instFields fields = CALL_FN(getFields_0, dInst.inst);
enum_immType renamed_cpp_dx2_reserved_dx2_matchPattern = imm_type_v.data;
switch (renamed_cpp_dx2_reserved_dx2_matchPattern) {
case enum_immType::ImmI: {
_ret = fields.immI;
}
break;
case enum_immType::ImmS: {
_ret = fields.immS;
}
break;
case enum_immType::ImmB: {
_ret = fields.immB;
}
break;
case enum_immType::ImmU: {
_ret = fields.immU;
}
break;
case enum_immType::ImmJ: {
_ret = fields.immJ;
}
break;
default: {
_ret = 32'0_b;
}
break;
}
}
else {
_ret = 32'0_b;
}
return true;
}

DECL_FN(execALU32_0, bits<32>)
DEF_FN(execALU32_0, bits<32> &_ret, bits<32> inst, bits<32> rs1_val, bits<32> rs2_val, bits<32> imm_val, bits<32> pc) {
bits<1> isLUI = ((inst[5'00010_b] == 1'1_b) & (inst[5'00101_b] == 1'1_b));
bits<1> isAUIPC = ((inst[5'00010_b] == 1'1_b) & (inst[5'00101_b] == 1'0_b));
bits<1> isIMM = (inst[5'00101_b] == 1'0_b);
bits<32> rd_val = 32'0_b;
if (isLUI) {
rd_val = imm_val;
}
else {
if (isAUIPC) {
rd_val = (pc + imm_val);
}
else {
bits<32> alu_src1 = rs1_val;
bits<32> alu_src2;
if (isIMM) {
alu_src2 = imm_val;
}
else {
alu_src2 = rs2_val;
}
struct_instFields _x50 = CALL_FN(getFields_0, inst);
bits<3> funct3 = _x50.funct3;
struct_instFields _x51 = CALL_FN(getFields_0, inst);
bits<7> funct7 = _x51.funct7;
struct_instFields _x52 = CALL_FN(getFields_0, inst);
bits<7> opcode = _x52.opcode;
if ((((funct3 == 3'001_b) & isIMM) | (opcode == 7'1100011_b))) {
funct7 = 7'0000000_b;
}
rd_val = CALL_FN(alu32_0, funct3, funct7, alu_src1, alu_src2);
}
}
_ret = rd_val;
return true;
}

DECL_FN(alu32_0, bits<32>)
DEF_FN(alu32_0, bits<32> &_ret, bits<3> funct3, bits<7> funct7, bits<32> a, bits<32> b) {
bits<5> shamt = prims::islice<5>(b, 5'00000_b);
bits<1> inst_30 = funct7[3'101_b];
bits<3> renamed_cpp_dx2_reserved_dx2_matchPattern = funct3;
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 3'001_bv: {
if ((inst_30 == 1'1_b)) {
_ret = (a - b);
}
else {
_ret = (a + b);
}
}
break;
case 3'000_bv: {
_ret = (a << shamt);
}
break;
case 3'010_bv: {
_ret = prims::zextl<32>(slt(a, b));
}
break;
case 3'011_bv: {
_ret = prims::zextl<32>((a < b));
}
break;
case 3'100_bv: {
_ret = (a ^ b);
}
break;
case 3'101_bv: {
if ((inst_30 == 1'1_b)) {
_ret = prims::asr(a, shamt);
}
else {
_ret = (a >> shamt);
}
}
break;
case 3'110_bv: {
_ret = (a | b);
}
break;
case 3'111_bv: {
_ret = (a & b);
}
break;
default: {
_ret = 32'0_b;
}
break;
}
return true;
}

DECL_FN(isMemoryInst_0, bits<1>)
DEF_FN(isMemoryInst_0, bits<1> &_ret, struct_decodedInst dInst) {
_ret = ((dInst.inst[5'00110_b] == 1'0_b) & (prims::islice<2>(dInst.inst, 5'00011_b) == 2'00_b));
return true;
}

DECL_FN(enq_1, unit)
DEF_FN(enq_1, unit &_ret, struct_mem_req data) {
bits<1> _x66 = CALL_FN(can_enq_2);
if (~(_x66)) {
FAIL();
}
WRITE0_FAST(toDMem_data0, data);
WRITE0_FAST(toDMem_valid0, 1'1_b);
_ret = prims::tt;
return true;
}

DECL_FN(can_enq_2, bits<1>)
DEF_FN(can_enq_2, bits<1> &_ret) {
bits<1> _x67 = READ0_FAST(toDMem_valid0);
_ret = ~(_x67);
return true;
}

DECL_FN(isControlInst_0, bits<1>)
DEF_FN(isControlInst_0, bits<1> &_ret, struct_decodedInst dInst) {
_ret = (prims::islice<3>(dInst.inst, 5'00100_b) == 3'110_b);
return true;
}

DECL_FN(isMultiplyInst_0, bits<1>)
DEF_FN(isMultiplyInst_0, bits<1> &_ret, struct_decodedInst dInst) {
_ret = CALL_FN(enabled_0);
bits<1> _y86;
/* bind */ {
struct_instFields fields = CALL_FN(getFields_0, dInst.inst);
_y86 = ((fields.funct7 == 7'0000001_b) & ((fields.funct3 == 3'000_b) & (fields.opcode == 7'0110011_b)));
}
_ret = (_ret & _y86);
return true;
}

DECL_FN(enabled_0, bits<1>)
DEF_FN(enabled_0, bits<1> &_ret) {
_ret = 1'1_b;
return true;
}

DECL_FN(enq_2, unit)
DEF_FN(enq_2, unit &_ret, bits<32> op1, bits<32> op2) {
bits<1> _x79 = READ0(mulState_valid);
if (~(~(_x79))) {
FAIL();
}
WRITE0(mulState_valid, 1'1_b);
WRITE0(mulState_operand1, op1);
WRITE0(mulState_operand2, op2);
WRITE0(mulState_result, 64'0_b);
WRITE0(mulState_n_step, 5'00000_b);
_ret = prims::tt;
return true;
}

DECL_FN(execControl32_0, struct_control_result)
DEF_FN(execControl32_0, struct_control_result &_ret, bits<32> inst, bits<32> rs1_val, bits<32> rs2_val, bits<32> imm_val, bits<32> pc) {
bits<1> isControl = (prims::islice<3>(inst, 5'00100_b) == 3'110_b);
bits<1> isJAL = ((inst[5'00010_b] == 1'1_b) & (inst[5'00011_b] == 1'1_b));
bits<1> isJALR = ((inst[5'00010_b] == 1'1_b) & (inst[5'00011_b] == 1'0_b));
bits<32> incPC = (pc + 0x32'0004_x);
struct_instFields _x86 = CALL_FN(getFields_0, inst);
bits<3> funct3 = _x86.funct3;
bits<1> taken = 1'1_b;
bits<32> nextPC = incPC;
if (~(isControl)) {
taken = 1'0_b;
nextPC = incPC;
}
else {
if (isJAL) {
taken = 1'1_b;
nextPC = (pc + imm_val);
}
else {
if (isJALR) {
taken = 1'1_b;
nextPC = ((rs1_val + imm_val) & ~(32'1_b));
}
else {
/* bind */ {
bits<3> renamed_cpp_dx2_reserved_dx2_matchPattern = funct3;
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 3'000_bv: {
taken = (rs1_val == rs2_val);
}
break;
case 3'001_bv: {
taken = (rs1_val != rs2_val);
}
break;
case 3'100_bv: {
taken = slt(rs1_val, rs2_val);
}
break;
case 3'101_bv: {
taken = ~(slt(rs1_val, rs2_val));
}
break;
case 3'110_bv: {
taken = (rs1_val < rs2_val);
}
break;
case 3'111_bv: {
taken = ~((rs1_val < rs2_val));
}
break;
default: {
taken = 1'0_b;
}
break;
}
}
if (taken) {
nextPC = (pc + imm_val);
}
else {
nextPC = incPC;
}
}
}
}
_ret = struct_control_result{};
_ret.taken = taken;
_ret.nextPC = nextPC;
return true;
}

DECL_FN(enq_3, unit)
DEF_FN(enq_3, unit &_ret, struct_execute_bookkeeping data) {
bits<1> _x97 = CALL_FN(can_enq_3);
if (~(_x97)) {
FAIL();
}
WRITE1_FAST(e2w_data0, data);
WRITE1_FAST(e2w_valid0, 1'1_b);
_ret = prims::tt;
return true;
}

DECL_FN(can_enq_3, bits<1>)
DEF_FN(can_enq_3, bits<1> &_ret) {
bits<1> _x98 = READ1_FAST(e2w_valid0);
_ret = ~(_x98);
return true;
}
DEF_RULE(Execute) {
struct_decode_bookkeeping decoded_bookkeeping = CALL_FN(deq_1);
bits<1> _y117 = READ0_FAST(epoch);
if ((decoded_bookkeeping.epoch == _y117)) {
struct_decodedInst dInst = decoded_bookkeeping.dInst;
if ((dInst.legal == 1'0_b)) {
bits<1> _v10 = READ0_FAST(epoch);
WRITE0_FAST(epoch, (_v10 + 1'1_b));
WRITE0_FAST(pc, 32'0_b);
}
else {
bits<32> fInst = dInst.inst;
struct_instFields _x103 = CALL_FN(getFields_0, fInst);
bits<3> funct3 = _x103.funct3;
bits<32> rs1_val = decoded_bookkeeping.rval1;
bits<32> rs2_val = decoded_bookkeeping.rval2;
bits<32> imm = CALL_FN(getImmediate_0, dInst);
bits<32> pc = decoded_bookkeeping.pc;
bits<32> data = CALL_FN(execALU32_0, fInst, rs1_val, rs2_val, imm, pc);
bits<1> isUnsigned = 1'0_b;
bits<2> size = prims::islice<2>(funct3, 2'00_b);
bits<32> addr = (rs1_val + imm);
bits<2> offset = prims::islice<2>(addr, 5'00000_b);
bits<1> _test17 = CALL_FN(isMemoryInst_0, dInst);
if (_test17) {
bits<5> shift_amount = prims::concat(offset, 3'000_b);
bits<1> is_write = (fInst[5'00101_b] == 1'1_b);
bits<4> byte_en;
if (is_write) {
/* bind */ {
bits<2> renamed_cpp_dx2_reserved_dx2_matchPattern = size;
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 2'00_bv: {
byte_en = 4'0001_b;
}
break;
case 2'01_bv: {
byte_en = 4'0011_b;
}
break;
case 2'10_bv: {
byte_en = 4'1111_b;
}
break;
default: {
FAIL();
}
break;
}
}
byte_en = (byte_en << offset);
}
else {
byte_en = 4'0000_b;
}
data = (rs2_val << shift_amount);
addr = prims::concat(prims::islice<30>(addr, 5'00010_b), 2'00_b);
isUnsigned = funct3[2'10_b];
struct_mem_req _data0 = struct_mem_req{};
_data0.byte_en = byte_en;
_data0.addr = addr;
_data0.data = data;
CALL_FN(enq_1, _data0);
}
else {
bits<1> _test19 = CALL_FN(isControlInst_0, dInst);
if (_test19) {
data = (pc + 0x32'0004_x);
}
else {
bits<1> _test20 = CALL_FN(isMultiplyInst_0, dInst);
if (_test20) {
CALL_FN(enq_2, rs1_val, rs2_val);
}
}
}
/* bind */ {
struct_control_result controlResult = CALL_FN(execControl32_0, fInst, rs1_val, rs2_val, imm, pc);
bits<32> nextPc = controlResult.nextPC;
if ((nextPc != decoded_bookkeeping.ppc)) {
bits<1> _v12 = READ0_FAST(epoch);
WRITE0_FAST(epoch, (_v12 + 1'1_b));
WRITE0_FAST(pc, nextPc);
}
/* bind */ {
struct_execute_bookkeeping execute_bookkeeping = struct_execute_bookkeeping{};
execute_bookkeeping.isUnsigned = isUnsigned;
execute_bookkeeping.size = size;
execute_bookkeeping.offset = offset;
execute_bookkeeping.newrd = data;
execute_bookkeeping.dInst = decoded_bookkeeping.dInst;
CALL_FN(enq_3, execute_bookkeeping);
}
}
}
}

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME Tick
DEF_RESET(Tick) {
log.state.cycle_count = Log.state.cycle_count;
}

DEF_COMMIT(Tick) {
Log.state.cycle_count = log.state.cycle_count;
}

DEF_RULE(Tick) {
bits<32> _v0 = READ0_FAST(cycle_count);
WRITE0_FAST(cycle_count, (_v0 + 32'1_b));

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME StepMultiplier
DEF_RESET(StepMultiplier) {
log.state.mulState_result = Log.state.mulState_result;
log.state.mulState_n_step = Log.state.mulState_n_step;
log.state.mulState_finished = Log.state.mulState_finished;
log.rwset.mulState_result = Log.rwset.mulState_result;
log.rwset.mulState_n_step = Log.rwset.mulState_n_step;
log.rwset.mulState_finished = Log.rwset.mulState_finished;
}

DEF_COMMIT(StepMultiplier) {
Log.state.mulState_result = log.state.mulState_result;
Log.state.mulState_n_step = log.state.mulState_n_step;
Log.state.mulState_finished = log.state.mulState_finished;
Log.rwset.mulState_result = log.rwset.mulState_result;
Log.rwset.mulState_n_step = log.rwset.mulState_n_step;
Log.rwset.mulState_finished = log.rwset.mulState_finished;
}

DECL_FN(step_0, unit)
DEF_FN(step_0, unit &_ret) {
bits<1> _x0 = READ0(mulState_valid);
bits<1> _x1 = READ0(mulState_finished);
if (~((_x0 & ~(_x1)))) {
FAIL_FAST();
}
bits<5> n_step_val = READ0(mulState_n_step);
bits<32> _x2 = READ0(mulState_operand2);
if (_x2[n_step_val]) {
bits<32> _x3 = READ0(mulState_operand1);
bits<64> partial_mul = (prims::zextl<64>(_x3) << n_step_val);
bits<64> _v0 = READ0(mulState_result);
WRITE0(mulState_result, (_v0 + partial_mul));
}
if ((n_step_val == 5'11111_b)) {
WRITE0(mulState_finished, 1'1_b);
_ret = prims::tt;
}
else {
WRITE0(mulState_n_step, (n_step_val + 5'00001_b));
_ret = prims::tt;
}
return true;
}
DEF_RULE(StepMultiplier) {
CALL_FN(step_0);

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME Writeback
DEF_RESET(Writeback) {
log.state.fromDMem_valid0 = Log.state.fromDMem_valid0;
log.state.e2w_valid0 = Log.state.e2w_valid0;
log.state.rf_x00_zero = Log.state.rf_x00_zero;
log.state.rf_x01_ra = Log.state.rf_x01_ra;
log.state.rf_x02_sp = Log.state.rf_x02_sp;
log.state.rf_x03_gp = Log.state.rf_x03_gp;
log.state.rf_x04_tp = Log.state.rf_x04_tp;
log.state.rf_x05_t0 = Log.state.rf_x05_t0;
log.state.rf_x06_t1 = Log.state.rf_x06_t1;
log.state.rf_x07_t2 = Log.state.rf_x07_t2;
log.state.rf_x08_s0_fp = Log.state.rf_x08_s0_fp;
log.state.rf_x09_s1 = Log.state.rf_x09_s1;
log.state.rf_x10_a0 = Log.state.rf_x10_a0;
log.state.rf_x11_a1 = Log.state.rf_x11_a1;
log.state.rf_x12_a2 = Log.state.rf_x12_a2;
log.state.rf_x13_a3 = Log.state.rf_x13_a3;
log.state.rf_x14_a4 = Log.state.rf_x14_a4;
log.state.rf_x15_a5 = Log.state.rf_x15_a5;
log.state.rf_x16_a6 = Log.state.rf_x16_a6;
log.state.rf_x17_a7 = Log.state.rf_x17_a7;
log.state.rf_x18_s2 = Log.state.rf_x18_s2;
log.state.rf_x19_s3 = Log.state.rf_x19_s3;
log.state.rf_x20_s4 = Log.state.rf_x20_s4;
log.state.rf_x21_s5 = Log.state.rf_x21_s5;
log.state.rf_x22_s6 = Log.state.rf_x22_s6;
log.state.rf_x23_s7 = Log.state.rf_x23_s7;
log.state.rf_x24_s8 = Log.state.rf_x24_s8;
log.state.rf_x25_s9 = Log.state.rf_x25_s9;
log.state.rf_x26_s10 = Log.state.rf_x26_s10;
log.state.rf_x27_s11 = Log.state.rf_x27_s11;
log.state.rf_x28_t3 = Log.state.rf_x28_t3;
log.state.rf_x29_t4 = Log.state.rf_x29_t4;
log.state.rf_x30_t5 = Log.state.rf_x30_t5;
log.state.rf_x31_t6 = Log.state.rf_x31_t6;
log.state.mulState_valid = Log.state.mulState_valid;
log.state.mulState_finished = Log.state.mulState_finished;
log.state.scoreboard_x00_zero = Log.state.scoreboard_x00_zero;
log.state.scoreboard_x01_ra = Log.state.scoreboard_x01_ra;
log.state.scoreboard_x02_sp = Log.state.scoreboard_x02_sp;
log.state.scoreboard_x03_gp = Log.state.scoreboard_x03_gp;
log.state.scoreboard_x04_tp = Log.state.scoreboard_x04_tp;
log.state.scoreboard_x05_t0 = Log.state.scoreboard_x05_t0;
log.state.scoreboard_x06_t1 = Log.state.scoreboard_x06_t1;
log.state.scoreboard_x07_t2 = Log.state.scoreboard_x07_t2;
log.state.scoreboard_x08_s0_fp = Log.state.scoreboard_x08_s0_fp;
log.state.scoreboard_x09_s1 = Log.state.scoreboard_x09_s1;
log.state.scoreboard_x10_a0 = Log.state.scoreboard_x10_a0;
log.state.scoreboard_x11_a1 = Log.state.scoreboard_x11_a1;
log.state.scoreboard_x12_a2 = Log.state.scoreboard_x12_a2;
log.state.scoreboard_x13_a3 = Log.state.scoreboard_x13_a3;
log.state.scoreboard_x14_a4 = Log.state.scoreboard_x14_a4;
log.state.scoreboard_x15_a5 = Log.state.scoreboard_x15_a5;
log.state.scoreboard_x16_a6 = Log.state.scoreboard_x16_a6;
log.state.scoreboard_x17_a7 = Log.state.scoreboard_x17_a7;
log.state.scoreboard_x18_s2 = Log.state.scoreboard_x18_s2;
log.state.scoreboard_x19_s3 = Log.state.scoreboard_x19_s3;
log.state.scoreboard_x20_s4 = Log.state.scoreboard_x20_s4;
log.state.scoreboard_x21_s5 = Log.state.scoreboard_x21_s5;
log.state.scoreboard_x22_s6 = Log.state.scoreboard_x22_s6;
log.state.scoreboard_x23_s7 = Log.state.scoreboard_x23_s7;
log.state.scoreboard_x24_s8 = Log.state.scoreboard_x24_s8;
log.state.scoreboard_x25_s9 = Log.state.scoreboard_x25_s9;
log.state.scoreboard_x26_s10 = Log.state.scoreboard_x26_s10;
log.state.scoreboard_x27_s11 = Log.state.scoreboard_x27_s11;
log.state.scoreboard_x28_t3 = Log.state.scoreboard_x28_t3;
log.state.scoreboard_x29_t4 = Log.state.scoreboard_x29_t4;
log.state.scoreboard_x30_t5 = Log.state.scoreboard_x30_t5;
log.state.scoreboard_x31_t6 = Log.state.scoreboard_x31_t6;
log.state.instr_count = Log.state.instr_count;
log.rwset.mulState_valid = Log.rwset.mulState_valid;
log.rwset.mulState_result = Log.rwset.mulState_result;
log.rwset.mulState_finished = Log.rwset.mulState_finished;
}

DEF_COMMIT(Writeback) {
Log.state.fromDMem_valid0 = log.state.fromDMem_valid0;
Log.state.e2w_valid0 = log.state.e2w_valid0;
Log.state.rf_x00_zero = log.state.rf_x00_zero;
Log.state.rf_x01_ra = log.state.rf_x01_ra;
Log.state.rf_x02_sp = log.state.rf_x02_sp;
Log.state.rf_x03_gp = log.state.rf_x03_gp;
Log.state.rf_x04_tp = log.state.rf_x04_tp;
Log.state.rf_x05_t0 = log.state.rf_x05_t0;
Log.state.rf_x06_t1 = log.state.rf_x06_t1;
Log.state.rf_x07_t2 = log.state.rf_x07_t2;
Log.state.rf_x08_s0_fp = log.state.rf_x08_s0_fp;
Log.state.rf_x09_s1 = log.state.rf_x09_s1;
Log.state.rf_x10_a0 = log.state.rf_x10_a0;
Log.state.rf_x11_a1 = log.state.rf_x11_a1;
Log.state.rf_x12_a2 = log.state.rf_x12_a2;
Log.state.rf_x13_a3 = log.state.rf_x13_a3;
Log.state.rf_x14_a4 = log.state.rf_x14_a4;
Log.state.rf_x15_a5 = log.state.rf_x15_a5;
Log.state.rf_x16_a6 = log.state.rf_x16_a6;
Log.state.rf_x17_a7 = log.state.rf_x17_a7;
Log.state.rf_x18_s2 = log.state.rf_x18_s2;
Log.state.rf_x19_s3 = log.state.rf_x19_s3;
Log.state.rf_x20_s4 = log.state.rf_x20_s4;
Log.state.rf_x21_s5 = log.state.rf_x21_s5;
Log.state.rf_x22_s6 = log.state.rf_x22_s6;
Log.state.rf_x23_s7 = log.state.rf_x23_s7;
Log.state.rf_x24_s8 = log.state.rf_x24_s8;
Log.state.rf_x25_s9 = log.state.rf_x25_s9;
Log.state.rf_x26_s10 = log.state.rf_x26_s10;
Log.state.rf_x27_s11 = log.state.rf_x27_s11;
Log.state.rf_x28_t3 = log.state.rf_x28_t3;
Log.state.rf_x29_t4 = log.state.rf_x29_t4;
Log.state.rf_x30_t5 = log.state.rf_x30_t5;
Log.state.rf_x31_t6 = log.state.rf_x31_t6;
Log.state.mulState_valid = log.state.mulState_valid;
Log.state.mulState_finished = log.state.mulState_finished;
Log.state.scoreboard_x00_zero = log.state.scoreboard_x00_zero;
Log.state.scoreboard_x01_ra = log.state.scoreboard_x01_ra;
Log.state.scoreboard_x02_sp = log.state.scoreboard_x02_sp;
Log.state.scoreboard_x03_gp = log.state.scoreboard_x03_gp;
Log.state.scoreboard_x04_tp = log.state.scoreboard_x04_tp;
Log.state.scoreboard_x05_t0 = log.state.scoreboard_x05_t0;
Log.state.scoreboard_x06_t1 = log.state.scoreboard_x06_t1;
Log.state.scoreboard_x07_t2 = log.state.scoreboard_x07_t2;
Log.state.scoreboard_x08_s0_fp = log.state.scoreboard_x08_s0_fp;
Log.state.scoreboard_x09_s1 = log.state.scoreboard_x09_s1;
Log.state.scoreboard_x10_a0 = log.state.scoreboard_x10_a0;
Log.state.scoreboard_x11_a1 = log.state.scoreboard_x11_a1;
Log.state.scoreboard_x12_a2 = log.state.scoreboard_x12_a2;
Log.state.scoreboard_x13_a3 = log.state.scoreboard_x13_a3;
Log.state.scoreboard_x14_a4 = log.state.scoreboard_x14_a4;
Log.state.scoreboard_x15_a5 = log.state.scoreboard_x15_a5;
Log.state.scoreboard_x16_a6 = log.state.scoreboard_x16_a6;
Log.state.scoreboard_x17_a7 = log.state.scoreboard_x17_a7;
Log.state.scoreboard_x18_s2 = log.state.scoreboard_x18_s2;
Log.state.scoreboard_x19_s3 = log.state.scoreboard_x19_s3;
Log.state.scoreboard_x20_s4 = log.state.scoreboard_x20_s4;
Log.state.scoreboard_x21_s5 = log.state.scoreboard_x21_s5;
Log.state.scoreboard_x22_s6 = log.state.scoreboard_x22_s6;
Log.state.scoreboard_x23_s7 = log.state.scoreboard_x23_s7;
Log.state.scoreboard_x24_s8 = log.state.scoreboard_x24_s8;
Log.state.scoreboard_x25_s9 = log.state.scoreboard_x25_s9;
Log.state.scoreboard_x26_s10 = log.state.scoreboard_x26_s10;
Log.state.scoreboard_x27_s11 = log.state.scoreboard_x27_s11;
Log.state.scoreboard_x28_t3 = log.state.scoreboard_x28_t3;
Log.state.scoreboard_x29_t4 = log.state.scoreboard_x29_t4;
Log.state.scoreboard_x30_t5 = log.state.scoreboard_x30_t5;
Log.state.scoreboard_x31_t6 = log.state.scoreboard_x31_t6;
Log.state.instr_count = log.state.instr_count;
Log.rwset.mulState_valid = log.rwset.mulState_valid;
Log.rwset.mulState_result = log.rwset.mulState_result;
Log.rwset.mulState_finished = log.rwset.mulState_finished;
}

DECL_FN(deq_2, struct_execute_bookkeeping)
DEF_FN(deq_2, struct_execute_bookkeeping &_ret) {
bits<1> _x0 = CALL_FN(can_deq_3);
if (~(_x0)) {
FAIL_FAST();
}
WRITE0_FAST(e2w_valid0, 1'0_b);
_ret = READ0_FAST(e2w_data0);
return true;
}

DECL_FN(can_deq_3, bits<1>)
DEF_FN(can_deq_3, bits<1> &_ret) {
_ret = READ0_FAST(e2w_valid0);
return true;
}

DECL_FN(getFields_1, struct_instFields)
DEF_FN(getFields_1, struct_instFields &_ret, bits<32> inst) {
struct_instFields res = struct_instFields{};
res.opcode = prims::islice<7>(inst, 5'00000_b);
res.funct3 = prims::islice<3>(inst, 5'01100_b);
res.funct7 = prims::islice<7>(inst, 5'11001_b);
res.funct5 = prims::islice<5>(inst, 5'11011_b);
res.funct2 = prims::islice<2>(inst, 5'11001_b);
res.rd = prims::islice<5>(inst, 5'00111_b);
res.rs1 = prims::islice<5>(inst, 5'01111_b);
res.rs2 = prims::islice<5>(inst, 5'10100_b);
res.rs3 = prims::islice<5>(inst, 5'11011_b);
bits<32> _y18 = CALL_FN(signExtend_3, prims::islice<12>(inst, 5'10100_b));
res.immI = _y18;
bits<32> _y20 = CALL_FN(signExtend_3, prims::concat(prims::islice<7>(inst, 5'11001_b), prims::islice<5>(inst, 5'00111_b)));
res.immS = _y20;
bits<32> _y24 = CALL_FN(signExtend_4, prims::concat(inst[5'11111_b], prims::concat(inst[5'00111_b], prims::concat(prims::islice<6>(inst, 5'11001_b), prims::concat(prims::islice<4>(inst, 5'01000_b), 1'0_b)))));
res.immB = _y24;
res.immU = prims::concat(prims::islice<20>(inst, 5'01100_b), 12'0_b);
bits<32> _y36 = CALL_FN(signExtend_5, prims::concat(inst[5'11111_b], prims::concat(prims::islice<8>(inst, 5'01100_b), prims::concat(inst[5'10100_b], prims::concat(prims::islice<10>(inst, 5'10101_b), 1'0_b)))));
res.immJ = _y36;
res.csr = prims::islice<12>(inst, 5'10100_b);
_ret = res;
return true;
}

DECL_FN(signExtend_3, bits<32>)
DEF_FN(signExtend_3, bits<32> &_ret, bits<12> arg) {
_ret = prims::sext<32>(arg);
return true;
}

DECL_FN(signExtend_4, bits<32>)
DEF_FN(signExtend_4, bits<32> &_ret, bits<13> arg) {
_ret = prims::sext<32>(arg);
return true;
}

DECL_FN(signExtend_5, bits<32>)
DEF_FN(signExtend_5, bits<32> &_ret, bits<21> arg) {
_ret = prims::sext<32>(arg);
return true;
}

DECL_FN(isMemoryInst_1, bits<1>)
DEF_FN(isMemoryInst_1, bits<1> &_ret, struct_decodedInst dInst) {
_ret = ((dInst.inst[5'00110_b] == 1'0_b) & (prims::islice<2>(dInst.inst, 5'00011_b) == 2'00_b));
return true;
}

DECL_FN(deq_3, struct_mem_resp)
DEF_FN(deq_3, struct_mem_resp &_ret) {
bits<1> _x41 = CALL_FN(can_deq_4);
if (~(_x41)) {
FAIL();
}
WRITE0_FAST(fromDMem_valid0, 1'0_b);
_ret = READ0_FAST(fromDMem_data0);
return true;
}

DECL_FN(can_deq_4, bits<1>)
DEF_FN(can_deq_4, bits<1> &_ret) {
_ret = READ0_FAST(fromDMem_valid0);
return true;
}

DECL_FN(signExtend_6, bits<32>)
DEF_FN(signExtend_6, bits<32> &_ret, bits<8> arg) {
_ret = prims::sext<32>(arg);
return true;
}

DECL_FN(signExtend_7, bits<32>)
DEF_FN(signExtend_7, bits<32> &_ret, bits<16> arg) {
_ret = prims::sext<32>(arg);
return true;
}

DECL_FN(isMultiplyInst_1, bits<1>)
DEF_FN(isMultiplyInst_1, bits<1> &_ret, struct_decodedInst dInst) {
_ret = CALL_FN(enabled_1);
bits<1> _y52;
/* bind */ {
struct_instFields fields = CALL_FN(getFields_1, dInst.inst);
_y52 = ((fields.funct7 == 7'0000001_b) & ((fields.funct3 == 3'000_b) & (fields.opcode == 7'0110011_b)));
}
_ret = (_ret & _y52);
return true;
}

DECL_FN(enabled_1, bits<1>)
DEF_FN(enabled_1, bits<1> &_ret) {
_ret = 1'1_b;
return true;
}

DECL_FN(deq_4, bits<64>)
DEF_FN(deq_4, bits<64> &_ret) {
bits<1> _x51 = READ1(mulState_valid);
bits<1> _y58 = READ1(mulState_finished);
if (~((_x51 & _y58))) {
FAIL();
}
WRITE1(mulState_finished, 1'0_b);
WRITE1(mulState_valid, 1'0_b);
_ret = READ1(mulState_result);
return true;
}

DECL_FN(remove_0, unit)
DEF_FN(remove_0, unit &_ret, bits<5> idx) {
bits<2> old_score = CALL_FN(read_0_0, idx);
bits<2> new_score = CALL_FN(sat_decr_0, old_score);
_ret = CALL_FN(write_0_0, idx, new_score);
return true;
}

DECL_FN(sliceReg_0, bits<5>)
DEF_FN(sliceReg_0, bits<5> &_ret, bits<5> idx) {
_ret = prims::islice<5>(idx, 3'000_b);
return true;
}

DECL_FN(read_0_0, bits<2>)
DEF_FN(read_0_0, bits<2> &_ret, bits<5> idx) {
if ((5'11111_b == idx)) {
_ret = READ0_FAST(scoreboard_x31_t6);
}
else {
_ret = 2'00_b;
}
bits<2> _y61;
if ((5'01111_b == idx)) {
_y61 = READ0_FAST(scoreboard_x15_a5);
}
else {
_y61 = 2'00_b;
}
bits<2> _y63;
if ((5'10111_b == idx)) {
_y63 = READ0_FAST(scoreboard_x23_s7);
}
else {
_y63 = 2'00_b;
}
bits<2> _y65;
if ((5'00111_b == idx)) {
_y65 = READ0_FAST(scoreboard_x07_t2);
}
else {
_y65 = 2'00_b;
}
bits<2> _y67;
if ((5'11011_b == idx)) {
_y67 = READ0_FAST(scoreboard_x27_s11);
}
else {
_y67 = 2'00_b;
}
bits<2> _y69;
if ((5'01011_b == idx)) {
_y69 = READ0_FAST(scoreboard_x11_a1);
}
else {
_y69 = 2'00_b;
}
bits<2> _y71;
if ((5'10011_b == idx)) {
_y71 = READ0_FAST(scoreboard_x19_s3);
}
else {
_y71 = 2'00_b;
}
bits<2> _y73;
if ((5'00011_b == idx)) {
_y73 = READ0_FAST(scoreboard_x03_gp);
}
else {
_y73 = 2'00_b;
}
bits<2> _y75;
if ((5'11101_b == idx)) {
_y75 = READ0_FAST(scoreboard_x29_t4);
}
else {
_y75 = 2'00_b;
}
bits<2> _y77;
if ((5'01101_b == idx)) {
_y77 = READ0_FAST(scoreboard_x13_a3);
}
else {
_y77 = 2'00_b;
}
bits<2> _y79;
if ((5'10101_b == idx)) {
_y79 = READ0_FAST(scoreboard_x21_s5);
}
else {
_y79 = 2'00_b;
}
bits<2> _y81;
if ((5'00101_b == idx)) {
_y81 = READ0_FAST(scoreboard_x05_t0);
}
else {
_y81 = 2'00_b;
}
bits<2> _y83;
if ((5'11001_b == idx)) {
_y83 = READ0_FAST(scoreboard_x25_s9);
}
else {
_y83 = 2'00_b;
}
bits<2> _y85;
if ((5'01001_b == idx)) {
_y85 = READ0_FAST(scoreboard_x09_s1);
}
else {
_y85 = 2'00_b;
}
bits<2> _y87;
if ((5'10001_b == idx)) {
_y87 = READ0_FAST(scoreboard_x17_a7);
}
else {
_y87 = 2'00_b;
}
bits<2> _y89;
if ((5'00001_b == idx)) {
_y89 = READ0_FAST(scoreboard_x01_ra);
}
else {
_y89 = 2'00_b;
}
bits<2> _y91;
if ((5'11110_b == idx)) {
_y91 = READ0_FAST(scoreboard_x30_t5);
}
else {
_y91 = 2'00_b;
}
bits<2> _y93;
if ((5'01110_b == idx)) {
_y93 = READ0_FAST(scoreboard_x14_a4);
}
else {
_y93 = 2'00_b;
}
bits<2> _y95;
if ((5'10110_b == idx)) {
_y95 = READ0_FAST(scoreboard_x22_s6);
}
else {
_y95 = 2'00_b;
}
bits<2> _y97;
if ((5'00110_b == idx)) {
_y97 = READ0_FAST(scoreboard_x06_t1);
}
else {
_y97 = 2'00_b;
}
bits<2> _y99;
if ((5'11010_b == idx)) {
_y99 = READ0_FAST(scoreboard_x26_s10);
}
else {
_y99 = 2'00_b;
}
bits<2> _y101;
if ((5'01010_b == idx)) {
_y101 = READ0_FAST(scoreboard_x10_a0);
}
else {
_y101 = 2'00_b;
}
bits<2> _y103;
if ((5'10010_b == idx)) {
_y103 = READ0_FAST(scoreboard_x18_s2);
}
else {
_y103 = 2'00_b;
}
bits<2> _y105;
if ((5'00010_b == idx)) {
_y105 = READ0_FAST(scoreboard_x02_sp);
}
else {
_y105 = 2'00_b;
}
bits<2> _y107;
if ((5'11100_b == idx)) {
_y107 = READ0_FAST(scoreboard_x28_t3);
}
else {
_y107 = 2'00_b;
}
bits<2> _y109;
if ((5'01100_b == idx)) {
_y109 = READ0_FAST(scoreboard_x12_a2);
}
else {
_y109 = 2'00_b;
}
bits<2> _y111;
if ((5'10100_b == idx)) {
_y111 = READ0_FAST(scoreboard_x20_s4);
}
else {
_y111 = 2'00_b;
}
bits<2> _y113;
if ((5'00100_b == idx)) {
_y113 = READ0_FAST(scoreboard_x04_tp);
}
else {
_y113 = 2'00_b;
}
bits<2> _y115;
if ((5'11000_b == idx)) {
_y115 = READ0_FAST(scoreboard_x24_s8);
}
else {
_y115 = 2'00_b;
}
bits<2> _y117;
if ((5'01000_b == idx)) {
_y117 = READ0_FAST(scoreboard_x08_s0_fp);
}
else {
_y117 = 2'00_b;
}
bits<2> _y119;
if ((5'10000_b == idx)) {
_y119 = READ0_FAST(scoreboard_x16_a6);
}
else {
_y119 = 2'00_b;
}
bits<2> _y121;
if ((5'00000_b == idx)) {
_y121 = READ0_FAST(scoreboard_x00_zero);
}
else {
_y121 = 2'00_b;
}
_ret = (((((_ret | _y61) | (_y63 | _y65)) | ((_y67 | _y69) | (_y71 | _y73))) | (((_y75 | _y77) | (_y79 | _y81)) | ((_y83 | _y85) | (_y87 | _y89)))) | ((((_y91 | _y93) | (_y95 | _y97)) | ((_y99 | _y101) | (_y103 | _y105))) | (((_y107 | _y109) | (_y111 | _y113)) | ((_y115 | _y117) | (_y119 | _y121)))));
return true;
}

DECL_FN(sat_decr_0, bits<2>)
DEF_FN(sat_decr_0, bits<2> &_ret, bits<2> a) {
_ret = (a - 2'01_b);
return true;
}

DECL_FN(write_0_0, unit)
DEF_FN(write_0_0, unit &_ret, bits<5> idx, bits<2> val) {
if ((idx == 5'00000_b)) {
WRITE0_FAST(scoreboard_x00_zero, val);
}
if ((idx == 5'00001_b)) {
WRITE0_FAST(scoreboard_x01_ra, val);
}
if ((idx == 5'00010_b)) {
WRITE0_FAST(scoreboard_x02_sp, val);
}
if ((idx == 5'00011_b)) {
WRITE0_FAST(scoreboard_x03_gp, val);
}
if ((idx == 5'00100_b)) {
WRITE0_FAST(scoreboard_x04_tp, val);
}
if ((idx == 5'00101_b)) {
WRITE0_FAST(scoreboard_x05_t0, val);
}
if ((idx == 5'00110_b)) {
WRITE0_FAST(scoreboard_x06_t1, val);
}
if ((idx == 5'00111_b)) {
WRITE0_FAST(scoreboard_x07_t2, val);
}
if ((idx == 5'01000_b)) {
WRITE0_FAST(scoreboard_x08_s0_fp, val);
}
if ((idx == 5'01001_b)) {
WRITE0_FAST(scoreboard_x09_s1, val);
}
if ((idx == 5'01010_b)) {
WRITE0_FAST(scoreboard_x10_a0, val);
}
if ((idx == 5'01011_b)) {
WRITE0_FAST(scoreboard_x11_a1, val);
}
if ((idx == 5'01100_b)) {
WRITE0_FAST(scoreboard_x12_a2, val);
}
if ((idx == 5'01101_b)) {
WRITE0_FAST(scoreboard_x13_a3, val);
}
if ((idx == 5'01110_b)) {
WRITE0_FAST(scoreboard_x14_a4, val);
}
if ((idx == 5'01111_b)) {
WRITE0_FAST(scoreboard_x15_a5, val);
}
if ((idx == 5'10000_b)) {
WRITE0_FAST(scoreboard_x16_a6, val);
}
if ((idx == 5'10001_b)) {
WRITE0_FAST(scoreboard_x17_a7, val);
}
if ((idx == 5'10010_b)) {
WRITE0_FAST(scoreboard_x18_s2, val);
}
if ((idx == 5'10011_b)) {
WRITE0_FAST(scoreboard_x19_s3, val);
}
if ((idx == 5'10100_b)) {
WRITE0_FAST(scoreboard_x20_s4, val);
}
if ((idx == 5'10101_b)) {
WRITE0_FAST(scoreboard_x21_s5, val);
}
if ((idx == 5'10110_b)) {
WRITE0_FAST(scoreboard_x22_s6, val);
}
if ((idx == 5'10111_b)) {
WRITE0_FAST(scoreboard_x23_s7, val);
}
if ((idx == 5'11000_b)) {
WRITE0_FAST(scoreboard_x24_s8, val);
}
if ((idx == 5'11001_b)) {
WRITE0_FAST(scoreboard_x25_s9, val);
}
if ((idx == 5'11010_b)) {
WRITE0_FAST(scoreboard_x26_s10, val);
}
if ((idx == 5'11011_b)) {
WRITE0_FAST(scoreboard_x27_s11, val);
}
if ((idx == 5'11100_b)) {
WRITE0_FAST(scoreboard_x28_t3, val);
}
if ((idx == 5'11101_b)) {
WRITE0_FAST(scoreboard_x29_t4, val);
}
if ((idx == 5'11110_b)) {
WRITE0_FAST(scoreboard_x30_t5, val);
}
if ((idx == 5'11111_b)) {
WRITE0_FAST(scoreboard_x31_t6, val);
}
_ret = prims::tt;
return true;
}

DECL_FN(write_0_1, unit)
DEF_FN(write_0_1, unit &_ret, bits<5> idx, bits<32> val) {
if ((idx == 5'00000_b)) {
WRITE0_FAST(rf_x00_zero, val);
}
if ((idx == 5'00001_b)) {
WRITE0_FAST(rf_x01_ra, val);
}
if ((idx == 5'00010_b)) {
WRITE0_FAST(rf_x02_sp, val);
}
if ((idx == 5'00011_b)) {
WRITE0_FAST(rf_x03_gp, val);
}
if ((idx == 5'00100_b)) {
WRITE0_FAST(rf_x04_tp, val);
}
if ((idx == 5'00101_b)) {
WRITE0_FAST(rf_x05_t0, val);
}
if ((idx == 5'00110_b)) {
WRITE0_FAST(rf_x06_t1, val);
}
if ((idx == 5'00111_b)) {
WRITE0_FAST(rf_x07_t2, val);
}
if ((idx == 5'01000_b)) {
WRITE0_FAST(rf_x08_s0_fp, val);
}
if ((idx == 5'01001_b)) {
WRITE0_FAST(rf_x09_s1, val);
}
if ((idx == 5'01010_b)) {
WRITE0_FAST(rf_x10_a0, val);
}
if ((idx == 5'01011_b)) {
WRITE0_FAST(rf_x11_a1, val);
}
if ((idx == 5'01100_b)) {
WRITE0_FAST(rf_x12_a2, val);
}
if ((idx == 5'01101_b)) {
WRITE0_FAST(rf_x13_a3, val);
}
if ((idx == 5'01110_b)) {
WRITE0_FAST(rf_x14_a4, val);
}
if ((idx == 5'01111_b)) {
WRITE0_FAST(rf_x15_a5, val);
}
if ((idx == 5'10000_b)) {
WRITE0_FAST(rf_x16_a6, val);
}
if ((idx == 5'10001_b)) {
WRITE0_FAST(rf_x17_a7, val);
}
if ((idx == 5'10010_b)) {
WRITE0_FAST(rf_x18_s2, val);
}
if ((idx == 5'10011_b)) {
WRITE0_FAST(rf_x19_s3, val);
}
if ((idx == 5'10100_b)) {
WRITE0_FAST(rf_x20_s4, val);
}
if ((idx == 5'10101_b)) {
WRITE0_FAST(rf_x21_s5, val);
}
if ((idx == 5'10110_b)) {
WRITE0_FAST(rf_x22_s6, val);
}
if ((idx == 5'10111_b)) {
WRITE0_FAST(rf_x23_s7, val);
}
if ((idx == 5'11000_b)) {
WRITE0_FAST(rf_x24_s8, val);
}
if ((idx == 5'11001_b)) {
WRITE0_FAST(rf_x25_s9, val);
}
if ((idx == 5'11010_b)) {
WRITE0_FAST(rf_x26_s10, val);
}
if ((idx == 5'11011_b)) {
WRITE0_FAST(rf_x27_s11, val);
}
if ((idx == 5'11100_b)) {
WRITE0_FAST(rf_x28_t3, val);
}
if ((idx == 5'11101_b)) {
WRITE0_FAST(rf_x29_t4, val);
}
if ((idx == 5'11110_b)) {
WRITE0_FAST(rf_x30_t5, val);
}
if ((idx == 5'11111_b)) {
WRITE0_FAST(rf_x31_t6, val);
}
_ret = prims::tt;
return true;
}
DEF_RULE(Writeback) {
struct_execute_bookkeeping execute_bookkeeping = CALL_FN(deq_2);
struct_decodedInst dInst = execute_bookkeeping.dInst;
bits<32> data = execute_bookkeeping.newrd;
struct_instFields fields = CALL_FN(getFields_1, dInst.inst);
bits<32> _v68 = READ0_FAST(instr_count);
WRITE0_FAST(instr_count, (_v68 + 32'1_b));
bits<1> _test99 = CALL_FN(isMemoryInst_1, dInst);
if (_test99) {
struct_mem_resp resp = CALL_FN(deq_3);
bits<32> mem_data = resp.data;
mem_data = (mem_data >> prims::concat(execute_bookkeeping.offset, 3'000_b));
/* bind */ {
bits<3> renamed_cpp_dx2_reserved_dx2_matchPattern = prims::concat(execute_bookkeeping.isUnsigned, execute_bookkeeping.size);
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 3'000_bv: {
data = CALL_FN(signExtend_6, prims::islice<8>(mem_data, 5'00000_b));
}
break;
case 3'001_bv: {
data = CALL_FN(signExtend_7, prims::islice<16>(mem_data, 5'00000_b));
}
break;
case 3'100_bv: {
data = prims::zextl<32>(prims::islice<8>(mem_data, 5'00000_b));
}
break;
case 3'101_bv: {
data = prims::zextl<32>(prims::islice<16>(mem_data, 5'00000_b));
}
break;
case 3'010_bv: {
data = mem_data;
}
break;
default: {
FAIL();
}
break;
}
}
}
else {
bits<1> _test100 = CALL_FN(isMultiplyInst_1, dInst);
if (_test100) {
bits<64> _x163 = CALL_FN(deq_4);
data = prims::islice<32>(_x163, 6'000000_b);
}
}
if (dInst.valid_rd) {
bits<5> rd_idx = fields.rd;
bits<5> _idx2 = CALL_FN(sliceReg_0, rd_idx);
CALL_FN(remove_0, _idx2);
if ((rd_idx == 5'00000_b)) {
}
else {
bits<5> _idx4 = CALL_FN(sliceReg_0, rd_idx);
CALL_FN(write_0_1, _idx4, data);
}
}

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME Imem
DEF_RESET(Imem) {
log.state.toIMem_valid0 = Log.state.toIMem_valid0;
log.state.fromIMem_data0 = Log.state.fromIMem_data0;
log.state.fromIMem_valid0 = Log.state.fromIMem_valid0;
}

DEF_COMMIT(Imem) {
Log.state.toIMem_valid0 = log.state.toIMem_valid0;
Log.state.fromIMem_data0 = log.state.fromIMem_data0;
Log.state.fromIMem_valid0 = log.state.fromIMem_valid0;
}

DECL_FN(can_enq_4, bits<1>)
DEF_FN(can_enq_4, bits<1> &_ret) {
bits<1> _x0 = READ1_FAST(fromIMem_valid0);
_ret = ~(_x0);
return true;
}

DECL_FN(peek_1, struct_maybe_mem_req)
DEF_FN(peek_1, struct_maybe_mem_req &_ret) {
bits<1> _test0 = CALL_FN(can_deq_5);
if (_test0) {
struct_mem_req _x1 = READ1_FAST(toIMem_data0);
_ret = CALL_FN(valid_1, _x1);
}
else {
_ret = CALL_FN(invalid_1);
}
return true;
}

DECL_FN(can_deq_5, bits<1>)
DEF_FN(can_deq_5, bits<1> &_ret) {
_ret = READ1_FAST(toIMem_valid0);
return true;
}

DECL_FN(valid_1, struct_maybe_mem_req)
DEF_FN(valid_1, struct_maybe_mem_req &_ret, struct_mem_req x) {
_ret = struct_maybe_mem_req{};
_ret.valid = 1'1_b;
_ret.data = x;
return true;
}

DECL_FN(invalid_1, struct_maybe_mem_req)
DEF_FN(invalid_1, struct_maybe_mem_req &_ret) {
_ret = struct_maybe_mem_req{};
_ret.valid = 1'0_b;
return true;
}

DECL_FN(memoryBus_1, struct_mem_output)
DEF_FN(memoryBus_1, struct_mem_output &_ret, bits<1> get_ready, bits<1> put_valid, struct_mem_req put_request) {
struct_mem_input _x2 = struct_mem_input{};
_x2.get_ready = get_ready;
_x2.put_valid = put_valid;
_x2.put_request = put_request;
_ret = extfuns.ext_mem_imem(_x2);
return true;
}

DECL_FN(enq_4, unit)
DEF_FN(enq_4, unit &_ret, struct_mem_resp data) {
bits<1> _x3 = CALL_FN(can_enq_5);
if (~(_x3)) {
FAIL_FAST();
}
WRITE1_FAST(fromIMem_data0, data);
WRITE1_FAST(fromIMem_valid0, 1'1_b);
_ret = prims::tt;
return true;
}

DECL_FN(can_enq_5, bits<1>)
DEF_FN(can_enq_5, bits<1> &_ret) {
bits<1> _x4 = READ1_FAST(fromIMem_valid0);
_ret = ~(_x4);
return true;
}

DECL_FN(deq_5, struct_mem_req)
DEF_FN(deq_5, struct_mem_req &_ret) {
bits<1> _x5 = CALL_FN(can_deq_6);
if (~(_x5)) {
FAIL();
}
WRITE1_FAST(toIMem_valid0, 1'0_b);
_ret = READ1_FAST(toIMem_data0);
return true;
}

DECL_FN(can_deq_6, bits<1>)
DEF_FN(can_deq_6, bits<1> &_ret) {
_ret = READ1_FAST(toIMem_valid0);
return true;
}
DEF_RULE(Imem) {
bits<1> get_ready = CALL_FN(can_enq_4);
struct_maybe_mem_req put_request_opt = CALL_FN(peek_1);
struct_mem_req put_request = put_request_opt.data;
bits<1> put_valid = put_request_opt.valid;
struct_mem_output mem_out = CALL_FN(memoryBus_1, get_ready, put_valid, put_request);
if ((get_ready & mem_out.get_valid)) {
CALL_FN(enq_4, mem_out.get_response);
}
if ((put_valid & mem_out.put_ready)) {
CALL_FN(deq_5);
}

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME WaitImem
DEF_RESET(WaitImem) {
log.state.f2d_valid0 = Log.state.f2d_valid0;
log.state.f2dprim_data0 = Log.state.f2dprim_data0;
log.state.f2dprim_valid0 = Log.state.f2dprim_valid0;
}

DEF_COMMIT(WaitImem) {
Log.state.f2d_valid0 = log.state.f2d_valid0;
Log.state.f2dprim_data0 = log.state.f2dprim_data0;
Log.state.f2dprim_valid0 = log.state.f2dprim_valid0;
}

DECL_FN(deq_6, struct_fetch_bookkeeping)
DEF_FN(deq_6, struct_fetch_bookkeeping &_ret) {
bits<1> _x0 = CALL_FN(can_deq_7);
if (~(_x0)) {
FAIL_FAST();
}
WRITE0_FAST(f2d_valid0, 1'0_b);
_ret = READ0_FAST(f2d_data0);
return true;
}

DECL_FN(can_deq_7, bits<1>)
DEF_FN(can_deq_7, bits<1> &_ret) {
_ret = READ0_FAST(f2d_valid0);
return true;
}

DECL_FN(enq_5, unit)
DEF_FN(enq_5, unit &_ret, struct_fetch_bookkeeping data) {
bits<1> _x1 = CALL_FN(can_enq_6);
if (~(_x1)) {
FAIL();
}
WRITE1_FAST(f2dprim_data0, data);
WRITE1_FAST(f2dprim_valid0, 1'1_b);
_ret = prims::tt;
return true;
}

DECL_FN(can_enq_6, bits<1>)
DEF_FN(can_enq_6, bits<1> &_ret) {
bits<1> _x2 = READ1_FAST(f2dprim_valid0);
_ret = ~(_x2);
return true;
}
DEF_RULE(WaitImem) {
struct_fetch_bookkeeping fetched_bookkeeping = CALL_FN(deq_6);
CALL_FN(enq_5, fetched_bookkeeping);

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME Fetch
DEF_RESET(Fetch) {
log.state.toIMem_data0 = Log.state.toIMem_data0;
log.state.toIMem_valid0 = Log.state.toIMem_valid0;
log.state.f2d_data0 = Log.state.f2d_data0;
log.state.f2d_valid0 = Log.state.f2d_valid0;
log.state.pc = Log.state.pc;
}

DEF_COMMIT(Fetch) {
Log.state.toIMem_data0 = log.state.toIMem_data0;
Log.state.toIMem_valid0 = log.state.toIMem_valid0;
Log.state.f2d_data0 = log.state.f2d_data0;
Log.state.f2d_valid0 = log.state.f2d_valid0;
Log.state.pc = log.state.pc;
}

DECL_FN(enq_6, unit)
DEF_FN(enq_6, unit &_ret, struct_mem_req data) {
bits<1> _x0 = CALL_FN(can_enq_7);
if (~(_x0)) {
FAIL_FAST();
}
WRITE0_FAST(toIMem_data0, data);
WRITE0_FAST(toIMem_valid0, 1'1_b);
_ret = prims::tt;
return true;
}

DECL_FN(can_enq_7, bits<1>)
DEF_FN(can_enq_7, bits<1> &_ret) {
bits<1> _x1 = READ0_FAST(toIMem_valid0);
_ret = ~(_x1);
return true;
}

DECL_FN(enq_7, unit)
DEF_FN(enq_7, unit &_ret, struct_fetch_bookkeeping data) {
bits<1> _x2 = CALL_FN(can_enq_8);
if (~(_x2)) {
FAIL();
}
WRITE1_FAST(f2d_data0, data);
WRITE1_FAST(f2d_valid0, 1'1_b);
_ret = prims::tt;
return true;
}

DECL_FN(can_enq_8, bits<1>)
DEF_FN(can_enq_8, bits<1> &_ret) {
bits<1> _x3 = READ1_FAST(f2d_valid0);
_ret = ~(_x3);
return true;
}
DEF_RULE(Fetch) {
bits<32> pc = READ1_FAST(pc);
struct_mem_req req = struct_mem_req{};
req.byte_en = 4'0000_b;
req.addr = pc;
req.data = 32'0_b;
struct_fetch_bookkeeping fetch_bookkeeping = struct_fetch_bookkeeping{};
fetch_bookkeeping.pc = pc;
fetch_bookkeeping.ppc = (pc + 0x32'0004_x);
bits<1> _y6 = READ1_FAST(epoch);
fetch_bookkeeping.epoch = _y6;
CALL_FN(enq_6, req);
WRITE1_FAST(pc, (pc + 0x32'0004_x));
CALL_FN(enq_7, fetch_bookkeeping);

COMMIT();
}
#undef RULE_NAME

#define RULE_NAME Decode
DEF_RESET(Decode) {
log.state.fromIMem_valid0 = Log.state.fromIMem_valid0;
log.state.f2dprim_valid0 = Log.state.f2dprim_valid0;
log.state.d2e_data0 = Log.state.d2e_data0;
log.state.d2e_valid0 = Log.state.d2e_valid0;
log.state.scoreboard_x00_zero = Log.state.scoreboard_x00_zero;
log.state.scoreboard_x01_ra = Log.state.scoreboard_x01_ra;
log.state.scoreboard_x02_sp = Log.state.scoreboard_x02_sp;
log.state.scoreboard_x03_gp = Log.state.scoreboard_x03_gp;
log.state.scoreboard_x04_tp = Log.state.scoreboard_x04_tp;
log.state.scoreboard_x05_t0 = Log.state.scoreboard_x05_t0;
log.state.scoreboard_x06_t1 = Log.state.scoreboard_x06_t1;
log.state.scoreboard_x07_t2 = Log.state.scoreboard_x07_t2;
log.state.scoreboard_x08_s0_fp = Log.state.scoreboard_x08_s0_fp;
log.state.scoreboard_x09_s1 = Log.state.scoreboard_x09_s1;
log.state.scoreboard_x10_a0 = Log.state.scoreboard_x10_a0;
log.state.scoreboard_x11_a1 = Log.state.scoreboard_x11_a1;
log.state.scoreboard_x12_a2 = Log.state.scoreboard_x12_a2;
log.state.scoreboard_x13_a3 = Log.state.scoreboard_x13_a3;
log.state.scoreboard_x14_a4 = Log.state.scoreboard_x14_a4;
log.state.scoreboard_x15_a5 = Log.state.scoreboard_x15_a5;
log.state.scoreboard_x16_a6 = Log.state.scoreboard_x16_a6;
log.state.scoreboard_x17_a7 = Log.state.scoreboard_x17_a7;
log.state.scoreboard_x18_s2 = Log.state.scoreboard_x18_s2;
log.state.scoreboard_x19_s3 = Log.state.scoreboard_x19_s3;
log.state.scoreboard_x20_s4 = Log.state.scoreboard_x20_s4;
log.state.scoreboard_x21_s5 = Log.state.scoreboard_x21_s5;
log.state.scoreboard_x22_s6 = Log.state.scoreboard_x22_s6;
log.state.scoreboard_x23_s7 = Log.state.scoreboard_x23_s7;
log.state.scoreboard_x24_s8 = Log.state.scoreboard_x24_s8;
log.state.scoreboard_x25_s9 = Log.state.scoreboard_x25_s9;
log.state.scoreboard_x26_s10 = Log.state.scoreboard_x26_s10;
log.state.scoreboard_x27_s11 = Log.state.scoreboard_x27_s11;
log.state.scoreboard_x28_t3 = Log.state.scoreboard_x28_t3;
log.state.scoreboard_x29_t4 = Log.state.scoreboard_x29_t4;
log.state.scoreboard_x30_t5 = Log.state.scoreboard_x30_t5;
log.state.scoreboard_x31_t6 = Log.state.scoreboard_x31_t6;
}

DEF_COMMIT(Decode) {
Log.state.fromIMem_valid0 = log.state.fromIMem_valid0;
Log.state.f2dprim_valid0 = log.state.f2dprim_valid0;
Log.state.d2e_data0 = log.state.d2e_data0;
Log.state.d2e_valid0 = log.state.d2e_valid0;
Log.state.scoreboard_x00_zero = log.state.scoreboard_x00_zero;
Log.state.scoreboard_x01_ra = log.state.scoreboard_x01_ra;
Log.state.scoreboard_x02_sp = log.state.scoreboard_x02_sp;
Log.state.scoreboard_x03_gp = log.state.scoreboard_x03_gp;
Log.state.scoreboard_x04_tp = log.state.scoreboard_x04_tp;
Log.state.scoreboard_x05_t0 = log.state.scoreboard_x05_t0;
Log.state.scoreboard_x06_t1 = log.state.scoreboard_x06_t1;
Log.state.scoreboard_x07_t2 = log.state.scoreboard_x07_t2;
Log.state.scoreboard_x08_s0_fp = log.state.scoreboard_x08_s0_fp;
Log.state.scoreboard_x09_s1 = log.state.scoreboard_x09_s1;
Log.state.scoreboard_x10_a0 = log.state.scoreboard_x10_a0;
Log.state.scoreboard_x11_a1 = log.state.scoreboard_x11_a1;
Log.state.scoreboard_x12_a2 = log.state.scoreboard_x12_a2;
Log.state.scoreboard_x13_a3 = log.state.scoreboard_x13_a3;
Log.state.scoreboard_x14_a4 = log.state.scoreboard_x14_a4;
Log.state.scoreboard_x15_a5 = log.state.scoreboard_x15_a5;
Log.state.scoreboard_x16_a6 = log.state.scoreboard_x16_a6;
Log.state.scoreboard_x17_a7 = log.state.scoreboard_x17_a7;
Log.state.scoreboard_x18_s2 = log.state.scoreboard_x18_s2;
Log.state.scoreboard_x19_s3 = log.state.scoreboard_x19_s3;
Log.state.scoreboard_x20_s4 = log.state.scoreboard_x20_s4;
Log.state.scoreboard_x21_s5 = log.state.scoreboard_x21_s5;
Log.state.scoreboard_x22_s6 = log.state.scoreboard_x22_s6;
Log.state.scoreboard_x23_s7 = log.state.scoreboard_x23_s7;
Log.state.scoreboard_x24_s8 = log.state.scoreboard_x24_s8;
Log.state.scoreboard_x25_s9 = log.state.scoreboard_x25_s9;
Log.state.scoreboard_x26_s10 = log.state.scoreboard_x26_s10;
Log.state.scoreboard_x27_s11 = log.state.scoreboard_x27_s11;
Log.state.scoreboard_x28_t3 = log.state.scoreboard_x28_t3;
Log.state.scoreboard_x29_t4 = log.state.scoreboard_x29_t4;
Log.state.scoreboard_x30_t5 = log.state.scoreboard_x30_t5;
Log.state.scoreboard_x31_t6 = log.state.scoreboard_x31_t6;
}

DECL_FN(deq_7, struct_mem_resp)
DEF_FN(deq_7, struct_mem_resp &_ret) {
bits<1> _x0 = CALL_FN(can_deq_8);
if (~(_x0)) {
FAIL_FAST();
}
WRITE0_FAST(fromIMem_valid0, 1'0_b);
_ret = READ0_FAST(fromIMem_data0);
return true;
}

DECL_FN(can_deq_8, bits<1>)
DEF_FN(can_deq_8, bits<1> &_ret) {
_ret = READ0_FAST(fromIMem_valid0);
return true;
}

DECL_FN(deq_8, struct_fetch_bookkeeping)
DEF_FN(deq_8, struct_fetch_bookkeeping &_ret) {
bits<1> _x1 = CALL_FN(can_deq_9);
if (~(_x1)) {
FAIL();
}
WRITE0_FAST(f2dprim_valid0, 1'0_b);
_ret = READ0_FAST(f2dprim_data0);
return true;
}

DECL_FN(can_deq_9, bits<1>)
DEF_FN(can_deq_9, bits<1> &_ret) {
_ret = READ0_FAST(f2dprim_valid0);
return true;
}

DECL_FN(decode_fun_0, struct_decodedInst)
DEF_FN(decode_fun_0, struct_decodedInst &_ret, bits<32> arg_inst) {
bits<1> _y0 = CALL_FN(usesRS1_0, arg_inst);
_ret = struct_decodedInst{};
_ret.valid_rs1 = _y0;
bits<1> _y1 = CALL_FN(usesRS2_0, arg_inst);
_ret.valid_rs2 = _y1;
bits<1> _y2 = CALL_FN(usesRD_0, arg_inst);
_ret.valid_rd = _y2;
bits<1> _y3 = CALL_FN(isLegalInstruction_0, arg_inst);
_ret.legal = _y3;
_ret.inst = arg_inst;
struct_maybe_immType _y5 = CALL_FN(getImmediateType_0, arg_inst);
_ret.immediateType = _y5;
return true;
}

DECL_FN(usesRS1_0, bits<1>)
DEF_FN(usesRS1_0, bits<1> &_ret, bits<32> inst) {
bits<5> renamed_cpp_dx2_reserved_dx2_matchPattern = prims::islice<5>(inst, 5'00010_b);
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 5'11000_bv: {
_ret = 1'1_b;
}
break;
case 5'00000_bv: {
_ret = 1'1_b;
}
break;
case 5'01000_bv: {
_ret = 1'1_b;
}
break;
case 5'01100_bv: {
_ret = 1'1_b;
}
break;
case 5'11001_bv: {
_ret = 1'1_b;
}
break;
case 5'00100_bv: {
_ret = 1'1_b;
}
break;
default: {
_ret = 1'0_b;
}
break;
}
return true;
}

DECL_FN(usesRS2_0, bits<1>)
DEF_FN(usesRS2_0, bits<1> &_ret, bits<32> inst) {
bits<5> renamed_cpp_dx2_reserved_dx2_matchPattern = prims::islice<5>(inst, 5'00010_b);
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 5'11000_bv: {
_ret = 1'1_b;
}
break;
case 5'01000_bv: {
_ret = 1'1_b;
}
break;
case 5'01100_bv: {
_ret = 1'1_b;
}
break;
default: {
_ret = 1'0_b;
}
break;
}
return true;
}

DECL_FN(usesRD_0, bits<1>)
DEF_FN(usesRD_0, bits<1> &_ret, bits<32> inst) {
bits<5> renamed_cpp_dx2_reserved_dx2_matchPattern = prims::islice<5>(inst, 5'00010_b);
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 5'01101_bv: {
_ret = 1'1_b;
}
break;
case 5'11011_bv: {
_ret = 1'1_b;
}
break;
case 5'00000_bv: {
_ret = 1'1_b;
}
break;
case 5'01100_bv: {
_ret = 1'1_b;
}
break;
case 5'11001_bv: {
_ret = 1'1_b;
}
break;
case 5'00100_bv: {
_ret = 1'1_b;
}
break;
case 5'00101_bv: {
_ret = 1'1_b;
}
break;
default: {
_ret = 1'0_b;
}
break;
}
return true;
}

DECL_FN(isLegalInstruction_0, bits<1>)
DEF_FN(isLegalInstruction_0, bits<1> &_ret, bits<32> inst) {
struct_instFields fields = CALL_FN(getFields_2, inst);
bits<7> renamed_cpp_dx2_reserved_dx2_matchPattern = fields.opcode;
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 7'0000011_bv: {
bits<3> renamed_cpp_dx2_reserved_dx2_matchPattern = fields.funct3;
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 3'000_bv: {
_ret = 1'1_b;
}
break;
case 3'001_bv: {
_ret = 1'1_b;
}
break;
case 3'010_bv: {
_ret = 1'1_b;
}
break;
case 3'100_bv: {
_ret = 1'1_b;
}
break;
case 3'101_bv: {
_ret = 1'1_b;
}
break;
default: {
_ret = 1'0_b;
}
break;
}
}
break;
case 7'0010011_bv: {
bits<3> renamed_cpp_dx2_reserved_dx2_matchPattern = fields.funct3;
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 3'001_bv: {
_ret = 1'1_b;
}
break;
case 3'010_bv: {
_ret = 1'1_b;
}
break;
case 3'011_bv: {
_ret = 1'1_b;
}
break;
case 3'100_bv: {
_ret = 1'1_b;
}
break;
case 3'110_bv: {
_ret = 1'1_b;
}
break;
case 3'111_bv: {
_ret = 1'1_b;
}
break;
case 3'000_bv: {
_ret = ((prims::islice<6>(fields.funct7, 3'001_b) == 6'000000_b) & (fields.funct7[3'000_b] == 1'0_b));
}
break;
case 3'101_bv: {
_ret = (((prims::islice<6>(fields.funct7, 3'001_b) == 6'000000_b) | (prims::islice<6>(fields.funct7, 3'001_b) == 6'010000_b)) & (fields.funct7[3'000_b] == 1'0_b));
}
break;
default: {
_ret = 1'0_b;
}
break;
}
}
break;
case 7'0010111_bv: {
_ret = 1'1_b;
}
break;
case 7'0100011_bv: {
bits<3> renamed_cpp_dx2_reserved_dx2_matchPattern = fields.funct3;
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 3'000_bv: {
_ret = 1'1_b;
}
break;
case 3'001_bv: {
_ret = 1'1_b;
}
break;
case 3'010_bv: {
_ret = 1'1_b;
}
break;
default: {
_ret = 1'0_b;
}
break;
}
}
break;
case 7'0110011_bv: {
bits<3> renamed_cpp_dx2_reserved_dx2_matchPattern = fields.funct3;
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 3'001_bv: {
_ret = (((fields.funct7 == 7'0000000_b) | (fields.funct7 == 7'0100000_b)) | (fields.funct7 == 7'0000001_b));
}
break;
case 3'101_bv: {
_ret = ((fields.funct7 == 7'0000000_b) | (fields.funct7 == 7'0100000_b));
}
break;
case 3'000_bv: {
_ret = (fields.funct7 == 7'0000000_b);
}
break;
case 3'010_bv: {
_ret = (fields.funct7 == 7'0000000_b);
}
break;
case 3'011_bv: {
_ret = (fields.funct7 == 7'0000000_b);
}
break;
case 3'100_bv: {
_ret = (fields.funct7 == 7'0000000_b);
}
break;
case 3'110_bv: {
_ret = (fields.funct7 == 7'0000000_b);
}
break;
case 3'111_bv: {
_ret = (fields.funct7 == 7'0000000_b);
}
break;
default: {
_ret = 1'0_b;
}
break;
}
}
break;
case 7'0110111_bv: {
_ret = 1'1_b;
}
break;
case 7'1100011_bv: {
bits<3> renamed_cpp_dx2_reserved_dx2_matchPattern = fields.funct3;
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 3'000_bv: {
_ret = 1'1_b;
}
break;
case 3'001_bv: {
_ret = 1'1_b;
}
break;
case 3'100_bv: {
_ret = 1'1_b;
}
break;
case 3'101_bv: {
_ret = 1'1_b;
}
break;
case 3'110_bv: {
_ret = 1'1_b;
}
break;
case 3'111_bv: {
_ret = 1'1_b;
}
break;
default: {
_ret = 1'0_b;
}
break;
}
}
break;
case 7'1100111_bv: {
_ret = (fields.funct3 == 3'000_b);
}
break;
case 7'1101111_bv: {
_ret = 1'1_b;
}
break;
case 7'1110011_bv: {
bits<3> renamed_cpp_dx2_reserved_dx2_matchPattern = fields.funct3;
if ((renamed_cpp_dx2_reserved_dx2_matchPattern == 3'000_b)) {
bits<1> _y39;
/* bind */ {
bits<12> renamed_cpp_dx2_reserved_dx2_matchPattern = prims::concat(fields.funct7, fields.rs2);
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 12'0_bv: {
_y39 = (fields.rs1 == 5'00000_b);
}
break;
case 12'1_bv: {
_y39 = (fields.rs1 == 5'00000_b);
}
break;
case 0x12'302_xv: {
_y39 = (fields.rs1 == 5'00000_b);
}
break;
case 0x12'105_xv: {
_y39 = (fields.rs1 == 5'00000_b);
}
break;
default: {
_y39 = 1'0_b;
}
break;
}
}
_ret = ((fields.rd == 5'00000_b) & _y39);
}
else {
_ret = 1'0_b;
}
}
break;
default: {
_ret = 1'0_b;
}
break;
}
return true;
}

DECL_FN(getFields_2, struct_instFields)
DEF_FN(getFields_2, struct_instFields &_ret, bits<32> inst) {
struct_instFields res = struct_instFields{};
res.opcode = prims::islice<7>(inst, 5'00000_b);
res.funct3 = prims::islice<3>(inst, 5'01100_b);
res.funct7 = prims::islice<7>(inst, 5'11001_b);
res.funct5 = prims::islice<5>(inst, 5'11011_b);
res.funct2 = prims::islice<2>(inst, 5'11001_b);
res.rd = prims::islice<5>(inst, 5'00111_b);
res.rs1 = prims::islice<5>(inst, 5'01111_b);
res.rs2 = prims::islice<5>(inst, 5'10100_b);
res.rs3 = prims::islice<5>(inst, 5'11011_b);
bits<32> _y63 = CALL_FN(signExtend_8, prims::islice<12>(inst, 5'10100_b));
res.immI = _y63;
bits<32> _y65 = CALL_FN(signExtend_8, prims::concat(prims::islice<7>(inst, 5'11001_b), prims::islice<5>(inst, 5'00111_b)));
res.immS = _y65;
bits<32> _y69 = CALL_FN(signExtend_9, prims::concat(inst[5'11111_b], prims::concat(inst[5'00111_b], prims::concat(prims::islice<6>(inst, 5'11001_b), prims::concat(prims::islice<4>(inst, 5'01000_b), 1'0_b)))));
res.immB = _y69;
res.immU = prims::concat(prims::islice<20>(inst, 5'01100_b), 12'0_b);
bits<32> _y81 = CALL_FN(signExtend_10, prims::concat(inst[5'11111_b], prims::concat(prims::islice<8>(inst, 5'01100_b), prims::concat(inst[5'10100_b], prims::concat(prims::islice<10>(inst, 5'10101_b), 1'0_b)))));
res.immJ = _y81;
res.csr = prims::islice<12>(inst, 5'10100_b);
_ret = res;
return true;
}

DECL_FN(signExtend_8, bits<32>)
DEF_FN(signExtend_8, bits<32> &_ret, bits<12> arg) {
_ret = prims::sext<32>(arg);
return true;
}

DECL_FN(signExtend_9, bits<32>)
DEF_FN(signExtend_9, bits<32> &_ret, bits<13> arg) {
_ret = prims::sext<32>(arg);
return true;
}

DECL_FN(signExtend_10, bits<32>)
DEF_FN(signExtend_10, bits<32> &_ret, bits<21> arg) {
_ret = prims::sext<32>(arg);
return true;
}

DECL_FN(getImmediateType_0, struct_maybe_immType)
DEF_FN(getImmediateType_0, struct_maybe_immType &_ret, bits<32> inst) {
bits<5> renamed_cpp_dx2_reserved_dx2_matchPattern = prims::islice<5>(inst, 5'00010_b);
switch (renamed_cpp_dx2_reserved_dx2_matchPattern.v) {
case 5'00000_bv: {
_ret = CALL_FN(valid_2, enum_immType::ImmI);
}
break;
case 5'00100_bv: {
_ret = CALL_FN(valid_2, enum_immType::ImmI);
}
break;
case 5'11001_bv: {
_ret = CALL_FN(valid_2, enum_immType::ImmI);
}
break;
case 5'00101_bv: {
_ret = CALL_FN(valid_2, enum_immType::ImmU);
}
break;
case 5'01101_bv: {
_ret = CALL_FN(valid_2, enum_immType::ImmU);
}
break;
case 5'01000_bv: {
_ret = CALL_FN(valid_2, enum_immType::ImmS);
}
break;
case 5'11000_bv: {
_ret = CALL_FN(valid_2, enum_immType::ImmB);
}
break;
case 5'11011_bv: {
_ret = CALL_FN(valid_2, enum_immType::ImmJ);
}
break;
default: {
_ret = CALL_FN(invalid_2);
}
break;
}
return true;
}

DECL_FN(valid_2, struct_maybe_immType)
DEF_FN(valid_2, struct_maybe_immType &_ret, enum_immType x) {
_ret = struct_maybe_immType{};
_ret.valid = 1'1_b;
_ret.data = x;
return true;
}

DECL_FN(invalid_2, struct_maybe_immType)
DEF_FN(invalid_2, struct_maybe_immType &_ret) {
_ret = struct_maybe_immType{};
_ret.valid = 1'0_b;
return true;
}

DECL_FN(search_0, bits<2>)
DEF_FN(search_0, bits<2> &_ret, bits<5> idx) {
_ret = CALL_FN(read_1_0, idx);
return true;
}

DECL_FN(sliceReg_1, bits<5>)
DEF_FN(sliceReg_1, bits<5> &_ret, bits<5> idx) {
_ret = prims::islice<5>(idx, 3'000_b);
return true;
}

DECL_FN(read_1_0, bits<2>)
DEF_FN(read_1_0, bits<2> &_ret, bits<5> idx) {
if ((5'11111_b == idx)) {
_ret = READ1_FAST(scoreboard_x31_t6);
}
else {
_ret = 2'00_b;
}
bits<2> _y98;
if ((5'01111_b == idx)) {
_y98 = READ1_FAST(scoreboard_x15_a5);
}
else {
_y98 = 2'00_b;
}
bits<2> _y100;
if ((5'10111_b == idx)) {
_y100 = READ1_FAST(scoreboard_x23_s7);
}
else {
_y100 = 2'00_b;
}
bits<2> _y102;
if ((5'00111_b == idx)) {
_y102 = READ1_FAST(scoreboard_x07_t2);
}
else {
_y102 = 2'00_b;
}
bits<2> _y104;
if ((5'11011_b == idx)) {
_y104 = READ1_FAST(scoreboard_x27_s11);
}
else {
_y104 = 2'00_b;
}
bits<2> _y106;
if ((5'01011_b == idx)) {
_y106 = READ1_FAST(scoreboard_x11_a1);
}
else {
_y106 = 2'00_b;
}
bits<2> _y108;
if ((5'10011_b == idx)) {
_y108 = READ1_FAST(scoreboard_x19_s3);
}
else {
_y108 = 2'00_b;
}
bits<2> _y110;
if ((5'00011_b == idx)) {
_y110 = READ1_FAST(scoreboard_x03_gp);
}
else {
_y110 = 2'00_b;
}
bits<2> _y112;
if ((5'11101_b == idx)) {
_y112 = READ1_FAST(scoreboard_x29_t4);
}
else {
_y112 = 2'00_b;
}
bits<2> _y114;
if ((5'01101_b == idx)) {
_y114 = READ1_FAST(scoreboard_x13_a3);
}
else {
_y114 = 2'00_b;
}
bits<2> _y116;
if ((5'10101_b == idx)) {
_y116 = READ1_FAST(scoreboard_x21_s5);
}
else {
_y116 = 2'00_b;
}
bits<2> _y118;
if ((5'00101_b == idx)) {
_y118 = READ1_FAST(scoreboard_x05_t0);
}
else {
_y118 = 2'00_b;
}
bits<2> _y120;
if ((5'11001_b == idx)) {
_y120 = READ1_FAST(scoreboard_x25_s9);
}
else {
_y120 = 2'00_b;
}
bits<2> _y122;
if ((5'01001_b == idx)) {
_y122 = READ1_FAST(scoreboard_x09_s1);
}
else {
_y122 = 2'00_b;
}
bits<2> _y124;
if ((5'10001_b == idx)) {
_y124 = READ1_FAST(scoreboard_x17_a7);
}
else {
_y124 = 2'00_b;
}
bits<2> _y126;
if ((5'00001_b == idx)) {
_y126 = READ1_FAST(scoreboard_x01_ra);
}
else {
_y126 = 2'00_b;
}
bits<2> _y128;
if ((5'11110_b == idx)) {
_y128 = READ1_FAST(scoreboard_x30_t5);
}
else {
_y128 = 2'00_b;
}
bits<2> _y130;
if ((5'01110_b == idx)) {
_y130 = READ1_FAST(scoreboard_x14_a4);
}
else {
_y130 = 2'00_b;
}
bits<2> _y132;
if ((5'10110_b == idx)) {
_y132 = READ1_FAST(scoreboard_x22_s6);
}
else {
_y132 = 2'00_b;
}
bits<2> _y134;
if ((5'00110_b == idx)) {
_y134 = READ1_FAST(scoreboard_x06_t1);
}
else {
_y134 = 2'00_b;
}
bits<2> _y136;
if ((5'11010_b == idx)) {
_y136 = READ1_FAST(scoreboard_x26_s10);
}
else {
_y136 = 2'00_b;
}
bits<2> _y138;
if ((5'01010_b == idx)) {
_y138 = READ1_FAST(scoreboard_x10_a0);
}
else {
_y138 = 2'00_b;
}
bits<2> _y140;
if ((5'10010_b == idx)) {
_y140 = READ1_FAST(scoreboard_x18_s2);
}
else {
_y140 = 2'00_b;
}
bits<2> _y142;
if ((5'00010_b == idx)) {
_y142 = READ1_FAST(scoreboard_x02_sp);
}
else {
_y142 = 2'00_b;
}
bits<2> _y144;
if ((5'11100_b == idx)) {
_y144 = READ1_FAST(scoreboard_x28_t3);
}
else {
_y144 = 2'00_b;
}
bits<2> _y146;
if ((5'01100_b == idx)) {
_y146 = READ1_FAST(scoreboard_x12_a2);
}
else {
_y146 = 2'00_b;
}
bits<2> _y148;
if ((5'10100_b == idx)) {
_y148 = READ1_FAST(scoreboard_x20_s4);
}
else {
_y148 = 2'00_b;
}
bits<2> _y150;
if ((5'00100_b == idx)) {
_y150 = READ1_FAST(scoreboard_x04_tp);
}
else {
_y150 = 2'00_b;
}
bits<2> _y152;
if ((5'11000_b == idx)) {
_y152 = READ1_FAST(scoreboard_x24_s8);
}
else {
_y152 = 2'00_b;
}
bits<2> _y154;
if ((5'01000_b == idx)) {
_y154 = READ1_FAST(scoreboard_x08_s0_fp);
}
else {
_y154 = 2'00_b;
}
bits<2> _y156;
if ((5'10000_b == idx)) {
_y156 = READ1_FAST(scoreboard_x16_a6);
}
else {
_y156 = 2'00_b;
}
bits<2> _y158;
if ((5'00000_b == idx)) {
_y158 = READ1_FAST(scoreboard_x00_zero);
}
else {
_y158 = 2'00_b;
}
_ret = (((((_ret | _y98) | (_y100 | _y102)) | ((_y104 | _y106) | (_y108 | _y110))) | (((_y112 | _y114) | (_y116 | _y118)) | ((_y120 | _y122) | (_y124 | _y126)))) | ((((_y128 | _y130) | (_y132 | _y134)) | ((_y136 | _y138) | (_y140 | _y142))) | (((_y144 | _y146) | (_y148 | _y150)) | ((_y152 | _y154) | (_y156 | _y158)))));
return true;
}

DECL_FN(search_1, bits<2>)
DEF_FN(search_1, bits<2> &_ret, bits<5> idx) {
_ret = CALL_FN(read_1_1, idx);
return true;
}

DECL_FN(read_1_1, bits<2>)
DEF_FN(read_1_1, bits<2> &_ret, bits<5> idx) {
if ((5'11111_b == idx)) {
_ret = READ1_FAST(scoreboard_x31_t6);
}
else {
_ret = 2'00_b;
}
bits<2> _y161;
if ((5'01111_b == idx)) {
_y161 = READ1_FAST(scoreboard_x15_a5);
}
else {
_y161 = 2'00_b;
}
bits<2> _y163;
if ((5'10111_b == idx)) {
_y163 = READ1_FAST(scoreboard_x23_s7);
}
else {
_y163 = 2'00_b;
}
bits<2> _y165;
if ((5'00111_b == idx)) {
_y165 = READ1_FAST(scoreboard_x07_t2);
}
else {
_y165 = 2'00_b;
}
bits<2> _y167;
if ((5'11011_b == idx)) {
_y167 = READ1_FAST(scoreboard_x27_s11);
}
else {
_y167 = 2'00_b;
}
bits<2> _y169;
if ((5'01011_b == idx)) {
_y169 = READ1_FAST(scoreboard_x11_a1);
}
else {
_y169 = 2'00_b;
}
bits<2> _y171;
if ((5'10011_b == idx)) {
_y171 = READ1_FAST(scoreboard_x19_s3);
}
else {
_y171 = 2'00_b;
}
bits<2> _y173;
if ((5'00011_b == idx)) {
_y173 = READ1_FAST(scoreboard_x03_gp);
}
else {
_y173 = 2'00_b;
}
bits<2> _y175;
if ((5'11101_b == idx)) {
_y175 = READ1_FAST(scoreboard_x29_t4);
}
else {
_y175 = 2'00_b;
}
bits<2> _y177;
if ((5'01101_b == idx)) {
_y177 = READ1_FAST(scoreboard_x13_a3);
}
else {
_y177 = 2'00_b;
}
bits<2> _y179;
if ((5'10101_b == idx)) {
_y179 = READ1_FAST(scoreboard_x21_s5);
}
else {
_y179 = 2'00_b;
}
bits<2> _y181;
if ((5'00101_b == idx)) {
_y181 = READ1_FAST(scoreboard_x05_t0);
}
else {
_y181 = 2'00_b;
}
bits<2> _y183;
if ((5'11001_b == idx)) {
_y183 = READ1_FAST(scoreboard_x25_s9);
}
else {
_y183 = 2'00_b;
}
bits<2> _y185;
if ((5'01001_b == idx)) {
_y185 = READ1_FAST(scoreboard_x09_s1);
}
else {
_y185 = 2'00_b;
}
bits<2> _y187;
if ((5'10001_b == idx)) {
_y187 = READ1_FAST(scoreboard_x17_a7);
}
else {
_y187 = 2'00_b;
}
bits<2> _y189;
if ((5'00001_b == idx)) {
_y189 = READ1_FAST(scoreboard_x01_ra);
}
else {
_y189 = 2'00_b;
}
bits<2> _y191;
if ((5'11110_b == idx)) {
_y191 = READ1_FAST(scoreboard_x30_t5);
}
else {
_y191 = 2'00_b;
}
bits<2> _y193;
if ((5'01110_b == idx)) {
_y193 = READ1_FAST(scoreboard_x14_a4);
}
else {
_y193 = 2'00_b;
}
bits<2> _y195;
if ((5'10110_b == idx)) {
_y195 = READ1_FAST(scoreboard_x22_s6);
}
else {
_y195 = 2'00_b;
}
bits<2> _y197;
if ((5'00110_b == idx)) {
_y197 = READ1_FAST(scoreboard_x06_t1);
}
else {
_y197 = 2'00_b;
}
bits<2> _y199;
if ((5'11010_b == idx)) {
_y199 = READ1_FAST(scoreboard_x26_s10);
}
else {
_y199 = 2'00_b;
}
bits<2> _y201;
if ((5'01010_b == idx)) {
_y201 = READ1_FAST(scoreboard_x10_a0);
}
else {
_y201 = 2'00_b;
}
bits<2> _y203;
if ((5'10010_b == idx)) {
_y203 = READ1_FAST(scoreboard_x18_s2);
}
else {
_y203 = 2'00_b;
}
bits<2> _y205;
if ((5'00010_b == idx)) {
_y205 = READ1_FAST(scoreboard_x02_sp);
}
else {
_y205 = 2'00_b;
}
bits<2> _y207;
if ((5'11100_b == idx)) {
_y207 = READ1_FAST(scoreboard_x28_t3);
}
else {
_y207 = 2'00_b;
}
bits<2> _y209;
if ((5'01100_b == idx)) {
_y209 = READ1_FAST(scoreboard_x12_a2);
}
else {
_y209 = 2'00_b;
}
bits<2> _y211;
if ((5'10100_b == idx)) {
_y211 = READ1_FAST(scoreboard_x20_s4);
}
else {
_y211 = 2'00_b;
}
bits<2> _y213;
if ((5'00100_b == idx)) {
_y213 = READ1_FAST(scoreboard_x04_tp);
}
else {
_y213 = 2'00_b;
}
bits<2> _y215;
if ((5'11000_b == idx)) {
_y215 = READ1_FAST(scoreboard_x24_s8);
}
else {
_y215 = 2'00_b;
}
bits<2> _y217;
if ((5'01000_b == idx)) {
_y217 = READ1_FAST(scoreboard_x08_s0_fp);
}
else {
_y217 = 2'00_b;
}
bits<2> _y219;
if ((5'10000_b == idx)) {
_y219 = READ1_FAST(scoreboard_x16_a6);
}
else {
_y219 = 2'00_b;
}
bits<2> _y221;
if ((5'00000_b == idx)) {
_y221 = READ1_FAST(scoreboard_x00_zero);
}
else {
_y221 = 2'00_b;
}
_ret = (((((_ret | _y161) | (_y163 | _y165)) | ((_y167 | _y169) | (_y171 | _y173))) | (((_y175 | _y177) | (_y179 | _y181)) | ((_y183 | _y185) | (_y187 | _y189)))) | ((((_y191 | _y193) | (_y195 | _y197)) | ((_y199 | _y201) | (_y203 | _y205))) | (((_y207 | _y209) | (_y211 | _y213)) | ((_y215 | _y217) | (_y219 | _y221)))));
return true;
}

DECL_FN(insert_0, unit)
DEF_FN(insert_0, unit &_ret, bits<5> idx) {
bits<2> old_score = CALL_FN(read_1_1, idx);
bits<2> new_score = CALL_FN(sat_incr_0, old_score);
_ret = CALL_FN(write_1_0, idx, new_score);
return true;
}

DECL_FN(sat_incr_0, bits<2>)
DEF_FN(sat_incr_0, bits<2> &_ret, bits<2> a) {
_ret = (a + 2'01_b);
return true;
}

DECL_FN(write_1_0, unit)
DEF_FN(write_1_0, unit &_ret, bits<5> idx, bits<2> val) {
if ((idx == 5'00000_b)) {
WRITE1_FAST(scoreboard_x00_zero, val);
}
if ((idx == 5'00001_b)) {
WRITE1_FAST(scoreboard_x01_ra, val);
}
if ((idx == 5'00010_b)) {
WRITE1_FAST(scoreboard_x02_sp, val);
}
if ((idx == 5'00011_b)) {
WRITE1_FAST(scoreboard_x03_gp, val);
}
if ((idx == 5'00100_b)) {
WRITE1_FAST(scoreboard_x04_tp, val);
}
if ((idx == 5'00101_b)) {
WRITE1_FAST(scoreboard_x05_t0, val);
}
if ((idx == 5'00110_b)) {
WRITE1_FAST(scoreboard_x06_t1, val);
}
if ((idx == 5'00111_b)) {
WRITE1_FAST(scoreboard_x07_t2, val);
}
if ((idx == 5'01000_b)) {
WRITE1_FAST(scoreboard_x08_s0_fp, val);
}
if ((idx == 5'01001_b)) {
WRITE1_FAST(scoreboard_x09_s1, val);
}
if ((idx == 5'01010_b)) {
WRITE1_FAST(scoreboard_x10_a0, val);
}
if ((idx == 5'01011_b)) {
WRITE1_FAST(scoreboard_x11_a1, val);
}
if ((idx == 5'01100_b)) {
WRITE1_FAST(scoreboard_x12_a2, val);
}
if ((idx == 5'01101_b)) {
WRITE1_FAST(scoreboard_x13_a3, val);
}
if ((idx == 5'01110_b)) {
WRITE1_FAST(scoreboard_x14_a4, val);
}
if ((idx == 5'01111_b)) {
WRITE1_FAST(scoreboard_x15_a5, val);
}
if ((idx == 5'10000_b)) {
WRITE1_FAST(scoreboard_x16_a6, val);
}
if ((idx == 5'10001_b)) {
WRITE1_FAST(scoreboard_x17_a7, val);
}
if ((idx == 5'10010_b)) {
WRITE1_FAST(scoreboard_x18_s2, val);
}
if ((idx == 5'10011_b)) {
WRITE1_FAST(scoreboard_x19_s3, val);
}
if ((idx == 5'10100_b)) {
WRITE1_FAST(scoreboard_x20_s4, val);
}
if ((idx == 5'10101_b)) {
WRITE1_FAST(scoreboard_x21_s5, val);
}
if ((idx == 5'10110_b)) {
WRITE1_FAST(scoreboard_x22_s6, val);
}
if ((idx == 5'10111_b)) {
WRITE1_FAST(scoreboard_x23_s7, val);
}
if ((idx == 5'11000_b)) {
WRITE1_FAST(scoreboard_x24_s8, val);
}
if ((idx == 5'11001_b)) {
WRITE1_FAST(scoreboard_x25_s9, val);
}
if ((idx == 5'11010_b)) {
WRITE1_FAST(scoreboard_x26_s10, val);
}
if ((idx == 5'11011_b)) {
WRITE1_FAST(scoreboard_x27_s11, val);
}
if ((idx == 5'11100_b)) {
WRITE1_FAST(scoreboard_x28_t3, val);
}
if ((idx == 5'11101_b)) {
WRITE1_FAST(scoreboard_x29_t4, val);
}
if ((idx == 5'11110_b)) {
WRITE1_FAST(scoreboard_x30_t5, val);
}
if ((idx == 5'11111_b)) {
WRITE1_FAST(scoreboard_x31_t6, val);
}
_ret = prims::tt;
return true;
}

DECL_FN(read_1_2, bits<32>)
DEF_FN(read_1_2, bits<32> &_ret, bits<5> idx) {
if ((5'11111_b == idx)) {
_ret = READ1_FAST(rf_x31_t6);
}
else {
_ret = 32'0_b;
}
bits<32> _y257;
if ((5'01111_b == idx)) {
_y257 = READ1_FAST(rf_x15_a5);
}
else {
_y257 = 32'0_b;
}
bits<32> _y259;
if ((5'10111_b == idx)) {
_y259 = READ1_FAST(rf_x23_s7);
}
else {
_y259 = 32'0_b;
}
bits<32> _y261;
if ((5'00111_b == idx)) {
_y261 = READ1_FAST(rf_x07_t2);
}
else {
_y261 = 32'0_b;
}
bits<32> _y263;
if ((5'11011_b == idx)) {
_y263 = READ1_FAST(rf_x27_s11);
}
else {
_y263 = 32'0_b;
}
bits<32> _y265;
if ((5'01011_b == idx)) {
_y265 = READ1_FAST(rf_x11_a1);
}
else {
_y265 = 32'0_b;
}
bits<32> _y267;
if ((5'10011_b == idx)) {
_y267 = READ1_FAST(rf_x19_s3);
}
else {
_y267 = 32'0_b;
}
bits<32> _y269;
if ((5'00011_b == idx)) {
_y269 = READ1_FAST(rf_x03_gp);
}
else {
_y269 = 32'0_b;
}
bits<32> _y271;
if ((5'11101_b == idx)) {
_y271 = READ1_FAST(rf_x29_t4);
}
else {
_y271 = 32'0_b;
}
bits<32> _y273;
if ((5'01101_b == idx)) {
_y273 = READ1_FAST(rf_x13_a3);
}
else {
_y273 = 32'0_b;
}
bits<32> _y275;
if ((5'10101_b == idx)) {
_y275 = READ1_FAST(rf_x21_s5);
}
else {
_y275 = 32'0_b;
}
bits<32> _y277;
if ((5'00101_b == idx)) {
_y277 = READ1_FAST(rf_x05_t0);
}
else {
_y277 = 32'0_b;
}
bits<32> _y279;
if ((5'11001_b == idx)) {
_y279 = READ1_FAST(rf_x25_s9);
}
else {
_y279 = 32'0_b;
}
bits<32> _y281;
if ((5'01001_b == idx)) {
_y281 = READ1_FAST(rf_x09_s1);
}
else {
_y281 = 32'0_b;
}
bits<32> _y283;
if ((5'10001_b == idx)) {
_y283 = READ1_FAST(rf_x17_a7);
}
else {
_y283 = 32'0_b;
}
bits<32> _y285;
if ((5'00001_b == idx)) {
_y285 = READ1_FAST(rf_x01_ra);
}
else {
_y285 = 32'0_b;
}
bits<32> _y287;
if ((5'11110_b == idx)) {
_y287 = READ1_FAST(rf_x30_t5);
}
else {
_y287 = 32'0_b;
}
bits<32> _y289;
if ((5'01110_b == idx)) {
_y289 = READ1_FAST(rf_x14_a4);
}
else {
_y289 = 32'0_b;
}
bits<32> _y291;
if ((5'10110_b == idx)) {
_y291 = READ1_FAST(rf_x22_s6);
}
else {
_y291 = 32'0_b;
}
bits<32> _y293;
if ((5'00110_b == idx)) {
_y293 = READ1_FAST(rf_x06_t1);
}
else {
_y293 = 32'0_b;
}
bits<32> _y295;
if ((5'11010_b == idx)) {
_y295 = READ1_FAST(rf_x26_s10);
}
else {
_y295 = 32'0_b;
}
bits<32> _y297;
if ((5'01010_b == idx)) {
_y297 = READ1_FAST(rf_x10_a0);
}
else {
_y297 = 32'0_b;
}
bits<32> _y299;
if ((5'10010_b == idx)) {
_y299 = READ1_FAST(rf_x18_s2);
}
else {
_y299 = 32'0_b;
}
bits<32> _y301;
if ((5'00010_b == idx)) {
_y301 = READ1_FAST(rf_x02_sp);
}
else {
_y301 = 32'0_b;
}
bits<32> _y303;
if ((5'11100_b == idx)) {
_y303 = READ1_FAST(rf_x28_t3);
}
else {
_y303 = 32'0_b;
}
bits<32> _y305;
if ((5'01100_b == idx)) {
_y305 = READ1_FAST(rf_x12_a2);
}
else {
_y305 = 32'0_b;
}
bits<32> _y307;
if ((5'10100_b == idx)) {
_y307 = READ1_FAST(rf_x20_s4);
}
else {
_y307 = 32'0_b;
}
bits<32> _y309;
if ((5'00100_b == idx)) {
_y309 = READ1_FAST(rf_x04_tp);
}
else {
_y309 = 32'0_b;
}
bits<32> _y311;
if ((5'11000_b == idx)) {
_y311 = READ1_FAST(rf_x24_s8);
}
else {
_y311 = 32'0_b;
}
bits<32> _y313;
if ((5'01000_b == idx)) {
_y313 = READ1_FAST(rf_x08_s0_fp);
}
else {
_y313 = 32'0_b;
}
bits<32> _y315;
if ((5'10000_b == idx)) {
_y315 = READ1_FAST(rf_x16_a6);
}
else {
_y315 = 32'0_b;
}
bits<32> _y317;
if ((5'00000_b == idx)) {
_y317 = READ1_FAST(rf_x00_zero);
}
else {
_y317 = 32'0_b;
}
_ret = (((((_ret | _y257) | (_y259 | _y261)) | ((_y263 | _y265) | (_y267 | _y269))) | (((_y271 | _y273) | (_y275 | _y277)) | ((_y279 | _y281) | (_y283 | _y285)))) | ((((_y287 | _y289) | (_y291 | _y293)) | ((_y295 | _y297) | (_y299 | _y301))) | (((_y303 | _y305) | (_y307 | _y309)) | ((_y311 | _y313) | (_y315 | _y317)))));
return true;
}

DECL_FN(read_1_3, bits<32>)
DEF_FN(read_1_3, bits<32> &_ret, bits<5> idx) {
if ((5'11111_b == idx)) {
_ret = READ1_FAST(rf_x31_t6);
}
else {
_ret = 32'0_b;
}
bits<32> _y320;
if ((5'01111_b == idx)) {
_y320 = READ1_FAST(rf_x15_a5);
}
else {
_y320 = 32'0_b;
}
bits<32> _y322;
if ((5'10111_b == idx)) {
_y322 = READ1_FAST(rf_x23_s7);
}
else {
_y322 = 32'0_b;
}
bits<32> _y324;
if ((5'00111_b == idx)) {
_y324 = READ1_FAST(rf_x07_t2);
}
else {
_y324 = 32'0_b;
}
bits<32> _y326;
if ((5'11011_b == idx)) {
_y326 = READ1_FAST(rf_x27_s11);
}
else {
_y326 = 32'0_b;
}
bits<32> _y328;
if ((5'01011_b == idx)) {
_y328 = READ1_FAST(rf_x11_a1);
}
else {
_y328 = 32'0_b;
}
bits<32> _y330;
if ((5'10011_b == idx)) {
_y330 = READ1_FAST(rf_x19_s3);
}
else {
_y330 = 32'0_b;
}
bits<32> _y332;
if ((5'00011_b == idx)) {
_y332 = READ1_FAST(rf_x03_gp);
}
else {
_y332 = 32'0_b;
}
bits<32> _y334;
if ((5'11101_b == idx)) {
_y334 = READ1_FAST(rf_x29_t4);
}
else {
_y334 = 32'0_b;
}
bits<32> _y336;
if ((5'01101_b == idx)) {
_y336 = READ1_FAST(rf_x13_a3);
}
else {
_y336 = 32'0_b;
}
bits<32> _y338;
if ((5'10101_b == idx)) {
_y338 = READ1_FAST(rf_x21_s5);
}
else {
_y338 = 32'0_b;
}
bits<32> _y340;
if ((5'00101_b == idx)) {
_y340 = READ1_FAST(rf_x05_t0);
}
else {
_y340 = 32'0_b;
}
bits<32> _y342;
if ((5'11001_b == idx)) {
_y342 = READ1_FAST(rf_x25_s9);
}
else {
_y342 = 32'0_b;
}
bits<32> _y344;
if ((5'01001_b == idx)) {
_y344 = READ1_FAST(rf_x09_s1);
}
else {
_y344 = 32'0_b;
}
bits<32> _y346;
if ((5'10001_b == idx)) {
_y346 = READ1_FAST(rf_x17_a7);
}
else {
_y346 = 32'0_b;
}
bits<32> _y348;
if ((5'00001_b == idx)) {
_y348 = READ1_FAST(rf_x01_ra);
}
else {
_y348 = 32'0_b;
}
bits<32> _y350;
if ((5'11110_b == idx)) {
_y350 = READ1_FAST(rf_x30_t5);
}
else {
_y350 = 32'0_b;
}
bits<32> _y352;
if ((5'01110_b == idx)) {
_y352 = READ1_FAST(rf_x14_a4);
}
else {
_y352 = 32'0_b;
}
bits<32> _y354;
if ((5'10110_b == idx)) {
_y354 = READ1_FAST(rf_x22_s6);
}
else {
_y354 = 32'0_b;
}
bits<32> _y356;
if ((5'00110_b == idx)) {
_y356 = READ1_FAST(rf_x06_t1);
}
else {
_y356 = 32'0_b;
}
bits<32> _y358;
if ((5'11010_b == idx)) {
_y358 = READ1_FAST(rf_x26_s10);
}
else {
_y358 = 32'0_b;
}
bits<32> _y360;
if ((5'01010_b == idx)) {
_y360 = READ1_FAST(rf_x10_a0);
}
else {
_y360 = 32'0_b;
}
bits<32> _y362;
if ((5'10010_b == idx)) {
_y362 = READ1_FAST(rf_x18_s2);
}
else {
_y362 = 32'0_b;
}
bits<32> _y364;
if ((5'00010_b == idx)) {
_y364 = READ1_FAST(rf_x02_sp);
}
else {
_y364 = 32'0_b;
}
bits<32> _y366;
if ((5'11100_b == idx)) {
_y366 = READ1_FAST(rf_x28_t3);
}
else {
_y366 = 32'0_b;
}
bits<32> _y368;
if ((5'01100_b == idx)) {
_y368 = READ1_FAST(rf_x12_a2);
}
else {
_y368 = 32'0_b;
}
bits<32> _y370;
if ((5'10100_b == idx)) {
_y370 = READ1_FAST(rf_x20_s4);
}
else {
_y370 = 32'0_b;
}
bits<32> _y372;
if ((5'00100_b == idx)) {
_y372 = READ1_FAST(rf_x04_tp);
}
else {
_y372 = 32'0_b;
}
bits<32> _y374;
if ((5'11000_b == idx)) {
_y374 = READ1_FAST(rf_x24_s8);
}
else {
_y374 = 32'0_b;
}
bits<32> _y376;
if ((5'01000_b == idx)) {
_y376 = READ1_FAST(rf_x08_s0_fp);
}
else {
_y376 = 32'0_b;
}
bits<32> _y378;
if ((5'10000_b == idx)) {
_y378 = READ1_FAST(rf_x16_a6);
}
else {
_y378 = 32'0_b;
}
bits<32> _y380;
if ((5'00000_b == idx)) {
_y380 = READ1_FAST(rf_x00_zero);
}
else {
_y380 = 32'0_b;
}
_ret = (((((_ret | _y320) | (_y322 | _y324)) | ((_y326 | _y328) | (_y330 | _y332))) | (((_y334 | _y336) | (_y338 | _y340)) | ((_y342 | _y344) | (_y346 | _y348)))) | ((((_y350 | _y352) | (_y354 | _y356)) | ((_y358 | _y360) | (_y362 | _y364))) | (((_y366 | _y368) | (_y370 | _y372)) | ((_y374 | _y376) | (_y378 | _y380)))));
return true;
}

DECL_FN(enq_8, unit)
DEF_FN(enq_8, unit &_ret, struct_decode_bookkeeping data) {
bits<1> _x267 = CALL_FN(can_enq_9);
if (~(_x267)) {
FAIL();
}
WRITE1_FAST(d2e_data0, data);
WRITE1_FAST(d2e_valid0, 1'1_b);
_ret = prims::tt;
return true;
}

DECL_FN(can_enq_9, bits<1>)
DEF_FN(can_enq_9, bits<1> &_ret) {
bits<1> _x268 = READ1_FAST(d2e_valid0);
_ret = ~(_x268);
return true;
}
DEF_RULE(Decode) {
struct_mem_resp instr = CALL_FN(deq_7);
/* bind */ {
bits<32> _tmp0 = instr.data;
bits<32> instr = _tmp0;
struct_fetch_bookkeeping fetched_bookkeeping = CALL_FN(deq_8);
struct_decodedInst decodedInst = CALL_FN(decode_fun_0, instr);
bits<1> _y382 = READ1_FAST(epoch);
if ((fetched_bookkeeping.epoch == _y382)) {
struct_instFields _x271 = CALL_FN(getFields_2, instr);
bits<5> rs1_idx = _x271.rs1;
struct_instFields _x272 = CALL_FN(getFields_2, instr);
bits<5> rs2_idx = _x272.rs2;
bits<5> _idx4 = CALL_FN(sliceReg_1, rs1_idx);
bits<2> score1 = CALL_FN(search_0, _idx4);
bits<5> _idx6 = CALL_FN(sliceReg_1, rs2_idx);
bits<2> score2 = CALL_FN(search_1, _idx6);
if (~(((score1 == 2'00_b) & (score2 == 2'00_b)))) {
FAIL();
}
if (decodedInst.valid_rd) {
struct_instFields _x277 = CALL_FN(getFields_2, instr);
bits<5> rd_idx = _x277.rd;
bits<5> _idx8 = CALL_FN(sliceReg_1, rd_idx);
CALL_FN(insert_0, _idx8);
}
/* bind */ {
bits<5> _idx10 = CALL_FN(sliceReg_1, rs1_idx);
bits<32> rs1 = CALL_FN(read_1_2, _idx10);
bits<5> _idx12 = CALL_FN(sliceReg_1, rs2_idx);
bits<32> rs2 = CALL_FN(read_1_3, _idx12);
struct_decode_bookkeeping decode_bookkeeping = struct_decode_bookkeeping{};
decode_bookkeeping.pc = fetched_bookkeeping.pc;
decode_bookkeeping.ppc = fetched_bookkeeping.ppc;
decode_bookkeeping.epoch = fetched_bookkeeping.epoch;
decode_bookkeeping.dInst = decodedInst;
decode_bookkeeping.rval1 = rs1;
decode_bookkeeping.rval2 = rs2;
CALL_FN(enq_8, decode_bookkeeping);
}
}
}

COMMIT();
}
#undef RULE_NAME

#ifdef SIM_FUZZER
using assert_pred_t = bool(*)(const module_rv32&);
using assert_pred_rule_t = bool(*)(const module_rv32&);
assert_pred_t assert_pred = nullptr;
assert_pred_t assert_pred_final = nullptr;
assert_pred_rule_t assert_pred__rule = nullptr;
std::vector<snapshot_t> snapshot_history;

#define MODULE_PIPELINE_FUZZ_RULES(x) \
   X("rule_Dmem") \
   X("rule_Execute") \
   X("rule_Tick") \
   X("rule_StepMultiplier") \
   X("rule_Writeback") \
   X("rule_Imem") \
   X("rule_WaitImem") \
   X("rule_Fetch") \
   X("rule_Decode")
#endif

public:
void finish(cuttlesim::exit_info exit_config, int exit_code) {
meta.finished = true;
meta.exit_config = exit_config;
meta.exit_code = exit_code;
}

 bool is_legal_inst(bits<32> inst)
  {
    bits<1> legal;
    fn_Decode_isLegalInstruction_0(legal, inst);
    return static_cast<bool>(legal);
  }

    bool finished() const // changed to const
  {
    return meta.finished;
  }

  int finish_exit_code() const // added this
  {
    return meta.exit_code;
  }

snapshot_t snapshot() const {
return snapshot_t(Log.snapshot(), meta);
}

static constexpr state_t initial_state() {
state_t init {
.toIMem_data0 = struct_mem_req{ 4'0000_b, 32'0_b, 32'0_b },
.toIMem_valid0 = 1'0_b,
.fromIMem_data0 = struct_mem_resp{ 4'0000_b, 32'0_b, 32'0_b },
.fromIMem_valid0 = 1'0_b,
.toDMem_data0 = struct_mem_req{ 4'0000_b, 32'0_b, 32'0_b },
.toDMem_valid0 = 1'0_b,
.fromDMem_data0 = struct_mem_resp{ 4'0000_b, 32'0_b, 32'0_b },
.fromDMem_valid0 = 1'0_b,
.f2d_data0 = struct_fetch_bookkeeping{ 32'0_b, 32'0_b, 1'0_b },
.f2d_valid0 = 1'0_b,
.f2dprim_data0 = struct_fetch_bookkeeping{ 32'0_b, 32'0_b, 1'0_b },
.f2dprim_valid0 = 1'0_b,
.d2e_data0 = struct_decode_bookkeeping{ 32'0_b, 32'0_b, 1'0_b, struct_decodedInst{ 1'0_b, 1'0_b, 1'0_b, 1'0_b, 32'0_b, struct_maybe_immType{ 1'0_b, enum_immType::ImmI } }, 32'0_b, 32'0_b },
.d2e_valid0 = 1'0_b,
.e2w_data0 = struct_execute_bookkeeping{ 1'0_b, 2'00_b, 2'00_b, 32'0_b, struct_decodedInst{ 1'0_b, 1'0_b, 1'0_b, 1'0_b, 32'0_b, struct_maybe_immType{ 1'0_b, enum_immType::ImmI } } },
.e2w_valid0 = 1'0_b,
.rf_x00_zero = 32'0_b,
.rf_x01_ra = 32'0_b,
.rf_x02_sp = 32'0_b,
.rf_x03_gp = 32'0_b,
.rf_x04_tp = 32'0_b,
.rf_x05_t0 = 32'0_b,
.rf_x06_t1 = 32'0_b,
.rf_x07_t2 = 32'0_b,
.rf_x08_s0_fp = 32'0_b,
.rf_x09_s1 = 32'0_b,
.rf_x10_a0 = 32'0_b,
.rf_x11_a1 = 32'0_b,
.rf_x12_a2 = 32'0_b,
.rf_x13_a3 = 32'0_b,
.rf_x14_a4 = 32'0_b,
.rf_x15_a5 = 32'0_b,
.rf_x16_a6 = 32'0_b,
.rf_x17_a7 = 32'0_b,
.rf_x18_s2 = 32'0_b,
.rf_x19_s3 = 32'0_b,
.rf_x20_s4 = 32'0_b,
.rf_x21_s5 = 32'0_b,
.rf_x22_s6 = 32'0_b,
.rf_x23_s7 = 32'0_b,
.rf_x24_s8 = 32'0_b,
.rf_x25_s9 = 32'0_b,
.rf_x26_s10 = 32'0_b,
.rf_x27_s11 = 32'0_b,
.rf_x28_t3 = 32'0_b,
.rf_x29_t4 = 32'0_b,
.rf_x30_t5 = 32'0_b,
.rf_x31_t6 = 32'0_b,
.mulState_valid = 1'0_b,
.mulState_operand1 = 32'0_b,
.mulState_operand2 = 32'0_b,
.mulState_result = 64'0_b,
.mulState_n_step = 5'00000_b,
.mulState_finished = 1'0_b,
.scoreboard_x00_zero = 2'00_b,
.scoreboard_x01_ra = 2'00_b,
.scoreboard_x02_sp = 2'00_b,
.scoreboard_x03_gp = 2'00_b,
.scoreboard_x04_tp = 2'00_b,
.scoreboard_x05_t0 = 2'00_b,
.scoreboard_x06_t1 = 2'00_b,
.scoreboard_x07_t2 = 2'00_b,
.scoreboard_x08_s0_fp = 2'00_b,
.scoreboard_x09_s1 = 2'00_b,
.scoreboard_x10_a0 = 2'00_b,
.scoreboard_x11_a1 = 2'00_b,
.scoreboard_x12_a2 = 2'00_b,
.scoreboard_x13_a3 = 2'00_b,
.scoreboard_x14_a4 = 2'00_b,
.scoreboard_x15_a5 = 2'00_b,
.scoreboard_x16_a6 = 2'00_b,
.scoreboard_x17_a7 = 2'00_b,
.scoreboard_x18_s2 = 2'00_b,
.scoreboard_x19_s3 = 2'00_b,
.scoreboard_x20_s4 = 2'00_b,
.scoreboard_x21_s5 = 2'00_b,
.scoreboard_x22_s6 = 2'00_b,
.scoreboard_x23_s7 = 2'00_b,
.scoreboard_x24_s8 = 2'00_b,
.scoreboard_x25_s9 = 2'00_b,
.scoreboard_x26_s10 = 2'00_b,
.scoreboard_x27_s11 = 2'00_b,
.scoreboard_x28_t3 = 2'00_b,
.scoreboard_x29_t4 = 2'00_b,
.scoreboard_x30_t5 = 2'00_b,
.scoreboard_x31_t6 = 2'00_b,
.cycle_count = 32'0_b,
.instr_count = 32'0_b,
.pc = 32'0_b,
.epoch = 1'0_b,
};
return init;
}

explicit module_rv32(const state_t init = initial_state()) : log(init), Log(init), extfuns{}, meta{} {
#ifndef SIM_MINIMAL
rng.seed(cuttlesim::random_seed);
#endif
}

 extfuns_t &get_extfuns() // added this
   {
      return extfuns;
   }

   const extfuns_t &get_extfuns() const // added thi
   {
      return extfuns;
   }

_virtual void strobe() const {}

void cycle() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
rule_Writeback();
rule_Execute();
rule_StepMultiplier();
rule_Decode();
rule_WaitImem();
rule_Fetch();
rule_Imem();
rule_Dmem();
rule_Tick();
strobe();
}

_flatten module_rv32& run(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
}
return *this;
}

#ifndef SIM_MINIMAL
typedef bool (module_rv32::*rule_ptr)();
void cycle_randomized() {
meta.cycle_id++;
cuttlesim::ruletrace::set_cycle(meta.cycle_id); 
log.rwset = Log.rwset = rwset_t{};
static constexpr rule_ptr rules[9] {
&module_rv32::rule_Dmem,
&module_rv32::rule_Execute,
&module_rv32::rule_Tick,
&module_rv32::rule_StepMultiplier,
&module_rv32::rule_Writeback,
&module_rv32::rule_Imem,
&module_rv32::rule_WaitImem,
&module_rv32::rule_Fetch,
&module_rv32::rule_Decode};
(this->*rules[uniform(rng)])();
strobe();
}

_flatten module_rv32& run_randomized(std::uint_fast64_t ncycles) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
}
return *this;
}

_flatten module_rv32& trace(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}

_flatten module_rv32& trace_randomized(std::string fname, std::uint_fast64_t ncycles) {
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle_randomized();
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
}
return *this;
}
#endif
#ifdef SIM_FUZZER
void clear_snapshots() {
snapshot_history.clear();
}

const std::vector<snapshot_t>& get_snapshots() const {
return snapshot_history;
}

_flatten module_rv32& run_fuzz(std::uint_fast64_t ncycles, bool abort_on_failure) {
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();

snapshot_history.push_back(snapshot());
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
if (!cuttlesim::fuzz::check_pred(*this, assert_pred_final, abort_on_failure)) { 
return *this;
}
return *this;
}

_flatten module_rv32& run_trace_until_fail(std::string fname, std::uint_fast64_t ncycles, bool abort_on_failure) {
clear_snapshots();
std::ofstream vcd(fname);
state_t::vcd_header(vcd);
state_t latest = Log.snapshot();
latest.vcd_dumpvars(meta.cycle_id, vcd, latest, true);
for (std::uint_fast64_t cycle_id = 0;
                cycle_id < ncycles && !meta.finished;
                cycle_id++) {
cycle();
snapshot_history.push_back(snapshot());
state_t current = Log.snapshot();
current.vcd_dumpvars(meta.cycle_id, vcd, latest, false);
latest = current;
if (!cuttlesim::fuzz::check_pred(*this, assert_pred, abort_on_failure)) { 
return *this;
}
}
return *this;
}
void set_assert_pred(assert_pred_t p) {
assert_pred = p;
}

void clear_assert_pred() {
assert_pred = nullptr;
}

void set_assert_pred_final(assert_pred_t p) {
assert_pred_final = p;
}

void clear_assert_pred_final() {
assert_pred_final = nullptr;
}

void set_assert_pred__rule(assert_pred_rule_t p) {
assert_pred__rule = p;
}

void clear_assert_pred__rule() {
assert_pred__rule = nullptr;
}

#endif
};
}
#endif
