#pragma once // as included by both Vers. A and Vers. B
//////////////
// PREAMBLE //
//////////////

#define NEEDS_BOOST_MULTIPRECISION

#include "cuttlesim.hpp"
#include <cstdlib>

//////////////
// TYPEDEFS //
//////////////

enum class enum_hostID : bits_t<8>{
    FPGA = 8'10000000_bv,
    Verilator = 8'00000001_bv,
    Cuttlesim = 8'00000000_bv};
enum class enum_immType : bits_t<3>{
    ImmI = 3'000_bv,
    ImmS = 3'001_bv,
    ImmB = 3'010_bv,
    ImmU = 3'011_bv,
    ImmJ = 3'100_bv};

struct struct_control_result
{
   bits<32> nextPC;
   bits<1> taken;
};

struct struct_maybe_immType
{
   bits<1> valid;
   enum_immType data;
};

struct struct_decodedInst
{
   bits<1> valid_rs1;
   bits<1> valid_rs2;
   bits<1> valid_rd;
   bits<1> legal;
   bits<32> inst;
   struct_maybe_immType immediateType;
};

struct struct_decode_bookkeeping
{
   bits<32> pc;
   bits<32> ppc;
   bits<1> epoch;
   struct_decodedInst dInst;
   bits<32> rval1;
   bits<32> rval2;
};

struct struct_execute_bookkeeping
{
   bits<1> isUnsigned;
   bits<2> size;
   bits<2> offset;
   bits<32> newrd;
   struct_decodedInst dInst;
};

struct struct_fetch_bookkeeping
{
   bits<32> pc;
   bits<32> ppc;
   bits<1> epoch;
};

struct struct_instFields
{
   bits<7> opcode;
   bits<3> funct3;
   bits<7> funct7;
   bits<5> funct5;
   bits<2> funct2;
   bits<5> rd;
   bits<5> rs1;
   bits<5> rs2;
   bits<5> rs3;
   bits<32> immI;
   bits<32> immS;
   bits<32> immB;
   bits<32> immU;
   bits<32> immJ;
   bits<12> csr;
};

struct struct_maybe_bits_1
{
   bits<1> valid;
   bits<1> data;
};

struct struct_maybe_bits_8
{
   bits<1> valid;
   bits<8> data;
};

struct struct_mem_req
{
   bits<4> byte_en;
   bits<32> addr;
   bits<32> data;
};

struct struct_maybe_mem_req
{
   bits<1> valid;
   struct_mem_req data;
};

struct struct_mem_input
{
   bits<1> get_ready;
   bits<1> put_valid;
   struct_mem_req put_request;
};

struct struct_mem_resp
{
   bits<4> byte_en;
   bits<32> addr;
   bits<32> data;
};

struct struct_mem_output
{
   bits<1> get_valid;
   bits<1> put_ready;
   struct_mem_resp get_response;
};

static _unused bits<1> operator==(const enum_hostID v1, const enum_hostID v2)
{
   return bits<8>::mk(v1) == bits<8>::mk(v2);
}
static _unused bits<1> operator!=(const enum_hostID v1, const enum_hostID v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const enum_hostID &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const enum_immType v1, const enum_immType v2)
{
   return bits<3>::mk(v1) == bits<3>::mk(v2);
}
static _unused bits<1> operator!=(const enum_immType v1, const enum_immType v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const enum_immType &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_control_result v1, const struct_control_result v2)
{
   return bits<1>::mk(bool(v1.nextPC == v2.nextPC) && bool(v1.taken == v2.taken));
}
static _unused bits<1> operator!=(const struct_control_result v1, const struct_control_result v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_control_result &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_maybe_immType v1, const struct_maybe_immType v2)
{
   return bits<1>::mk(bool(v1.valid == v2.valid) && bool(v1.data == v2.data));
}
static _unused bits<1> operator!=(const struct_maybe_immType v1, const struct_maybe_immType v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_maybe_immType &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_decodedInst v1, const struct_decodedInst v2)
{
   return bits<1>::mk(bool(v1.valid_rs1 == v2.valid_rs1) && bool(v1.valid_rs2 == v2.valid_rs2) && bool(v1.valid_rd == v2.valid_rd) && bool(v1.legal == v2.legal) && bool(v1.inst == v2.inst) && bool(v1.immediateType == v2.immediateType));
}
static _unused bits<1> operator!=(const struct_decodedInst v1, const struct_decodedInst v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_decodedInst &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_decode_bookkeeping v1, const struct_decode_bookkeeping v2)
{
   return bits<1>::mk(bool(v1.pc == v2.pc) && bool(v1.ppc == v2.ppc) && bool(v1.epoch == v2.epoch) && bool(v1.dInst == v2.dInst) && bool(v1.rval1 == v2.rval1) && bool(v1.rval2 == v2.rval2));
}
static _unused bits<1> operator!=(const struct_decode_bookkeeping v1, const struct_decode_bookkeeping v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_decode_bookkeeping &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_execute_bookkeeping v1, const struct_execute_bookkeeping v2)
{
   return bits<1>::mk(bool(v1.isUnsigned == v2.isUnsigned) && bool(v1.size == v2.size) && bool(v1.offset == v2.offset) && bool(v1.newrd == v2.newrd) && bool(v1.dInst == v2.dInst));
}
static _unused bits<1> operator!=(const struct_execute_bookkeeping v1, const struct_execute_bookkeeping v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_execute_bookkeeping &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_fetch_bookkeeping v1, const struct_fetch_bookkeeping v2)
{
   return bits<1>::mk(bool(v1.pc == v2.pc) && bool(v1.ppc == v2.ppc) && bool(v1.epoch == v2.epoch));
}
static _unused bits<1> operator!=(const struct_fetch_bookkeeping v1, const struct_fetch_bookkeeping v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_fetch_bookkeeping &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_instFields v1, const struct_instFields v2)
{
   return bits<1>::mk(bool(v1.opcode == v2.opcode) && bool(v1.funct3 == v2.funct3) && bool(v1.funct7 == v2.funct7) && bool(v1.funct5 == v2.funct5) && bool(v1.funct2 == v2.funct2) && bool(v1.rd == v2.rd) && bool(v1.rs1 == v2.rs1) && bool(v1.rs2 == v2.rs2) && bool(v1.rs3 == v2.rs3) && bool(v1.immI == v2.immI) && bool(v1.immS == v2.immS) && bool(v1.immB == v2.immB) && bool(v1.immU == v2.immU) && bool(v1.immJ == v2.immJ) && bool(v1.csr == v2.csr));
}
static _unused bits<1> operator!=(const struct_instFields v1, const struct_instFields v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_instFields &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_maybe_bits_1 v1, const struct_maybe_bits_1 v2)
{
   return bits<1>::mk(bool(v1.valid == v2.valid) && bool(v1.data == v2.data));
}
static _unused bits<1> operator!=(const struct_maybe_bits_1 v1, const struct_maybe_bits_1 v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_maybe_bits_1 &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_maybe_bits_8 v1, const struct_maybe_bits_8 v2)
{
   return bits<1>::mk(bool(v1.valid == v2.valid) && bool(v1.data == v2.data));
}
static _unused bits<1> operator!=(const struct_maybe_bits_8 v1, const struct_maybe_bits_8 v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_maybe_bits_8 &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_mem_req v1, const struct_mem_req v2)
{
   return bits<1>::mk(bool(v1.byte_en == v2.byte_en) && bool(v1.addr == v2.addr) && bool(v1.data == v2.data));
}
static _unused bits<1> operator!=(const struct_mem_req v1, const struct_mem_req v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_mem_req &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_maybe_mem_req v1, const struct_maybe_mem_req v2)
{
   return bits<1>::mk(bool(v1.valid == v2.valid) && bool(v1.data == v2.data));
}
static _unused bits<1> operator!=(const struct_maybe_mem_req v1, const struct_maybe_mem_req v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_maybe_mem_req &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_mem_input v1, const struct_mem_input v2)
{
   return bits<1>::mk(bool(v1.get_ready == v2.get_ready) && bool(v1.put_valid == v2.put_valid) && bool(v1.put_request == v2.put_request));
}
static _unused bits<1> operator!=(const struct_mem_input v1, const struct_mem_input v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_mem_input &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_mem_resp v1, const struct_mem_resp v2)
{
   return bits<1>::mk(bool(v1.byte_en == v2.byte_en) && bool(v1.addr == v2.addr) && bool(v1.data == v2.data));
}
static _unused bits<1> operator!=(const struct_mem_resp v1, const struct_mem_resp v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_mem_resp &val)
{
   return prims::fmt(os, val);
}
#endif

static _unused bits<1> operator==(const struct_mem_output v1, const struct_mem_output v2)
{
   return bits<1>::mk(bool(v1.get_valid == v2.get_valid) && bool(v1.put_ready == v2.put_ready) && bool(v1.get_response == v2.get_response));
}
static _unused bits<1> operator!=(const struct_mem_output v1, const struct_mem_output v2)
{
   return !(v1 == v2);
}

#ifndef SIM_MINIMAL
static _unused std::ostream &operator<<(std::ostream &os, const struct_mem_output &val)
{
   return prims::fmt(os, val);
}
#endif

namespace prims
{
#ifndef SIM_MINIMAL
   static _unused std::ostream &fmt(std::ostream &os, const enum_hostID &val, const fmtopts opts)
   {
      switch (val)
      {
      case enum_hostID::FPGA:
         os << "hostID::FPGA";
         break;
      case enum_hostID::Verilator:
         os << "hostID::Verilator";
         break;
      case enum_hostID::Cuttlesim:
         os << "hostID::Cuttlesim";
         break;
      default:
         os << "hostID{";
         fmt(os, bits<8>::mk(val), opts) << "}";
      }
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const enum_immType &val, const fmtopts opts)
   {
      switch (val)
      {
      case enum_immType::ImmI:
         os << "immType::ImmI";
         break;
      case enum_immType::ImmS:
         os << "immType::ImmS";
         break;
      case enum_immType::ImmB:
         os << "immType::ImmB";
         break;
      case enum_immType::ImmU:
         os << "immType::ImmU";
         break;
      case enum_immType::ImmJ:
         os << "immType::ImmJ";
         break;
      default:
         os << "immType{";
         fmt(os, bits<3>::mk(val), opts) << "}";
      }
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_control_result &val, const fmtopts opts)
   {
      os << "control_result { ";
      os << ".nextPC = ";
      fmt(os, val.nextPC, opts) << "; ";
      os << ".taken = ";
      fmt(os, val.taken, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_maybe_immType &val, const fmtopts opts)
   {
      os << "maybe_immType { ";
      os << ".valid = ";
      fmt(os, val.valid, opts) << "; ";
      os << ".data = ";
      fmt(os, val.data, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_decodedInst &val, const fmtopts opts)
   {
      os << "decodedInst { ";
      os << ".valid_rs1 = ";
      fmt(os, val.valid_rs1, opts) << "; ";
      os << ".valid_rs2 = ";
      fmt(os, val.valid_rs2, opts) << "; ";
      os << ".valid_rd = ";
      fmt(os, val.valid_rd, opts) << "; ";
      os << ".legal = ";
      fmt(os, val.legal, opts) << "; ";
      os << ".inst = ";
      fmt(os, val.inst, opts) << "; ";
      os << ".immediateType = ";
      fmt(os, val.immediateType, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_decode_bookkeeping &val, const fmtopts opts)
   {
      os << "decode_bookkeeping { ";
      os << ".pc = ";
      fmt(os, val.pc, opts) << "; ";
      os << ".ppc = ";
      fmt(os, val.ppc, opts) << "; ";
      os << ".epoch = ";
      fmt(os, val.epoch, opts) << "; ";
      os << ".dInst = ";
      fmt(os, val.dInst, opts) << "; ";
      os << ".rval1 = ";
      fmt(os, val.rval1, opts) << "; ";
      os << ".rval2 = ";
      fmt(os, val.rval2, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_execute_bookkeeping &val, const fmtopts opts)
   {
      os << "execute_bookkeeping { ";
      os << ".isUnsigned = ";
      fmt(os, val.isUnsigned, opts) << "; ";
      os << ".size = ";
      fmt(os, val.size, opts) << "; ";
      os << ".offset = ";
      fmt(os, val.offset, opts) << "; ";
      os << ".newrd = ";
      fmt(os, val.newrd, opts) << "; ";
      os << ".dInst = ";
      fmt(os, val.dInst, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_fetch_bookkeeping &val, const fmtopts opts)
   {
      os << "fetch_bookkeeping { ";
      os << ".pc = ";
      fmt(os, val.pc, opts) << "; ";
      os << ".ppc = ";
      fmt(os, val.ppc, opts) << "; ";
      os << ".epoch = ";
      fmt(os, val.epoch, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_instFields &val, const fmtopts opts)
   {
      os << "instFields { ";
      os << ".opcode = ";
      fmt(os, val.opcode, opts) << "; ";
      os << ".funct3 = ";
      fmt(os, val.funct3, opts) << "; ";
      os << ".funct7 = ";
      fmt(os, val.funct7, opts) << "; ";
      os << ".funct5 = ";
      fmt(os, val.funct5, opts) << "; ";
      os << ".funct2 = ";
      fmt(os, val.funct2, opts) << "; ";
      os << ".rd = ";
      fmt(os, val.rd, opts) << "; ";
      os << ".rs1 = ";
      fmt(os, val.rs1, opts) << "; ";
      os << ".rs2 = ";
      fmt(os, val.rs2, opts) << "; ";
      os << ".rs3 = ";
      fmt(os, val.rs3, opts) << "; ";
      os << ".immI = ";
      fmt(os, val.immI, opts) << "; ";
      os << ".immS = ";
      fmt(os, val.immS, opts) << "; ";
      os << ".immB = ";
      fmt(os, val.immB, opts) << "; ";
      os << ".immU = ";
      fmt(os, val.immU, opts) << "; ";
      os << ".immJ = ";
      fmt(os, val.immJ, opts) << "; ";
      os << ".csr = ";
      fmt(os, val.csr, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_maybe_bits_1 &val, const fmtopts opts)
   {
      os << "maybe_bits_1 { ";
      os << ".valid = ";
      fmt(os, val.valid, opts) << "; ";
      os << ".data = ";
      fmt(os, val.data, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_maybe_bits_8 &val, const fmtopts opts)
   {
      os << "maybe_bits_8 { ";
      os << ".valid = ";
      fmt(os, val.valid, opts) << "; ";
      os << ".data = ";
      fmt(os, val.data, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_mem_req &val, const fmtopts opts)
   {
      os << "mem_req { ";
      os << ".byte_en = ";
      fmt(os, val.byte_en, opts) << "; ";
      os << ".addr = ";
      fmt(os, val.addr, opts) << "; ";
      os << ".data = ";
      fmt(os, val.data, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_maybe_mem_req &val, const fmtopts opts)
   {
      os << "maybe_mem_req { ";
      os << ".valid = ";
      fmt(os, val.valid, opts) << "; ";
      os << ".data = ";
      fmt(os, val.data, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_mem_input &val, const fmtopts opts)
   {
      os << "mem_input { ";
      os << ".get_ready = ";
      fmt(os, val.get_ready, opts) << "; ";
      os << ".put_valid = ";
      fmt(os, val.put_valid, opts) << "; ";
      os << ".put_request = ";
      fmt(os, val.put_request, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_mem_resp &val, const fmtopts opts)
   {
      os << "mem_resp { ";
      os << ".byte_en = ";
      fmt(os, val.byte_en, opts) << "; ";
      os << ".addr = ";
      fmt(os, val.addr, opts) << "; ";
      os << ".data = ";
      fmt(os, val.data, opts) << "; ";
      os << "}";
      return os;
   }

   static _unused std::ostream &fmt(std::ostream &os, const struct_mem_output &val, const fmtopts opts)
   {
      os << "mem_output { ";
      os << ".get_valid = ";
      fmt(os, val.get_valid, opts) << "; ";
      os << ".put_ready = ";
      fmt(os, val.put_ready, opts) << "; ";
      os << ".get_response = ";
      fmt(os, val.get_response, opts) << "; ";
      os << "}";
      return os;
   }
#endif

   template <>
   struct type_info<enum_hostID>
   {
      static constexpr prims::bitwidth size = 8;
   };

   template <>
   _unused bits<8> pack<>(const enum_hostID val)
   {
      return bits<8>::mk(val);
   }

   template <>
   struct _unpack<enum_hostID, 8>
   {
      static enum_hostID unpack(const bits<8> bs)
      {
         return static_cast<enum_hostID>(bs.v);
      }
   };

   template <>
   struct type_info<enum_immType>
   {
      static constexpr prims::bitwidth size = 3;
   };

   template <>
   _unused bits<3> pack<>(const enum_immType val)
   {
      return bits<3>::mk(val);
   }

   template <>
   struct _unpack<enum_immType, 3>
   {
      static enum_immType unpack(const bits<3> bs)
      {
         return static_cast<enum_immType>(bs.v);
      }
   };

   template <>
   struct type_info<struct_control_result>
   {
      static constexpr prims::bitwidth size = 33;
   };

   template <>
   _unused bits<33> pack<>(const struct_control_result val)
   {
      bits<33> packed = 33'0_b;
      packed |= prims::widen<33>(val.nextPC);
      packed <<= 1;
      packed |= prims::widen<33>(val.taken);
      return packed;
   }

   template <>
   struct _unpack<struct_control_result, 33>
   {
      static struct_control_result unpack(const bits<33> bs)
      {
         struct_control_result unpacked = {};
         unpacked.taken = prims::truncate<1>(bs >> 0u);
         unpacked.nextPC = prims::truncate<32>(bs >> 1u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_maybe_immType>
   {
      static constexpr prims::bitwidth size = 4;
   };

   template <>
   _unused bits<4> pack<>(const struct_maybe_immType val)
   {
      bits<4> packed = 4'0000_b;
      packed |= prims::widen<4>(val.valid);
      packed <<= 3;
      packed |= prims::widen<4>(prims::pack(val.data));
      return packed;
   }

   template <>
   struct _unpack<struct_maybe_immType, 4>
   {
      static struct_maybe_immType unpack(const bits<4> bs)
      {
         struct_maybe_immType unpacked = {};
         unpacked.data = prims::unpack<enum_immType>(prims::truncate<3>(bs >> 0u));
         unpacked.valid = prims::truncate<1>(bs >> 3u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_decodedInst>
   {
      static constexpr prims::bitwidth size = 40;
   };

   template <>
   _unused bits<40> pack<>(const struct_decodedInst val)
   {
      bits<40> packed = 40'0_b;
      packed |= prims::widen<40>(val.valid_rs1);
      packed <<= 1;
      packed |= prims::widen<40>(val.valid_rs2);
      packed <<= 1;
      packed |= prims::widen<40>(val.valid_rd);
      packed <<= 1;
      packed |= prims::widen<40>(val.legal);
      packed <<= 32;
      packed |= prims::widen<40>(val.inst);
      packed <<= 4;
      packed |= prims::widen<40>(prims::pack(val.immediateType));
      return packed;
   }

   template <>
   struct _unpack<struct_decodedInst, 40>
   {
      static struct_decodedInst unpack(const bits<40> bs)
      {
         struct_decodedInst unpacked = {};
         unpacked.immediateType = prims::unpack<struct_maybe_immType>(prims::truncate<4>(bs >> 0u));
         unpacked.inst = prims::truncate<32>(bs >> 4u);
         unpacked.legal = prims::truncate<1>(bs >> 36u);
         unpacked.valid_rd = prims::truncate<1>(bs >> 37u);
         unpacked.valid_rs2 = prims::truncate<1>(bs >> 38u);
         unpacked.valid_rs1 = prims::truncate<1>(bs >> 39u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_decode_bookkeeping>
   {
      static constexpr prims::bitwidth size = 169;
   };

   template <>
   _unused bits<169> pack<>(const struct_decode_bookkeeping val)
   {
      bits<169> packed = 0x169'0_x;
      packed |= prims::widen<169>(val.pc);
      packed <<= 32;
      packed |= prims::widen<169>(val.ppc);
      packed <<= 1;
      packed |= prims::widen<169>(val.epoch);
      packed <<= 40;
      packed |= prims::widen<169>(prims::pack(val.dInst));
      packed <<= 32;
      packed |= prims::widen<169>(val.rval1);
      packed <<= 32;
      packed |= prims::widen<169>(val.rval2);
      return packed;
   }

   template <>
   struct _unpack<struct_decode_bookkeeping, 169>
   {
      static struct_decode_bookkeeping unpack(const bits<169> bs)
      {
         struct_decode_bookkeeping unpacked = {};
         unpacked.rval2 = prims::truncate<32>(bs >> 0u);
         unpacked.rval1 = prims::truncate<32>(bs >> 32u);
         unpacked.dInst = prims::unpack<struct_decodedInst>(prims::truncate<40>(bs >> 64u));
         unpacked.epoch = prims::truncate<1>(bs >> 104u);
         unpacked.ppc = prims::truncate<32>(bs >> 105u);
         unpacked.pc = prims::truncate<32>(bs >> 137u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_execute_bookkeeping>
   {
      static constexpr prims::bitwidth size = 77;
   };

   template <>
   _unused bits<77> pack<>(const struct_execute_bookkeeping val)
   {
      bits<77> packed = 0x77'0_x;
      packed |= prims::widen<77>(val.isUnsigned);
      packed <<= 2;
      packed |= prims::widen<77>(val.size);
      packed <<= 2;
      packed |= prims::widen<77>(val.offset);
      packed <<= 32;
      packed |= prims::widen<77>(val.newrd);
      packed <<= 40;
      packed |= prims::widen<77>(prims::pack(val.dInst));
      return packed;
   }

   template <>
   struct _unpack<struct_execute_bookkeeping, 77>
   {
      static struct_execute_bookkeeping unpack(const bits<77> bs)
      {
         struct_execute_bookkeeping unpacked = {};
         unpacked.dInst = prims::unpack<struct_decodedInst>(prims::truncate<40>(bs >> 0u));
         unpacked.newrd = prims::truncate<32>(bs >> 40u);
         unpacked.offset = prims::truncate<2>(bs >> 72u);
         unpacked.size = prims::truncate<2>(bs >> 74u);
         unpacked.isUnsigned = prims::truncate<1>(bs >> 76u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_fetch_bookkeeping>
   {
      static constexpr prims::bitwidth size = 65;
   };

   template <>
   _unused bits<65> pack<>(const struct_fetch_bookkeeping val)
   {
      bits<65> packed = 0x65'0_x;
      packed |= prims::widen<65>(val.pc);
      packed <<= 32;
      packed |= prims::widen<65>(val.ppc);
      packed <<= 1;
      packed |= prims::widen<65>(val.epoch);
      return packed;
   }

   template <>
   struct _unpack<struct_fetch_bookkeeping, 65>
   {
      static struct_fetch_bookkeeping unpack(const bits<65> bs)
      {
         struct_fetch_bookkeeping unpacked = {};
         unpacked.epoch = prims::truncate<1>(bs >> 0u);
         unpacked.ppc = prims::truncate<32>(bs >> 1u);
         unpacked.pc = prims::truncate<32>(bs >> 33u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_instFields>
   {
      static constexpr prims::bitwidth size = 216;
   };

   template <>
   _unused bits<216> pack<>(const struct_instFields val)
   {
      bits<216> packed = 0x216'0_x;
      packed |= prims::widen<216>(val.opcode);
      packed <<= 3;
      packed |= prims::widen<216>(val.funct3);
      packed <<= 7;
      packed |= prims::widen<216>(val.funct7);
      packed <<= 5;
      packed |= prims::widen<216>(val.funct5);
      packed <<= 2;
      packed |= prims::widen<216>(val.funct2);
      packed <<= 5;
      packed |= prims::widen<216>(val.rd);
      packed <<= 5;
      packed |= prims::widen<216>(val.rs1);
      packed <<= 5;
      packed |= prims::widen<216>(val.rs2);
      packed <<= 5;
      packed |= prims::widen<216>(val.rs3);
      packed <<= 32;
      packed |= prims::widen<216>(val.immI);
      packed <<= 32;
      packed |= prims::widen<216>(val.immS);
      packed <<= 32;
      packed |= prims::widen<216>(val.immB);
      packed <<= 32;
      packed |= prims::widen<216>(val.immU);
      packed <<= 32;
      packed |= prims::widen<216>(val.immJ);
      packed <<= 12;
      packed |= prims::widen<216>(val.csr);
      return packed;
   }

   template <>
   struct _unpack<struct_instFields, 216>
   {
      static struct_instFields unpack(const bits<216> bs)
      {
         struct_instFields unpacked = {};
         unpacked.csr = prims::truncate<12>(bs >> 0u);
         unpacked.immJ = prims::truncate<32>(bs >> 12u);
         unpacked.immU = prims::truncate<32>(bs >> 44u);
         unpacked.immB = prims::truncate<32>(bs >> 76u);
         unpacked.immS = prims::truncate<32>(bs >> 108u);
         unpacked.immI = prims::truncate<32>(bs >> 140u);
         unpacked.rs3 = prims::truncate<5>(bs >> 172u);
         unpacked.rs2 = prims::truncate<5>(bs >> 177u);
         unpacked.rs1 = prims::truncate<5>(bs >> 182u);
         unpacked.rd = prims::truncate<5>(bs >> 187u);
         unpacked.funct2 = prims::truncate<2>(bs >> 192u);
         unpacked.funct5 = prims::truncate<5>(bs >> 194u);
         unpacked.funct7 = prims::truncate<7>(bs >> 199u);
         unpacked.funct3 = prims::truncate<3>(bs >> 206u);
         unpacked.opcode = prims::truncate<7>(bs >> 209u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_maybe_bits_1>
   {
      static constexpr prims::bitwidth size = 2;
   };

   template <>
   _unused bits<2> pack<>(const struct_maybe_bits_1 val)
   {
      bits<2> packed = 2'00_b;
      packed |= prims::widen<2>(val.valid);
      packed <<= 1;
      packed |= prims::widen<2>(val.data);
      return packed;
   }

   template <>
   struct _unpack<struct_maybe_bits_1, 2>
   {
      static struct_maybe_bits_1 unpack(const bits<2> bs)
      {
         struct_maybe_bits_1 unpacked = {};
         unpacked.data = prims::truncate<1>(bs >> 0u);
         unpacked.valid = prims::truncate<1>(bs >> 1u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_maybe_bits_8>
   {
      static constexpr prims::bitwidth size = 9;
   };

   template <>
   _unused bits<9> pack<>(const struct_maybe_bits_8 val)
   {
      bits<9> packed = 9'0_b;
      packed |= prims::widen<9>(val.valid);
      packed <<= 8;
      packed |= prims::widen<9>(val.data);
      return packed;
   }

   template <>
   struct _unpack<struct_maybe_bits_8, 9>
   {
      static struct_maybe_bits_8 unpack(const bits<9> bs)
      {
         struct_maybe_bits_8 unpacked = {};
         unpacked.data = prims::truncate<8>(bs >> 0u);
         unpacked.valid = prims::truncate<1>(bs >> 8u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_mem_req>
   {
      static constexpr prims::bitwidth size = 68;
   };

   template <>
   _unused bits<68> pack<>(const struct_mem_req val)
   {
      bits<68> packed = 0x68'0_x;
      packed |= prims::widen<68>(val.byte_en);
      packed <<= 32;
      packed |= prims::widen<68>(val.addr);
      packed <<= 32;
      packed |= prims::widen<68>(val.data);
      return packed;
   }

   template <>
   struct _unpack<struct_mem_req, 68>
   {
      static struct_mem_req unpack(const bits<68> bs)
      {
         struct_mem_req unpacked = {};
         unpacked.data = prims::truncate<32>(bs >> 0u);
         unpacked.addr = prims::truncate<32>(bs >> 32u);
         unpacked.byte_en = prims::truncate<4>(bs >> 64u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_maybe_mem_req>
   {
      static constexpr prims::bitwidth size = 69;
   };

   template <>
   _unused bits<69> pack<>(const struct_maybe_mem_req val)
   {
      bits<69> packed = 0x69'0_x;
      packed |= prims::widen<69>(val.valid);
      packed <<= 68;
      packed |= prims::widen<69>(prims::pack(val.data));
      return packed;
   }

   template <>
   struct _unpack<struct_maybe_mem_req, 69>
   {
      static struct_maybe_mem_req unpack(const bits<69> bs)
      {
         struct_maybe_mem_req unpacked = {};
         unpacked.data = prims::unpack<struct_mem_req>(prims::truncate<68>(bs >> 0u));
         unpacked.valid = prims::truncate<1>(bs >> 68u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_mem_input>
   {
      static constexpr prims::bitwidth size = 70;
   };

   template <>
   _unused bits<70> pack<>(const struct_mem_input val)
   {
      bits<70> packed = 0x70'0_x;
      packed |= prims::widen<70>(val.get_ready);
      packed <<= 1;
      packed |= prims::widen<70>(val.put_valid);
      packed <<= 68;
      packed |= prims::widen<70>(prims::pack(val.put_request));
      return packed;
   }

   template <>
   struct _unpack<struct_mem_input, 70>
   {
      static struct_mem_input unpack(const bits<70> bs)
      {
         struct_mem_input unpacked = {};
         unpacked.put_request = prims::unpack<struct_mem_req>(prims::truncate<68>(bs >> 0u));
         unpacked.put_valid = prims::truncate<1>(bs >> 68u);
         unpacked.get_ready = prims::truncate<1>(bs >> 69u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_mem_resp>
   {
      static constexpr prims::bitwidth size = 68;
   };

   template <>
   _unused bits<68> pack<>(const struct_mem_resp val)
   {
      bits<68> packed = 0x68'0_x;
      packed |= prims::widen<68>(val.byte_en);
      packed <<= 32;
      packed |= prims::widen<68>(val.addr);
      packed <<= 32;
      packed |= prims::widen<68>(val.data);
      return packed;
   }

   template <>
   struct _unpack<struct_mem_resp, 68>
   {
      static struct_mem_resp unpack(const bits<68> bs)
      {
         struct_mem_resp unpacked = {};
         unpacked.data = prims::truncate<32>(bs >> 0u);
         unpacked.addr = prims::truncate<32>(bs >> 32u);
         unpacked.byte_en = prims::truncate<4>(bs >> 64u);
         return unpacked;
      }
   };

   template <>
   struct type_info<struct_mem_output>
   {
      static constexpr prims::bitwidth size = 70;
   };

   template <>
   _unused bits<70> pack<>(const struct_mem_output val)
   {
      bits<70> packed = 0x70'0_x;
      packed |= prims::widen<70>(val.get_valid);
      packed <<= 1;
      packed |= prims::widen<70>(val.put_ready);
      packed <<= 68;
      packed |= prims::widen<70>(prims::pack(val.get_response));
      return packed;
   }

   template <>
   struct _unpack<struct_mem_output, 70>
   {
      static struct_mem_output unpack(const bits<70> bs)
      {
         struct_mem_output unpacked = {};
         unpacked.get_response = prims::unpack<struct_mem_resp>(prims::truncate<68>(bs >> 0u));
         unpacked.put_ready = prims::truncate<1>(bs >> 68u);
         unpacked.get_valid = prims::truncate<1>(bs >> 69u);
         return unpacked;
      }
   };
}
