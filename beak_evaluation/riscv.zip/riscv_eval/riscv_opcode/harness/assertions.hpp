#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {

  const auto& h = sim.get_snapshots();
  const auto& curr = h[h.size() - 1];

  const bool valid = static_cast<bool>(curr.state.d2e_valid0);
  const bool legal = static_cast<bool>(curr.state.d2e_data0.dInst.legal);

  return !valid || legal;
}


template <typename sim_t>
inline bool assert_final(const sim_t& sim) {

  return true;
}

#endif