// CPP Output Info:
//  - Module name: rv32
//  - Ext functions: 7
/* struct_mem_output ext_mem_dmem; */
//    - ext_mem_dmem : struct mem_input { get_ready: bits 1; put_valid: bits 1; put_request: struct mem_req { byte_en: bits 4; addr: bits 32; data: bits 32 } } -> struct mem_output { get_valid: bits 1; put_ready: bits 1; get_response: struct mem_resp { byte_en: bits 4; addr: bits 32; data: bits 32 } }
/* enum_hostID ext_host_id; */
//    - ext_host_id : bits 1 -> enum hostID
/* bits<1> ext_uart_write; */
//    - ext_uart_write : struct maybe_bits_8 { valid: bits 1; data: bits 8 } -> bits 1
/* struct_maybe_bits_8 ext_uart_read; */
//    - ext_uart_read : bits 1 -> struct maybe_bits_8 { valid: bits 1; data: bits 8 }
/* bits<1> ext_finish; */
//    - ext_finish : struct maybe_bits_8 { valid: bits 1; data: bits 8 } -> bits 1
/* struct_mem_output ext_mem_imem; */
//    - ext_mem_imem : struct mem_input { get_ready: bits 1; put_valid: bits 1; put_request: struct mem_req { byte_en: bits 4; addr: bits 32; data: bits 32 } } -> struct mem_output { get_valid: bits 1; put_ready: bits 1; get_response: struct mem_resp { byte_en: bits 4; addr: bits 32; data: bits 32 } }
/* bits<1> ext_led; */
//    - ext_led : struct maybe_bits_1 { valid: bits 1; data: bits 1 } -> bits 1
//  - Register toIMem_data0 : struct mem_req { byte_en: bits 4; addr: bits 32; data: bits 32 }
//  - Register toIMem_valid0 : bits 1
//  - Register fromIMem_data0 : struct mem_resp { byte_en: bits 4; addr: bits 32; data: bits 32 }
//  - Register fromIMem_valid0 : bits 1
//  - Register toDMem_data0 : struct mem_req { byte_en: bits 4; addr: bits 32; data: bits 32 }
//  - Register toDMem_valid0 : bits 1
//  - Register fromDMem_data0 : struct mem_resp { byte_en: bits 4; addr: bits 32; data: bits 32 }
//  - Register fromDMem_valid0 : bits 1
//  - Register f2d_data0 : struct fetch_bookkeeping { pc: bits 32; ppc: bits 32; epoch: bits 1 }
//  - Register f2d_valid0 : bits 1
//  - Register f2dprim_data0 : struct fetch_bookkeeping { pc: bits 32; ppc: bits 32; epoch: bits 1 }
//  - Register f2dprim_valid0 : bits 1
//  - Register d2e_data0 : struct decode_bookkeeping { pc: bits 32; ppc: bits 32; epoch: bits 1; dInst: struct decodedInst { valid_rs1: bits 1; valid_rs2: bits 1; valid_rd: bits 1; legal: bits 1; inst: bits 32; immediateType: struct maybe_immType { valid: bits 1; data: enum immType } }; rval1: bits 32; rval2: bits 32 }
//  - Register d2e_valid0 : bits 1
//  - Register e2w_data0 : struct execute_bookkeeping { isUnsigned: bits 1; size: bits 2; offset: bits 2; newrd: bits 32; dInst: struct decodedInst { valid_rs1: bits 1; valid_rs2: bits 1; valid_rd: bits 1; legal: bits 1; inst: bits 32; immediateType: struct maybe_immType { valid: bits 1; data: enum immType } } }
//  - Register e2w_valid0 : bits 1
//  - Register rf_x00_zero : bits 32
//  - Register rf_x01_ra : bits 32
//  - Register rf_x02_sp : bits 32
//  - Register rf_x03_gp : bits 32
//  - Register rf_x04_tp : bits 32
//  - Register rf_x05_t0 : bits 32
//  - Register rf_x06_t1 : bits 32
//  - Register rf_x07_t2 : bits 32
//  - Register rf_x08_s0_fp : bits 32
//  - Register rf_x09_s1 : bits 32
//  - Register rf_x10_a0 : bits 32
//  - Register rf_x11_a1 : bits 32
//  - Register rf_x12_a2 : bits 32
//  - Register rf_x13_a3 : bits 32
//  - Register rf_x14_a4 : bits 32
//  - Register rf_x15_a5 : bits 32
//  - Register rf_x16_a6 : bits 32
//  - Register rf_x17_a7 : bits 32
//  - Register rf_x18_s2 : bits 32
//  - Register rf_x19_s3 : bits 32
//  - Register rf_x20_s4 : bits 32
//  - Register rf_x21_s5 : bits 32
//  - Register rf_x22_s6 : bits 32
//  - Register rf_x23_s7 : bits 32
//  - Register rf_x24_s8 : bits 32
//  - Register rf_x25_s9 : bits 32
//  - Register rf_x26_s10 : bits 32
//  - Register rf_x27_s11 : bits 32
//  - Register rf_x28_t3 : bits 32
//  - Register rf_x29_t4 : bits 32
//  - Register rf_x30_t5 : bits 32
//  - Register rf_x31_t6 : bits 32
//  - Register mulState_valid : bits 1
//  - Register mulState_operand1 : bits 32
//  - Register mulState_operand2 : bits 32
//  - Register mulState_result : bits 64
//  - Register mulState_n_step : bits 5
//  - Register mulState_finished : bits 1
//  - Register scoreboard_x00_zero : bits 2
//  - Register scoreboard_x01_ra : bits 2
//  - Register scoreboard_x02_sp : bits 2
//  - Register scoreboard_x03_gp : bits 2
//  - Register scoreboard_x04_tp : bits 2
//  - Register scoreboard_x05_t0 : bits 2
//  - Register scoreboard_x06_t1 : bits 2
//  - Register scoreboard_x07_t2 : bits 2
//  - Register scoreboard_x08_s0_fp : bits 2
//  - Register scoreboard_x09_s1 : bits 2
//  - Register scoreboard_x10_a0 : bits 2
//  - Register scoreboard_x11_a1 : bits 2
//  - Register scoreboard_x12_a2 : bits 2
//  - Register scoreboard_x13_a3 : bits 2
//  - Register scoreboard_x14_a4 : bits 2
//  - Register scoreboard_x15_a5 : bits 2
//  - Register scoreboard_x16_a6 : bits 2
//  - Register scoreboard_x17_a7 : bits 2
//  - Register scoreboard_x18_s2 : bits 2
//  - Register scoreboard_x19_s3 : bits 2
//  - Register scoreboard_x20_s4 : bits 2
//  - Register scoreboard_x21_s5 : bits 2
//  - Register scoreboard_x22_s6 : bits 2
//  - Register scoreboard_x23_s7 : bits 2
//  - Register scoreboard_x24_s8 : bits 2
//  - Register scoreboard_x25_s9 : bits 2
//  - Register scoreboard_x26_s10 : bits 2
//  - Register scoreboard_x27_s11 : bits 2
//  - Register scoreboard_x28_t3 : bits 2
//  - Register scoreboard_x29_t4 : bits 2
//  - Register scoreboard_x30_t5 : bits 2
//  - Register scoreboard_x31_t6 : bits 2
//  - Register cycle_count : bits 32
//  - Register instr_count : bits 32
//  - Register pc : bits 32
//  - Register epoch : bits 1


#include <vector>
#include <cstdio>
#include <cstdint>
#include <cassert>
#include <string>
#include <cstring>
#include <cerrno>
#include "rv32.hpp"
#include "harness_support.hpp"
#include "beak_mode.hpp"

// This is a test harness for the module rv32
// It is generated by Koika and is intended to be used with fuzzing tools.
// The harness provides an interface to set assertion predicates and run simulations.

// pred must be callable of type : const(snapshot_t)& -> bool


// run_fuzz : to run the simulation for n cycles with fuzzing support
#define ALL_REGISTERS(X) \
   X(toIMem_data0, 68) \
   X(toIMem_valid0, 1) \
   X(fromIMem_data0, 68) \
   X(fromIMem_valid0, 1) \
   X(toDMem_data0, 68) \
   X(toDMem_valid0, 1) \
   X(fromDMem_data0, 68) \
   X(fromDMem_valid0, 1) \
   X(f2d_data0, 65) \
   X(f2d_valid0, 1) \
   X(f2dprim_data0, 65) \
   X(f2dprim_valid0, 1) \
   X(d2e_data0, 169) \
   X(d2e_valid0, 1) \
   X(e2w_data0, 77) \
   X(e2w_valid0, 1) \
   X(rf_x00_zero, 32) \
   X(rf_x01_ra, 32) \
   X(rf_x02_sp, 32) \
   X(rf_x03_gp, 32) \
   X(rf_x04_tp, 32) \
   X(rf_x05_t0, 32) \
   X(rf_x06_t1, 32) \
   X(rf_x07_t2, 32) \
   X(rf_x08_s0_fp, 32) \
   X(rf_x09_s1, 32) \
   X(rf_x10_a0, 32) \
   X(rf_x11_a1, 32) \
   X(rf_x12_a2, 32) \
   X(rf_x13_a3, 32) \
   X(rf_x14_a4, 32) \
   X(rf_x15_a5, 32) \
   X(rf_x16_a6, 32) \
   X(rf_x17_a7, 32) \
   X(rf_x18_s2, 32) \
   X(rf_x19_s3, 32) \
   X(rf_x20_s4, 32) \
   X(rf_x21_s5, 32) \
   X(rf_x22_s6, 32) \
   X(rf_x23_s7, 32) \
   X(rf_x24_s8, 32) \
   X(rf_x25_s9, 32) \
   X(rf_x26_s10, 32) \
   X(rf_x27_s11, 32) \
   X(rf_x28_t3, 32) \
   X(rf_x29_t4, 32) \
   X(rf_x30_t5, 32) \
   X(rf_x31_t6, 32) \
   X(mulState_valid, 1) \
   X(mulState_operand1, 32) \
   X(mulState_operand2, 32) \
   X(mulState_result, 64) \
   X(mulState_n_step, 5) \
   X(mulState_finished, 1) \
   X(scoreboard_x00_zero, 2) \
   X(scoreboard_x01_ra, 2) \
   X(scoreboard_x02_sp, 2) \
   X(scoreboard_x03_gp, 2) \
   X(scoreboard_x04_tp, 2) \
   X(scoreboard_x05_t0, 2) \
   X(scoreboard_x06_t1, 2) \
   X(scoreboard_x07_t2, 2) \
   X(scoreboard_x08_s0_fp, 2) \
   X(scoreboard_x09_s1, 2) \
   X(scoreboard_x10_a0, 2) \
   X(scoreboard_x11_a1, 2) \
   X(scoreboard_x12_a2, 2) \
   X(scoreboard_x13_a3, 2) \
   X(scoreboard_x14_a4, 2) \
   X(scoreboard_x15_a5, 2) \
   X(scoreboard_x16_a6, 2) \
   X(scoreboard_x17_a7, 2) \
   X(scoreboard_x18_s2, 2) \
   X(scoreboard_x19_s3, 2) \
   X(scoreboard_x20_s4, 2) \
   X(scoreboard_x21_s5, 2) \
   X(scoreboard_x22_s6, 2) \
   X(scoreboard_x23_s7, 2) \
   X(scoreboard_x24_s8, 2) \
   X(scoreboard_x25_s9, 2) \
   X(scoreboard_x26_s10, 2) \
   X(scoreboard_x27_s11, 2) \
   X(scoreboard_x28_t3, 2) \
   X(scoreboard_x29_t4, 2) \
   X(scoreboard_x30_t5, 2) \
   X(scoreboard_x31_t6, 2) \
   X(cycle_count, 32) \
   X(instr_count, 32) \
   X(pc, 32) \
   X(epoch, 1)

#define VAL_REGISTER(X) \
   X(toIMem_data0, 68) \
   X(toIMem_valid0, 1) \
   X(fromIMem_data0, 68) \
   X(fromIMem_valid0, 1) \
   X(toDMem_data0, 68) \
   X(toDMem_valid0, 1) \
   X(fromDMem_data0, 68) \
   X(fromDMem_valid0, 1) \
   X(f2d_data0, 65) \
   X(f2d_valid0, 1) \
   X(f2dprim_data0, 65) \
   X(f2dprim_valid0, 1) \
   X(d2e_data0, 169) \
   X(d2e_valid0, 1) \
   X(e2w_data0, 77) \
   X(e2w_valid0, 1) \
   X(rf_x00_zero, 32) \
   X(rf_x01_ra, 32) \
   X(rf_x02_sp, 32) \
   X(rf_x03_gp, 32) \
   X(rf_x04_tp, 32) \
   X(rf_x05_t0, 32) \
   X(rf_x06_t1, 32) \
   X(rf_x07_t2, 32) \
   X(rf_x08_s0_fp, 32) \
   X(rf_x09_s1, 32) \
   X(rf_x10_a0, 32) \
   X(rf_x11_a1, 32) \
   X(rf_x12_a2, 32) \
   X(rf_x13_a3, 32) \
   X(rf_x14_a4, 32) \
   X(rf_x15_a5, 32) \
   X(rf_x16_a6, 32) \
   X(rf_x17_a7, 32) \
   X(rf_x18_s2, 32) \
   X(rf_x19_s3, 32) \
   X(rf_x20_s4, 32) \
   X(rf_x21_s5, 32) \
   X(rf_x22_s6, 32) \
   X(rf_x23_s7, 32) \
   X(rf_x24_s8, 32) \
   X(rf_x25_s9, 32) \
   X(rf_x26_s10, 32) \
   X(rf_x27_s11, 32) \
   X(rf_x28_t3, 32) \
   X(rf_x29_t4, 32) \
   X(rf_x30_t5, 32) \
   X(rf_x31_t6, 32) \
   X(mulState_valid, 1) \
   X(mulState_result, 64) \
   X(mulState_finished, 1) \
   X(scoreboard_x00_zero, 2) \
   X(scoreboard_x01_ra, 2) \
   X(scoreboard_x02_sp, 2) \
   X(scoreboard_x03_gp, 2) \
   X(scoreboard_x04_tp, 2) \
   X(scoreboard_x05_t0, 2) \
   X(scoreboard_x06_t1, 2) \
   X(scoreboard_x07_t2, 2) \
   X(scoreboard_x08_s0_fp, 2) \
   X(scoreboard_x09_s1, 2) \
   X(scoreboard_x10_a0, 2) \
   X(scoreboard_x11_a1, 2) \
   X(scoreboard_x12_a2, 2) \
   X(scoreboard_x13_a3, 2) \
   X(scoreboard_x14_a4, 2) \
   X(scoreboard_x15_a5, 2) \
   X(scoreboard_x16_a6, 2) \
   X(scoreboard_x17_a7, 2) \
   X(scoreboard_x18_s2, 2) \
   X(scoreboard_x19_s3, 2) \
   X(scoreboard_x20_s4, 2) \
   X(scoreboard_x21_s5, 2) \
   X(scoreboard_x22_s6, 2) \
   X(scoreboard_x23_s7, 2) \
   X(scoreboard_x24_s8, 2) \
   X(scoreboard_x25_s9, 2) \
   X(scoreboard_x26_s10, 2) \
   X(scoreboard_x27_s11, 2) \
   X(scoreboard_x28_t3, 2) \
   X(scoreboard_x29_t4, 2) \
   X(scoreboard_x30_t5, 2) \
   X(scoreboard_x31_t6, 2) \
   X(cycle_count, 32) \
   X(instr_count, 32) \
   X(pc, 32) \
   X(epoch, 1)

#define EXT_INPUTS(X) \
   X(ext_mem_dmem, struct_mem_input,  struct_mem_output) \
   X(ext_uart_write, struct_maybe_bits_8,  bits<1>) \
   X(ext_uart_read, bits<1>,  struct_maybe_bits_8) \
   X(ext_mem_imem, struct_mem_input,  struct_mem_output) \
   X(ext_led, struct_maybe_bits_1, bits<1>)

#define EXT_OUTPUTS(X) \

// Registers:
//  - toIMem_data0 : struct mem_req { byte_en: bits 4; addr: bits 32; data: bits 32 } (kind: value)
//  - toIMem_valid0 : bits 1 (kind: value)
//  - fromIMem_data0 : struct mem_resp { byte_en: bits 4; addr: bits 32; data: bits 32 } (kind: value)
//  - fromIMem_valid0 : bits 1 (kind: value)
//  - toDMem_data0 : struct mem_req { byte_en: bits 4; addr: bits 32; data: bits 32 } (kind: value)
//  - toDMem_valid0 : bits 1 (kind: value)
//  - fromDMem_data0 : struct mem_resp { byte_en: bits 4; addr: bits 32; data: bits 32 } (kind: value)
//  - fromDMem_valid0 : bits 1 (kind: value)
//  - f2d_data0 : struct fetch_bookkeeping { pc: bits 32; ppc: bits 32; epoch: bits 1 } (kind: value)
//  - f2d_valid0 : bits 1 (kind: value)
//  - f2dprim_data0 : struct fetch_bookkeeping { pc: bits 32; ppc: bits 32; epoch: bits 1 } (kind: value)
//  - f2dprim_valid0 : bits 1 (kind: value)
//  - d2e_data0 : struct decode_bookkeeping { pc: bits 32; ppc: bits 32; epoch: bits 1; dInst: struct decodedInst { valid_rs1: bits 1; valid_rs2: bits 1; valid_rd: bits 1; legal: bits 1; inst: bits 32; immediateType: struct maybe_immType { valid: bits 1; data: enum immType } }; rval1: bits 32; rval2: bits 32 } (kind: value)
//  - d2e_valid0 : bits 1 (kind: value)
//  - e2w_data0 : struct execute_bookkeeping { isUnsigned: bits 1; size: bits 2; offset: bits 2; newrd: bits 32; dInst: struct decodedInst { valid_rs1: bits 1; valid_rs2: bits 1; valid_rd: bits 1; legal: bits 1; inst: bits 32; immediateType: struct maybe_immType { valid: bits 1; data: enum immType } } } (kind: value)
//  - e2w_valid0 : bits 1 (kind: value)
//  - rf_x00_zero : bits 32 (kind: value)
//  - rf_x01_ra : bits 32 (kind: value)
//  - rf_x02_sp : bits 32 (kind: value)
//  - rf_x03_gp : bits 32 (kind: value)
//  - rf_x04_tp : bits 32 (kind: value)
//  - rf_x05_t0 : bits 32 (kind: value)
//  - rf_x06_t1 : bits 32 (kind: value)
//  - rf_x07_t2 : bits 32 (kind: value)
//  - rf_x08_s0_fp : bits 32 (kind: value)
//  - rf_x09_s1 : bits 32 (kind: value)
//  - rf_x10_a0 : bits 32 (kind: value)
//  - rf_x11_a1 : bits 32 (kind: value)
//  - rf_x12_a2 : bits 32 (kind: value)
//  - rf_x13_a3 : bits 32 (kind: value)
//  - rf_x14_a4 : bits 32 (kind: value)
//  - rf_x15_a5 : bits 32 (kind: value)
//  - rf_x16_a6 : bits 32 (kind: value)
//  - rf_x17_a7 : bits 32 (kind: value)
//  - rf_x18_s2 : bits 32 (kind: value)
//  - rf_x19_s3 : bits 32 (kind: value)
//  - rf_x20_s4 : bits 32 (kind: value)
//  - rf_x21_s5 : bits 32 (kind: value)
//  - rf_x22_s6 : bits 32 (kind: value)
//  - rf_x23_s7 : bits 32 (kind: value)
//  - rf_x24_s8 : bits 32 (kind: value)
//  - rf_x25_s9 : bits 32 (kind: value)
//  - rf_x26_s10 : bits 32 (kind: value)
//  - rf_x27_s11 : bits 32 (kind: value)
//  - rf_x28_t3 : bits 32 (kind: value)
//  - rf_x29_t4 : bits 32 (kind: value)
//  - rf_x30_t5 : bits 32 (kind: value)
//  - rf_x31_t6 : bits 32 (kind: value)
//  - mulState_valid : bits 1 (kind: ehr)
//  - mulState_result : bits 64 (kind: ehr)
//  - mulState_finished : bits 1 (kind: ehr)
//  - scoreboard_x00_zero : bits 2 (kind: value)
//  - scoreboard_x01_ra : bits 2 (kind: value)
//  - scoreboard_x02_sp : bits 2 (kind: value)
//  - scoreboard_x03_gp : bits 2 (kind: value)
//  - scoreboard_x04_tp : bits 2 (kind: value)
//  - scoreboard_x05_t0 : bits 2 (kind: value)
//  - scoreboard_x06_t1 : bits 2 (kind: value)
//  - scoreboard_x07_t2 : bits 2 (kind: value)
//  - scoreboard_x08_s0_fp : bits 2 (kind: value)
//  - scoreboard_x09_s1 : bits 2 (kind: value)
//  - scoreboard_x10_a0 : bits 2 (kind: value)
//  - scoreboard_x11_a1 : bits 2 (kind: value)
//  - scoreboard_x12_a2 : bits 2 (kind: value)
//  - scoreboard_x13_a3 : bits 2 (kind: value)
//  - scoreboard_x14_a4 : bits 2 (kind: value)
//  - scoreboard_x15_a5 : bits 2 (kind: value)
//  - scoreboard_x16_a6 : bits 2 (kind: value)
//  - scoreboard_x17_a7 : bits 2 (kind: value)
//  - scoreboard_x18_s2 : bits 2 (kind: value)
//  - scoreboard_x19_s3 : bits 2 (kind: value)
//  - scoreboard_x20_s4 : bits 2 (kind: value)
//  - scoreboard_x21_s5 : bits 2 (kind: value)
//  - scoreboard_x22_s6 : bits 2 (kind: value)
//  - scoreboard_x23_s7 : bits 2 (kind: value)
//  - scoreboard_x24_s8 : bits 2 (kind: value)
//  - scoreboard_x25_s9 : bits 2 (kind: value)
//  - scoreboard_x26_s10 : bits 2 (kind: value)
//  - scoreboard_x27_s11 : bits 2 (kind: value)
//  - scoreboard_x28_t3 : bits 2 (kind: value)
//  - scoreboard_x29_t4 : bits 2 (kind: value)
//  - scoreboard_x30_t5 : bits 2 (kind: value)
//  - scoreboard_x31_t6 : bits 2 (kind: value)
//  - cycle_count : bits 32 (kind: value)
//  - instr_count : bits 32 (kind: value)
//  - pc : bits 32 (kind: value)
//  - epoch : bits 1 (kind: value)

// The input format of the input seed should be consistent with the input format expected by the module
namespace harness {
    struct extfuns_impl; 
    using extfuns_t = extfuns_impl;
}
namespace harness {

// Total input size IO: 22 bytes
   static constexpr std::size_t  InputBytesPerCycle =22; 
// Total input size REG: 277 bytes
   static constexpr std::size_t  InitBytes =277; 

 struct extfuns_impl {

    EXT_INPUTS(HARNESS_DECL_INPUT_CHANNEL)
    EXT_OUTPUTS(HARNESS_DECL_OUTPUT_CHANNEL)
static void clear() {
    EXT_INPUTS(HARNESS_CLEAR_INPUT_CHANNEL)
    EXT_OUTPUTS(HARNESS_CLEAR_OUTPUT_CHANNEL)
}
 auto ext_mem_dmem(struct_mem_input ready);
 auto ext_uart_write(struct_maybe_bits_8 ready);
 auto ext_uart_read(bits<1> ready);
 auto ext_mem_imem(struct_mem_input ready);
 auto ext_led(struct_maybe_bits_1 ready);
 
  enum_hostID ext_host_id(bits<1>) {
    return enum_hostID::Cuttlesim;
  }

  template<typename simulator>
  bits<1> ext_finish(simulator& sim, struct_maybe_bits_8 req) {
    if (req.valid) {
      bits<8> exitcode = req.data;
      if (exitcode == 8'0_b) {
        printf("  [0;32mPASS[0m\n");
      } else {
        printf("  [0;31mFAIL[0m (%d)\n", exitcode.v);
      }
      sim.finish(cuttlesim::exit_info_none, exitcode.v);
    }
    return 1'0_b;
  }
};

using simulator = module_rv32<extfuns_t>;
using snapshot_t = simulator::snapshot_t;
using state_t = simulator::state_t;
static std::string CrashLogPath = "";

#define DEF_INPUT_CHANNEL(name, width, storage) \
 input_channel_fifo<extfuns_impl::name##_stored_t> extfuns_impl::name##_chan;
EXT_INPUTS(DEF_INPUT_CHANNEL)
#undef DEF_INPUT_CHANNEL

#define DEF_OUTPUT_CHANNEL(name, width, storage) \
 output_channel_fifo<extfuns_impl::name##_stored_t> extfuns_impl::name##_chan;
EXT_OUTPUTS(DEF_OUTPUT_CHANNEL)
#undef DEF_OUTPUT_CHANNEL

inline auto extfuns_impl::ext_mem_dmem(struct_mem_input ready) {
 // ready can be ignored
  const ext_mem_dmem_stored_t p = ext_mem_dmem_chan.pop_or_zero();
  return p;
}
inline auto extfuns_impl::ext_uart_write(struct_maybe_bits_8 ready) {
 // ready can be ignored
  const ext_uart_write_stored_t p = ext_uart_write_chan.pop_or_zero();
  return p;
}
inline auto extfuns_impl::ext_uart_read(bits<1> ready) {
 // ready can be ignored
  const ext_uart_read_stored_t p = ext_uart_read_chan.pop_or_zero();
  return p;
}
inline auto extfuns_impl::ext_mem_imem(struct_mem_input ready) {
 // ready can be ignored
  const ext_mem_imem_stored_t p = ext_mem_imem_chan.pop_or_zero();
  return p;
}
inline auto extfuns_impl::ext_led(struct_maybe_bits_1 ready) {
 // ready can be ignored
  const ext_led_stored_t p = ext_led_chan.pop_or_zero();
  return p;
}

static std::string  decode_path_for(const char* input_path) {
    std::string in_path(input_path ? input_path : "");
    return in_path + "_decoded";
}

template <typename BitsT>
static void dump_bits_field(FILE* out, const char* name, int width, BitsT value) {
  const auto packed = prims::pack(value);
  std::fprintf(out, "%s[%d] = 0x%08x\n", name, width, (unsigned)packed.v);
}

template <int BitWidth>
static prims::bits<BitWidth> pack_bits_from_bytes(const std::vector<uint8_t>& buf, std::size_t offset, std::size_t nbytes) {
  prims::bits<BitWidth> acc = prims::bits<BitWidth>::mk(0);
  for (std::size_t i = 0; i < nbytes; ++i) {
    const uint8_t byte = (offset + i < buf.size()) ? buf[offset + i] : 0;
    const auto b = prims::widen<BitWidth>(prims::bits<8>::mk(byte));
    acc = acc | (b << (8 * i));
  }
  return acc;
}


template <typename T>
inline void dump_hex_value(FILE* out, const char* item_name, std::size_t idx, const T& v, int bit_width) {
const int hex_digits = (bit_width + 3) / 4;
if constexpr (std::is_integral_v<T>) {
  std::fprintf(out, "%s[%zu]: 0x%0*llx\n",
               item_name,
               idx,
               hex_digits,
               static_cast<unsigned long long>(v));
} else {
  const auto packed = prims::pack(v);
  std::fprintf(out, "%s[%zu]: 0x%0*llx\n",
               item_name,
               idx,
               hex_digits,
               static_cast<unsigned long long>(packed.v));
}
}

template <typename QueueT>
inline void dump_queue_hex(FILE* out, const char* title, const char* item_name, QueueT q, int bit_width) {
std::fprintf(out, "--- %s ---\n", title);

std::size_t idx = 0;
while (!q.empty()) {
  const auto v = q.front();
  q.pop();
  dump_hex_value(out, item_name, idx, v, bit_width);
  ++idx;
}

if (idx == 0) {
  std::fprintf(out, "(empty)\n");
}
}

static void  dump_state(const char* label, const state_t& st) {
  FILE* out = std::fopen(CrashLogPath.c_str(), "a");
  if (!out) {
    std::fprintf(stderr, "Failed to open %s: %s\n",
                 CrashLogPath.c_str(), std::strerror(errno));
    out = stderr;
  }

  std::fprintf(out, "=== %s ===\n", label);
#define DUMP_FIELD(name, width) dump_bits_field(out, #name, width, st.name);
  ALL_REGISTERS(DUMP_FIELD)
#undef DUMP_FIELD

 dump_queue_hex(out, "extfuns ext_mem_dmem queue", " ext_mem_dmem ",  extfuns_impl::ext_mem_dmem_chan.q, 70);
 dump_queue_hex(out, "extfuns ext_uart_write queue", " ext_uart_write ",  extfuns_impl::ext_uart_write_chan.q, 1);
 dump_queue_hex(out, "extfuns ext_uart_read queue", " ext_uart_read ",  extfuns_impl::ext_uart_read_chan.q, 9);
 dump_queue_hex(out, "extfuns ext_mem_imem queue", " ext_mem_imem ",  extfuns_impl::ext_mem_imem_chan.q, 70);
 dump_queue_hex(out, "extfuns ext_led queue", " ext_led ",  extfuns_impl::ext_led_chan.q, 1);

  if (out != stderr) {
    std::fclose(out);
  }
}

static void set_inputs(const std::vector<uint8_t>& buf, const std::size_t kSeedPairs,const std::size_t input_offset) {
  extfuns_impl::clear();
constexpr std::size_t ext_mem_dmem_bytes = 9;
constexpr std::size_t ext_uart_write_bytes = 1;
constexpr std::size_t ext_uart_read_bytes = 2;
constexpr std::size_t ext_mem_imem_bytes = 9;
constexpr std::size_t ext_led_bytes = 1;
constexpr std::size_t total_bytes = 22;
for (std::size_t i = 0; i < kSeedPairs; ++i) {
  const std::size_t base_off = input_offset + i * total_bytes;
  {
    const std::size_t off = base_off + 0;
    prims::bits<72> safe_ext_mem_dmem = pack_bits_from_bytes<72>(buf, off, ext_mem_dmem_bytes);
    extfuns_impl::ext_mem_dmem_chan.push(prims::unpack<struct_mem_output>(prims::truncate<70>(safe_ext_mem_dmem)));
  }
  {
    const std::size_t off = base_off + 9;
    prims::bits<8> safe_ext_uart_write = pack_bits_from_bytes<8>(buf, off, ext_uart_write_bytes);
    extfuns_impl::ext_uart_write_chan.push(prims::truncate<1>(safe_ext_uart_write));
  }
  {
    const std::size_t off = base_off + 10;
    prims::bits<16> safe_ext_uart_read = pack_bits_from_bytes<16>(buf, off, ext_uart_read_bytes);
    extfuns_impl::ext_uart_read_chan.push(prims::unpack<struct_maybe_bits_8>(prims::truncate<9>(safe_ext_uart_read)));
  }
  {
    const std::size_t off = base_off + 12;
    prims::bits<72> safe_ext_mem_imem = pack_bits_from_bytes<72>(buf, off, ext_mem_imem_bytes);
    extfuns_impl::ext_mem_imem_chan.push(prims::unpack<struct_mem_output>(prims::truncate<70>(safe_ext_mem_imem)));
  }
  {
    const std::size_t off = base_off + 21;
    prims::bits<8> safe_ext_led = pack_bits_from_bytes<8>(buf, off, ext_led_bytes);
    extfuns_impl::ext_led_chan.push(prims::truncate<1>(safe_ext_led));
  }
}
}

static void  set_init(state_t &st, const std::vector<uint8_t>& buf) {
   prims::bits<72> toIMem_data0 = prims::bits<72>::mk(0);

   prims::bits<8> toIMem_valid0 = prims::bits<8>::mk(0);

   prims::bits<72> fromIMem_data0 = prims::bits<72>::mk(0);

   prims::bits<8> fromIMem_valid0 = prims::bits<8>::mk(0);

   prims::bits<72> toDMem_data0 = prims::bits<72>::mk(0);

   prims::bits<8> toDMem_valid0 = prims::bits<8>::mk(0);

   prims::bits<72> fromDMem_data0 = prims::bits<72>::mk(0);

   prims::bits<8> fromDMem_valid0 = prims::bits<8>::mk(0);

   prims::bits<72> f2d_data0 = prims::bits<72>::mk(0);

   prims::bits<8> f2d_valid0 = prims::bits<8>::mk(0);

   prims::bits<72> f2dprim_data0 = prims::bits<72>::mk(0);

   prims::bits<8> f2dprim_valid0 = prims::bits<8>::mk(0);

   prims::bits<176> d2e_data0 = prims::bits<176>::mk(0);

   prims::bits<8> d2e_valid0 = prims::bits<8>::mk(0);

   prims::bits<80> e2w_data0 = prims::bits<80>::mk(0);

   prims::bits<8> e2w_valid0 = prims::bits<8>::mk(0);

   prims::bits<32> rf_x00_zero = prims::bits<32>::mk(0);

   prims::bits<32> rf_x01_ra = prims::bits<32>::mk(0);

   prims::bits<32> rf_x02_sp = prims::bits<32>::mk(0);

   prims::bits<32> rf_x03_gp = prims::bits<32>::mk(0);

   prims::bits<32> rf_x04_tp = prims::bits<32>::mk(0);

   prims::bits<32> rf_x05_t0 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x06_t1 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x07_t2 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x08_s0_fp = prims::bits<32>::mk(0);

   prims::bits<32> rf_x09_s1 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x10_a0 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x11_a1 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x12_a2 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x13_a3 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x14_a4 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x15_a5 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x16_a6 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x17_a7 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x18_s2 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x19_s3 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x20_s4 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x21_s5 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x22_s6 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x23_s7 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x24_s8 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x25_s9 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x26_s10 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x27_s11 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x28_t3 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x29_t4 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x30_t5 = prims::bits<32>::mk(0);

   prims::bits<32> rf_x31_t6 = prims::bits<32>::mk(0);

   prims::bits<8> mulState_valid = prims::bits<8>::mk(0);

   prims::bits<64> mulState_result = prims::bits<64>::mk(0);

   prims::bits<8> mulState_finished = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x00_zero = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x01_ra = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x02_sp = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x03_gp = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x04_tp = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x05_t0 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x06_t1 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x07_t2 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x08_s0_fp = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x09_s1 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x10_a0 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x11_a1 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x12_a2 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x13_a3 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x14_a4 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x15_a5 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x16_a6 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x17_a7 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x18_s2 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x19_s3 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x20_s4 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x21_s5 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x22_s6 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x23_s7 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x24_s8 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x25_s9 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x26_s10 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x27_s11 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x28_t3 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x29_t4 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x30_t5 = prims::bits<8>::mk(0);

   prims::bits<8> scoreboard_x31_t6 = prims::bits<8>::mk(0);

   prims::bits<32> cycle_count = prims::bits<32>::mk(0);

   prims::bits<32> instr_count = prims::bits<32>::mk(0);

   prims::bits<32> pc = prims::bits<32>::mk(0);

   prims::bits<8> epoch = prims::bits<8>::mk(0);

 toIMem_data0 = pack_bits_from_bytes<72>(buf, 0, 9);

 toIMem_valid0 = pack_bits_from_bytes<8>(buf, 9, 1);

 fromIMem_data0 = pack_bits_from_bytes<72>(buf, 10, 9);

 fromIMem_valid0 = pack_bits_from_bytes<8>(buf, 19, 1);

 toDMem_data0 = pack_bits_from_bytes<72>(buf, 20, 9);

 toDMem_valid0 = pack_bits_from_bytes<8>(buf, 29, 1);

 fromDMem_data0 = pack_bits_from_bytes<72>(buf, 30, 9);

 fromDMem_valid0 = pack_bits_from_bytes<8>(buf, 39, 1);

 f2d_data0 = pack_bits_from_bytes<72>(buf, 40, 9);

 f2d_valid0 = pack_bits_from_bytes<8>(buf, 49, 1);

 f2dprim_data0 = pack_bits_from_bytes<72>(buf, 50, 9);

 f2dprim_valid0 = pack_bits_from_bytes<8>(buf, 59, 1);

 d2e_data0 = pack_bits_from_bytes<176>(buf, 60, 22);

 d2e_valid0 = pack_bits_from_bytes<8>(buf, 82, 1);

 e2w_data0 = pack_bits_from_bytes<80>(buf, 83, 10);

 e2w_valid0 = pack_bits_from_bytes<8>(buf, 93, 1);

 rf_x00_zero = pack_bits_from_bytes<32>(buf, 94, 4);

 rf_x01_ra = pack_bits_from_bytes<32>(buf, 98, 4);

 rf_x02_sp = pack_bits_from_bytes<32>(buf, 102, 4);

 rf_x03_gp = pack_bits_from_bytes<32>(buf, 106, 4);

 rf_x04_tp = pack_bits_from_bytes<32>(buf, 110, 4);

 rf_x05_t0 = pack_bits_from_bytes<32>(buf, 114, 4);

 rf_x06_t1 = pack_bits_from_bytes<32>(buf, 118, 4);

 rf_x07_t2 = pack_bits_from_bytes<32>(buf, 122, 4);

 rf_x08_s0_fp = pack_bits_from_bytes<32>(buf, 126, 4);

 rf_x09_s1 = pack_bits_from_bytes<32>(buf, 130, 4);

 rf_x10_a0 = pack_bits_from_bytes<32>(buf, 134, 4);

 rf_x11_a1 = pack_bits_from_bytes<32>(buf, 138, 4);

 rf_x12_a2 = pack_bits_from_bytes<32>(buf, 142, 4);

 rf_x13_a3 = pack_bits_from_bytes<32>(buf, 146, 4);

 rf_x14_a4 = pack_bits_from_bytes<32>(buf, 150, 4);

 rf_x15_a5 = pack_bits_from_bytes<32>(buf, 154, 4);

 rf_x16_a6 = pack_bits_from_bytes<32>(buf, 158, 4);

 rf_x17_a7 = pack_bits_from_bytes<32>(buf, 162, 4);

 rf_x18_s2 = pack_bits_from_bytes<32>(buf, 166, 4);

 rf_x19_s3 = pack_bits_from_bytes<32>(buf, 170, 4);

 rf_x20_s4 = pack_bits_from_bytes<32>(buf, 174, 4);

 rf_x21_s5 = pack_bits_from_bytes<32>(buf, 178, 4);

 rf_x22_s6 = pack_bits_from_bytes<32>(buf, 182, 4);

 rf_x23_s7 = pack_bits_from_bytes<32>(buf, 186, 4);

 rf_x24_s8 = pack_bits_from_bytes<32>(buf, 190, 4);

 rf_x25_s9 = pack_bits_from_bytes<32>(buf, 194, 4);

 rf_x26_s10 = pack_bits_from_bytes<32>(buf, 198, 4);

 rf_x27_s11 = pack_bits_from_bytes<32>(buf, 202, 4);

 rf_x28_t3 = pack_bits_from_bytes<32>(buf, 206, 4);

 rf_x29_t4 = pack_bits_from_bytes<32>(buf, 210, 4);

 rf_x30_t5 = pack_bits_from_bytes<32>(buf, 214, 4);

 rf_x31_t6 = pack_bits_from_bytes<32>(buf, 218, 4);

 mulState_valid = pack_bits_from_bytes<8>(buf, 222, 1);

 mulState_result = pack_bits_from_bytes<64>(buf, 223, 8);

 mulState_finished = pack_bits_from_bytes<8>(buf, 231, 1);

 scoreboard_x00_zero = pack_bits_from_bytes<8>(buf, 232, 1);

 scoreboard_x01_ra = pack_bits_from_bytes<8>(buf, 233, 1);

 scoreboard_x02_sp = pack_bits_from_bytes<8>(buf, 234, 1);

 scoreboard_x03_gp = pack_bits_from_bytes<8>(buf, 235, 1);

 scoreboard_x04_tp = pack_bits_from_bytes<8>(buf, 236, 1);

 scoreboard_x05_t0 = pack_bits_from_bytes<8>(buf, 237, 1);

 scoreboard_x06_t1 = pack_bits_from_bytes<8>(buf, 238, 1);

 scoreboard_x07_t2 = pack_bits_from_bytes<8>(buf, 239, 1);

 scoreboard_x08_s0_fp = pack_bits_from_bytes<8>(buf, 240, 1);

 scoreboard_x09_s1 = pack_bits_from_bytes<8>(buf, 241, 1);

 scoreboard_x10_a0 = pack_bits_from_bytes<8>(buf, 242, 1);

 scoreboard_x11_a1 = pack_bits_from_bytes<8>(buf, 243, 1);

 scoreboard_x12_a2 = pack_bits_from_bytes<8>(buf, 244, 1);

 scoreboard_x13_a3 = pack_bits_from_bytes<8>(buf, 245, 1);

 scoreboard_x14_a4 = pack_bits_from_bytes<8>(buf, 246, 1);

 scoreboard_x15_a5 = pack_bits_from_bytes<8>(buf, 247, 1);

 scoreboard_x16_a6 = pack_bits_from_bytes<8>(buf, 248, 1);

 scoreboard_x17_a7 = pack_bits_from_bytes<8>(buf, 249, 1);

 scoreboard_x18_s2 = pack_bits_from_bytes<8>(buf, 250, 1);

 scoreboard_x19_s3 = pack_bits_from_bytes<8>(buf, 251, 1);

 scoreboard_x20_s4 = pack_bits_from_bytes<8>(buf, 252, 1);

 scoreboard_x21_s5 = pack_bits_from_bytes<8>(buf, 253, 1);

 scoreboard_x22_s6 = pack_bits_from_bytes<8>(buf, 254, 1);

 scoreboard_x23_s7 = pack_bits_from_bytes<8>(buf, 255, 1);

 scoreboard_x24_s8 = pack_bits_from_bytes<8>(buf, 256, 1);

 scoreboard_x25_s9 = pack_bits_from_bytes<8>(buf, 257, 1);

 scoreboard_x26_s10 = pack_bits_from_bytes<8>(buf, 258, 1);

 scoreboard_x27_s11 = pack_bits_from_bytes<8>(buf, 259, 1);

 scoreboard_x28_t3 = pack_bits_from_bytes<8>(buf, 260, 1);

 scoreboard_x29_t4 = pack_bits_from_bytes<8>(buf, 261, 1);

 scoreboard_x30_t5 = pack_bits_from_bytes<8>(buf, 262, 1);

 scoreboard_x31_t6 = pack_bits_from_bytes<8>(buf, 263, 1);

 cycle_count = pack_bits_from_bytes<32>(buf, 264, 4);

 instr_count = pack_bits_from_bytes<32>(buf, 268, 4);

 pc = pack_bits_from_bytes<32>(buf, 272, 4);

 epoch = pack_bits_from_bytes<8>(buf, 276, 1);

 st.toIMem_data0 = prims::unpack<decltype(st.toIMem_data0)>(prims::truncate<68>(toIMem_data0)); 
 st.toIMem_valid0 = prims::truncate<1>(toIMem_valid0);
 st.fromIMem_data0 = prims::unpack<decltype(st.fromIMem_data0)>(prims::truncate<68>(fromIMem_data0)); 
 st.fromIMem_valid0 = prims::truncate<1>(fromIMem_valid0);
 st.toDMem_data0 = prims::unpack<decltype(st.toDMem_data0)>(prims::truncate<68>(toDMem_data0)); 
 st.toDMem_valid0 = prims::truncate<1>(toDMem_valid0);
 st.fromDMem_data0 = prims::unpack<decltype(st.fromDMem_data0)>(prims::truncate<68>(fromDMem_data0)); 
 st.fromDMem_valid0 = prims::truncate<1>(fromDMem_valid0);
 st.f2d_data0 = prims::unpack<decltype(st.f2d_data0)>(prims::truncate<65>(f2d_data0)); 
 st.f2d_valid0 = prims::truncate<1>(f2d_valid0);
 st.f2dprim_data0 = prims::unpack<decltype(st.f2dprim_data0)>(prims::truncate<65>(f2dprim_data0)); 
 st.f2dprim_valid0 = prims::truncate<1>(f2dprim_valid0);
 st.d2e_data0 = prims::unpack<decltype(st.d2e_data0)>(prims::truncate<169>(d2e_data0)); 
 st.d2e_valid0 = prims::truncate<1>(d2e_valid0);
 st.e2w_data0 = prims::unpack<decltype(st.e2w_data0)>(prims::truncate<77>(e2w_data0)); 
 st.e2w_valid0 = prims::truncate<1>(e2w_valid0);
 st.rf_x00_zero = prims::bits<32>::mk(rf_x00_zero);
 st.rf_x01_ra = prims::bits<32>::mk(rf_x01_ra);
 st.rf_x02_sp = prims::bits<32>::mk(rf_x02_sp);
 st.rf_x03_gp = prims::bits<32>::mk(rf_x03_gp);
 st.rf_x04_tp = prims::bits<32>::mk(rf_x04_tp);
 st.rf_x05_t0 = prims::bits<32>::mk(rf_x05_t0);
 st.rf_x06_t1 = prims::bits<32>::mk(rf_x06_t1);
 st.rf_x07_t2 = prims::bits<32>::mk(rf_x07_t2);
 st.rf_x08_s0_fp = prims::bits<32>::mk(rf_x08_s0_fp);
 st.rf_x09_s1 = prims::bits<32>::mk(rf_x09_s1);
 st.rf_x10_a0 = prims::bits<32>::mk(rf_x10_a0);
 st.rf_x11_a1 = prims::bits<32>::mk(rf_x11_a1);
 st.rf_x12_a2 = prims::bits<32>::mk(rf_x12_a2);
 st.rf_x13_a3 = prims::bits<32>::mk(rf_x13_a3);
 st.rf_x14_a4 = prims::bits<32>::mk(rf_x14_a4);
 st.rf_x15_a5 = prims::bits<32>::mk(rf_x15_a5);
 st.rf_x16_a6 = prims::bits<32>::mk(rf_x16_a6);
 st.rf_x17_a7 = prims::bits<32>::mk(rf_x17_a7);
 st.rf_x18_s2 = prims::bits<32>::mk(rf_x18_s2);
 st.rf_x19_s3 = prims::bits<32>::mk(rf_x19_s3);
 st.rf_x20_s4 = prims::bits<32>::mk(rf_x20_s4);
 st.rf_x21_s5 = prims::bits<32>::mk(rf_x21_s5);
 st.rf_x22_s6 = prims::bits<32>::mk(rf_x22_s6);
 st.rf_x23_s7 = prims::bits<32>::mk(rf_x23_s7);
 st.rf_x24_s8 = prims::bits<32>::mk(rf_x24_s8);
 st.rf_x25_s9 = prims::bits<32>::mk(rf_x25_s9);
 st.rf_x26_s10 = prims::bits<32>::mk(rf_x26_s10);
 st.rf_x27_s11 = prims::bits<32>::mk(rf_x27_s11);
 st.rf_x28_t3 = prims::bits<32>::mk(rf_x28_t3);
 st.rf_x29_t4 = prims::bits<32>::mk(rf_x29_t4);
 st.rf_x30_t5 = prims::bits<32>::mk(rf_x30_t5);
 st.rf_x31_t6 = prims::bits<32>::mk(rf_x31_t6);
 st.mulState_valid = prims::truncate<1>(mulState_valid);
 st.mulState_result = prims::bits<64>::mk(mulState_result);
 st.mulState_finished = prims::truncate<1>(mulState_finished);
 st.scoreboard_x00_zero = prims::truncate<2>(scoreboard_x00_zero);
 st.scoreboard_x01_ra = prims::truncate<2>(scoreboard_x01_ra);
 st.scoreboard_x02_sp = prims::truncate<2>(scoreboard_x02_sp);
 st.scoreboard_x03_gp = prims::truncate<2>(scoreboard_x03_gp);
 st.scoreboard_x04_tp = prims::truncate<2>(scoreboard_x04_tp);
 st.scoreboard_x05_t0 = prims::truncate<2>(scoreboard_x05_t0);
 st.scoreboard_x06_t1 = prims::truncate<2>(scoreboard_x06_t1);
 st.scoreboard_x07_t2 = prims::truncate<2>(scoreboard_x07_t2);
 st.scoreboard_x08_s0_fp = prims::truncate<2>(scoreboard_x08_s0_fp);
 st.scoreboard_x09_s1 = prims::truncate<2>(scoreboard_x09_s1);
 st.scoreboard_x10_a0 = prims::truncate<2>(scoreboard_x10_a0);
 st.scoreboard_x11_a1 = prims::truncate<2>(scoreboard_x11_a1);
 st.scoreboard_x12_a2 = prims::truncate<2>(scoreboard_x12_a2);
 st.scoreboard_x13_a3 = prims::truncate<2>(scoreboard_x13_a3);
 st.scoreboard_x14_a4 = prims::truncate<2>(scoreboard_x14_a4);
 st.scoreboard_x15_a5 = prims::truncate<2>(scoreboard_x15_a5);
 st.scoreboard_x16_a6 = prims::truncate<2>(scoreboard_x16_a6);
 st.scoreboard_x17_a7 = prims::truncate<2>(scoreboard_x17_a7);
 st.scoreboard_x18_s2 = prims::truncate<2>(scoreboard_x18_s2);
 st.scoreboard_x19_s3 = prims::truncate<2>(scoreboard_x19_s3);
 st.scoreboard_x20_s4 = prims::truncate<2>(scoreboard_x20_s4);
 st.scoreboard_x21_s5 = prims::truncate<2>(scoreboard_x21_s5);
 st.scoreboard_x22_s6 = prims::truncate<2>(scoreboard_x22_s6);
 st.scoreboard_x23_s7 = prims::truncate<2>(scoreboard_x23_s7);
 st.scoreboard_x24_s8 = prims::truncate<2>(scoreboard_x24_s8);
 st.scoreboard_x25_s9 = prims::truncate<2>(scoreboard_x25_s9);
 st.scoreboard_x26_s10 = prims::truncate<2>(scoreboard_x26_s10);
 st.scoreboard_x27_s11 = prims::truncate<2>(scoreboard_x27_s11);
 st.scoreboard_x28_t3 = prims::truncate<2>(scoreboard_x28_t3);
 st.scoreboard_x29_t4 = prims::truncate<2>(scoreboard_x29_t4);
 st.scoreboard_x30_t5 = prims::truncate<2>(scoreboard_x30_t5);
 st.scoreboard_x31_t6 = prims::truncate<2>(scoreboard_x31_t6);
 st.cycle_count = prims::bits<32>::mk(cycle_count);
 st.instr_count = prims::bits<32>::mk(instr_count);
 st.pc = prims::bits<32>::mk(pc);
 st.epoch = prims::truncate<1>(epoch);
}

static void  set_init_and_inputs(state_t &st, const std::vector<uint8_t>& buf, const std::size_t kSeedPairs) {
set_init(st, buf);
 set_inputs(buf, kSeedPairs, InitBytes);
}

} // namespace harness


#include "assertions.hpp"


int main(int argc, char **argv) {

   bool replay = false;
   const char *input_path = nullptr;

 if (argc == 3 && strcmp(argv[1], "--replay") == 0) {
     replay = true; 
      input_path = argv[2];
 } else if (argc == 2) {
     input_path = argv[1]; 
 } else {
     fprintf(stderr, "Usage: %s [--replay] <input_file>\n", argv[0]);
     return 1;
 }

 FILE *f = fopen(input_path, "rb");
 if (!f) {
     fprintf(stderr, "Error: unable to open %s\n", input_path);
     return 1;
 }

   std::vector<uint8_t> buf; 
   fseek(f, 0, SEEK_END); // move to end of file
   long file_size = ftell(f); // get file size
   fseek(f, 0, SEEK_SET); // move back to start of file
   if (file_size > 0){
       buf.resize(file_size); // resize buffer to fit file size
       fread(buf.data(), 1, file_size, f); // read file into buffer
   } else {
       fprintf(stderr, "Error: unable to read from %s\n", input_path);
       return 1;
   }
   fclose(f); // close file

beak_mode::plan plan;

if (!beak_mode::prepare_input<harness::InitBytes,harness::InputBytesPerCycle>(buf, plan)) {
 return 0; 
}

 harness::simulator::state_t st = harness::simulator::initial_state();

 BEAK_APPLY_FUZZ_MODE(harness, st, buf, plan);

 if (replay) { 
    harness::CrashLogPath = harness::decode_path_for(input_path);
    const std::string ruletrace_path = harness::CrashLogPath + "_ruletrace";
    setenv("SIM_RULETRACE_FPATH", ruletrace_path.c_str(), 1);
    fprintf(stderr, "Replaying input from %s\n", input_path);
    harness::dump_state("Initial State", st);
}
    harness::simulator sim(st); 
    sim.set_assert_pred(assert_fn);
    sim.set_assert_pred_final(assert_final);
   sim.run_fuzz(plan.cycles, !replay); // run_fuzz is fuzzing method
 if (replay) { 
    harness::dump_state("Final State", sim.snapshot().state);
}

  return 0;
}
