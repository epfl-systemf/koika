#ifndef _ASSERTIONS_HPP
#define _ASSERTIONS_HPP


template <typename sim_t>
inline bool assert_fn(const sim_t& sim) {

  auto& snap_hist = sim.get_snapshots();
  if (snap_hist.size() < 2) return true;

  const auto &prev = snap_hist[snap_hist.size() - 2];
  const auto &curr = snap_hist.back();

  if (prev.state.epoch.v == curr.state.epoch.v) {
    return (prev.state.pc.v + 4) == curr.state.pc.v; 
  }
  return true; 

}


template <typename sim_t>
inline bool assert_final(const sim_t& sim) {

  return true;
}

#endif